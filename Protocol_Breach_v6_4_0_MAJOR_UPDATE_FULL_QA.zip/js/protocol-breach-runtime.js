/* ===== bootstrap-data.js ===== */
// Protocol Breach v6.4.0 — expanded simulated CLI, mission lifecycle fixes, scenario learning briefings.
// Protocol Breach bootstrap data: companies + all embedded scenarios
// companies.js — Challenge Board data (preserved from the original project)
window.COMPANIES = [
  { id: 1,  name: "Maple & Ash Legal Partners",         industry: "Corporate Law / Legal",            employees: 18,     difficulty: "Weak",             tagline: "Small firm, big secrets, zero security." },
  { id: 2,  name: "Brix Dental Partners",                industry: "Dental Care / Healthcare",         employees: 45,     difficulty: "Medium",           tagline: "3 clinics, 1 shared password, unpatched PACS." },
  { id: 3,  name: "RheinWerk Commerce GmbH",              industry: "E-Commerce / Online Retail",       employees: 220,    difficulty: "Medium",           tagline: "Leaky API, vulnerable returns portal." },
  { id: 4,  name: "PixelForge Interactive",               industry: "Game Dev / Interactive Media",     employees: 180,    difficulty: "Hard",             tagline: "Security-conscious, but leaked CI/CD secret." },
  { id: 5,  name: "Al Nahda Capital",                     industry: "Private Equity / Finance",         employees: 400,    difficulty: "Brutal",           tagline: "Heavy defenses, but an old VPN & insider." },
  { id: 6,  name: "Rede Vida Hospital Network",           industry: "Healthcare / Hospital Network",    employees: 12000,  difficulty: "Hard",             tagline: "12,000 staff, legacy IoT, shared badges." },
  { id: 7,  name: "Hanul Logistics & Manufacturing",      industry: "Port Logistics / OT / Battery",    employees: 45000,  difficulty: "Brutal",           tagline: "Brutal IT, but unmonitored OT & vendor backdoor." },
  { id: 8,  name: "Borealis Energy Group",                industry: "Renewable Energy / Grid",          employees: 110000, difficulty: "Brutal",           tagline: "Brutal security, except exposed Grafana & SNMP." },
  { id: 9,  name: "Aurora Media & Entertainment",         industry: "Streaming / Film / Music",         employees: 75000,  difficulty: "Brutal",           tagline: "Cloud-native, but public S3 & over-privileged role." },
  { id: 10, name: "Meridian Global Shipping",             industry: "Global Shipping / Port Ops",       employees: 220000, difficulty: "Extremely Brutal", tagline: "AI SOC & zero trust, but legacy EDI & OT holes." }
];

window.DIFFICULTY_MULT = {
  "Weak": 0.50,
  "Medium": 0.75,
  "Hard": 1.00,
  "Brutal": 1.35,
  "Extremely Brutal": 1.75
};

window.DIFFICULTY_ORDER = ["Weak", "Medium", "Hard", "Brutal", "Extremely Brutal"];

// Mission time-pressure bands. Each band lowers the maximum attainable score;
// crossing the fifth band ends the operation. Timers begin only when the
// player actually clicks Start Mission, not while reading the briefing.
window.MISSION_TIME_RULES = {
  scoreThresholdFactors: [0.15, 0.175, 0.20, 0.225, 0.25],
  scoreCaps: [80, 70, 55, 40, 20],
  timeoutFactor: 0.30,
  difficultyScale: {
    1:{min:4,max:10}, 2:{min:5,max:12}, 3:{min:6,max:15}, 4:{min:7,max:18},
    5:{min:8,max:20}, 6:{min:10,max:24}, 7:{min:12,max:28}, 8:{min:14,max:32},
    9:{min:16,max:36}, 10:{min:18,max:42}
  }
};
window.MISSION_SCORE_CAPS = [80, 70, 55, 40, 20];

// Protocol Breach scenario data bundle — all scenarios embedded for reliable local/offline loading

window.SCENARIO_LIBRARY = window.SCENARIO_LIBRARY || {};

/* SCENARIO 1: plan-01.js */
(function() {
// scenario-p1.js — Maple & Ash Legal Partners
// FULLY STRUCTURED DATA with tables/arrays for all possible fields

window.SCENARIO = {
    id: 1,

    // ─── Basic Info ───
    name: "Maple & Ash Legal Partners",
    welcomeMessage: "🔒 Target: 203.0.113.64/29 — RDP, SMB, OWA, WordPress",
    description: "A small law firm with weak security – RDP exposed, SMBv1, default creds.",
    
    // ─── Environment Variables ───
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },

    // ─── Network Data (table of hosts with services) ───
    network: {
        subnets: [
            { cidr: "203.0.113.64/29", description: "Public IP range" },
            { cidr: "192.168.1.0/24", description: "Internal network" }
        ],
        hosts: [
            {
                ip: "203.0.113.65",
                hostname: "www.mapleashlegal.ca",
                os: "Ubuntu 18.04",
                services: [
                    { port: 80, protocol: "tcp", service: "http", product: "Apache 2.4.41", version: "2.4.41" },
                    { port: 443, protocol: "tcp", service: "https", product: "Apache 2.4.41", version: "2.4.41" }
                ],
                vulnerabilities: [
                    { id: "WP-5.2.3", name: "WordPress 5.2.3", description: "Multiple vulnerabilities including file upload and SQLi", exploit: "wpscan, sqlmap" }
                ]
            },
            {
                ip: "203.0.113.66",
                hostname: "rdp.mapleashlegal.ca",
                os: "Windows Server 2012 R2",
                services: [
                    { port: 3389, protocol: "tcp", service: "rdp", product: "Microsoft Terminal Services", version: "6.3" }
                ],
                vulnerabilities: [
                    { id: "CVE-2019-0708", name: "BlueKeep", description: "Remote code execution in RDP", exploit: "Metasploit bluekeep" },
                    { id: "Default-Creds", name: "Default Administrator Credentials", description: "Administrator / Maple2020!", exploit: "hydra, xfreerdp" }
                ]
            },
            {
                ip: "203.0.113.67",
                hostname: "fs.mapleashlegal.ca",
                os: "Windows Server 2012 R2",
                services: [
                    { port: 139, protocol: "tcp", service: "netbios-ssn", product: "SMBv1", version: "1.0" },
                    { port: 445, protocol: "tcp", service: "smb", product: "SMBv1", version: "1.0" }
                ],
                vulnerabilities: [
                    { id: "MS17-010", name: "EternalBlue", description: "SMBv1 remote code execution", exploit: "Metasploit ms17_010_eternalblue" },
                    { id: "SMBv1", name: "SMBv1 Enabled", description: "Legacy protocol with known exploits", exploit: "enum4linux, smbclient" },
                    { id: "Guest-Access", name: "Guest Share Access", description: "ClientFiles$ accessible via guest", exploit: "smbclient //203.0.113.67/ClientFiles$" }
                ]
            },
            {
                ip: "203.0.113.68",
                hostname: "mail.mapleashlegal.ca",
                os: "Windows Server 2016",
                services: [
                    { port: 80, protocol: "tcp", service: "http", product: "Microsoft Exchange OWA", version: "2016" },
                    { port: 443, protocol: "tcp", service: "https", product: "Microsoft Exchange OWA", version: "2016" }
                ],
                vulnerabilities: [
                    { id: "Weak-Passwords", name: "Weak OWA Passwords", description: "Three users with Spring2020!", exploit: "hydra owa" }
                ]
            }
        ]
    },

    // ─── Users / Credentials ───
    users: [
        { username: "dash", password: "password123", email: "dash@mapleashlegal.ca", role: "Managing Partner", osint: "Breached credential reuse" },
        { username: "pmaple", password: "Spring2020!", email: "pmaple@mapleashlegal.ca", role: "Partner", osint: "Sticky note with IP" },
        { username: "tkessler", password: "Spring2020!", email: "tkessler@mapleashlegal.ca", role: "Office Manager", osint: "Voicemail about backup" },
        { username: "gliu", password: "Spring2020!", email: "gliu@mapleashlegal.ca", role: "Paralegal", osint: "Twitter complains about weak passwords" },
        { username: "intern", password: "intern123", email: "intern@mapleashlegal.ca", role: "Intern", osint: "Summer student default" },
        { username: "Administrator", password: "Maple2020!", role: "Domain Admin", osint: "Default RDP creds" },
        { username: "admin", password: "password", role: "WordPress Admin", osint: "Default WP admin" }
    ],

    // ─── Virtual Filesystem ───
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt", "mnt", "proc", "sys", "dev"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", "Downloads", ".bashrc", ".profile", ".local", ".config"],
        "/home/kali/Desktop": ["notes.txt", "scan_results.txt", "payload.exe"],
        "/home/kali/Documents": ["report.docx", "client_data.xlsx"],
        "/home/kali/Downloads": ["nmap_scan.xml", "wpscan_report.txt"],
        "/etc": ["hosts", "passwd", "shadow", "hostname", "resolv.conf", "fstab", "crontab"],
        "/var": ["log", "www", "spool", "tmp"],
        "/var/log": ["syslog", "auth.log", "kern.log", "dpkg.log"],
        "/var/www": ["html"],
        "/var/www/html": ["index.html", "wp-config.php", ".htaccess", "robots.txt"],
        "/tmp": [],
        "/root": [".bashrc", ".profile", "flag.txt"]
    },

    // ─── File Contents ───
    fileContents: {
        "/home/kali/Desktop/notes.txt": "Operational notes:\n- Investigate OWA for David's password-reuse lead.\n- Administrator appears to have legacy RDP credentials; verify them from evidence.\n- SMB share ClientFiles$ contains interesting documents.\n- Preserve evidence and confirm the objective flag through the tool workflow.",
        "/home/kali/Desktop/scan_results.txt": "Nmap scan of 203.0.113.64/29:\n203.0.113.65: 80,443 (WordPress)\n203.0.113.66: 3389 (RDP) - BlueKeep vulnerable\n203.0.113.67: 445,139 (SMB) - EternalBlue vulnerable\n203.0.113.68: 80,443 (OWA)",
        "/home/kali/Desktop/payload.exe": "MZ... (malicious executable for /careers upload)",
        "/etc/hostname": "proto",
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\nkali:x:1000:1000:Kali,,,:/home/kali:/bin/bash",
        "/etc/shadow": "root:*:19000:0:99999:7:::\nkali:$6$xyz$hash:19000:0:99999:7:::",
        "/var/www/html/wp-config.php": "<?php\ndefine('DB_NAME', 'wordpress');\ndefine('DB_USER', 'wpuser');\ndefine('DB_PASSWORD', 'password123');\ndefine('DB_HOST', 'localhost');\n// SQLi at /client-login?user=\n?>",
        "/var/www/html/robots.txt": "User-agent: *\nDisallow: /wp-admin/\nDisallow: /client-login/\nDisallow: /careers/",
        "/root/flag.txt": "MAPLE{domain_admin} - you found the root flag!"
    },

    // ─── Flags ───
    flags: [
        { id: "MAPLE{initial_access}", description: "RDP or OWA compromise", hint: "hydra or xfreerdp to 203.0.113.66" },
        { id: "MAPLE{client_files}", description: "Access ClientFiles$ share", hint: "smbclient //203.0.113.67/ClientFiles$" },
        { id: "MAPLE{recruitment_malware}", description: "Upload malicious .exe via careers", hint: "Upload to /careers" },
        { id: "MAPLE{domain_admin}", description: "Compromise file server or workstation", hint: "EternalBlue or domain admin creds" }
    ],

    // ─── Pentest Command Handlers ───
    // Each handler receives (args, scenario, helpers) and returns a string.
    // helpers provides: currentPath, flagsFound, findFlagInText, resolvePath,
    // listDirectory, getFileContent, printLine, scenario, env, getHostByIP,
    // getServiceByIPPort, getAllIPs
    commands: {
        // ── Network Scanning ──
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.64/29';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            
            // Check flags
            let version = parsed.flags['-sV'] || false;
            let port = parsed.flags['-p'] || null;
            let allPorts = parsed.flags['-p-'] || false;
            let osDetect = parsed.flags['-O'] || false;
            let aggressive = parsed.flags['-A'] || false;
            let script = parsed.flags['--script'] || null;
            let defaultScripts = parsed.flags['-sC'] || false;
            let synScan = parsed.flags['-sS'] || false;

            // Find hosts in scenario
            const hosts = scenario.network.hosts;
            let matchedHosts = [];
            
            if (target === '203.0.113.64/29' || target === '203.0.113.64') {
                matchedHosts = hosts;
            } else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }

            if (matchedHosts.length === 0) {
                return `nmap: scan for ${target} not found in scenario data.`;
            }

            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os} (${osDetect ? 'detected' : 'guess'})\n`;
                output += `PORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    if (port && service.port != port && !allPorts) return;
                    const state = (service.port === 445 || service.port === 3389 || service.port === 80) ? 'open' : 'filtered';
                    output += `${String(service.port).padStart(5)}/${service.protocol}  ${state.padEnd(6)} ${service.service}`;
                    if (version) output += `  ${service.product} ${service.version}`;
                    if (script && script.includes('vuln')) {
                        const vulns = host.vulnerabilities || [];
                        vulns.forEach(v => {
                            output += `\n| ${v.id}: ${v.name}`;
                        });
                    }
                    output += '\n';
                });
            });
            output += `\nNmap done: ${matchedHosts.length} IP addresses scanned in 2.34 seconds`;
            return output;
        },

        // ── OSINT ──
        theHarvester: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let domain = parsed.targets[0] || 'mapleashlegal.ca';
            let output = `[+] theHarvester -d ${domain}\n`;
            output += `[+] Found emails:\n`;
            scenario.users.forEach(u => {
                if (u.email && u.email.includes(domain)) {
                    output += `    ${u.email}\n`;
                }
            });
            output += `[+] Found subdomains:\n    www.${domain}\n    mail.${domain}\n    fs.${domain}\n    rdp.${domain}\n`;
            output += `[+] Found hosts:\n    ${scenario.network.hosts.map(h => h.ip).join('\n    ')}`;
            return output;
        },

        shodan: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let query = parsed.remaining.join(' ') || 'port:3389 country:CA';
            let output = `[+] Shodan search: ${query}\n`;
            if (query.includes('3389')) {
                output += `    ${scenario.network.hosts.find(h => h.services.some(s => s.port === 3389))?.ip || '203.0.113.66'}:3389 - Microsoft Terminal Services\n`;
            }
            if (query.includes('445')) {
                output += `    ${scenario.network.hosts.find(h => h.services.some(s => s.port === 445))?.ip || '203.0.113.67'}:445 - SMBv1 (Windows 2012 R2)\n`;
            }
            output += `[+] Total results: 3`;
            return output;
        },

        // ── SMB Enumeration ──
        enum4linux: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.67';
            let all = parsed.flags['-a'] || false;
            let users = parsed.flags['-U'] || false;
            let shares = parsed.flags['-S'] || false;
            
            const host = helpers.getHostByIP(target);
            if (!host) return `enum4linux: target ${target} not recognized.`;
            
            let output = `[+] Enumerating ${target}\n`;
            if (all || shares) {
                output += `[+] Share Enumeration:\n`;
                output += `    Sharename       Type      Comment\n`;
                output += `    ---------       ----      -------\n`;
                output += `    ADMIN$          Disk      Remote Admin\n`;
                output += `    C$              Disk      Default share\n`;
                output += `    ClientFiles$    Disk      Client documents (guest accessible)\n`;
                output += `    IPC$            IPC       Remote IPC\n`;
            }
            if (all || users) {
                output += `[+] Users: Administrator, Guest, David, Priya, Tom, Grace, Intern\n`;
                // Show passwords from scenario
                output += `[+] Password policy: none\n`;
                scenario.users.forEach(u => {
                    if (u.username && u.password) {
                        output += `    ${u.username}: ${u.password}\n`;
                    }
                });
            }
            if (all) {
                output += `[+] SMBv1 enabled\n`;
                const vulns = host.vulnerabilities || [];
                vulns.forEach(v => {
                    if (v.id === 'MS17-010') output += `[+] VULNERABLE: EternalBlue (MS17-010)\n`;
                    if (v.id === 'SMBv1') output += `[+] VULNERABLE: SMBv1 enabled\n`;
                });
            }
            return output;
        },

        smbclient: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '//203.0.113.67/ClientFiles$';
            let list = parsed.flags['-L'] || false;
            let cmd = parsed.flags['-c'] || null;
            
            if (target.includes('ClientFiles$')) {
                let output = `[+] Connecting to 203.0.113.67\\ClientFiles$\n`;
                output += `[+] Login successful (guest)\n`;
                if (list) {
                    output += `[+] Share list:\n    ClientFiles$ (Disk)\n`;
                } else {
                    output += `[+] Listing share contents:\n`;
                    output += `    client_data_2021.xlsx\n`;
                    output += `    contracts/\n`;
                    output += `    financials.pdf\n`;
                    output += `    flag.txt   <--- contains MAPLE{client_files}\n`;
                    if (cmd && cmd.includes('get flag.txt')) {
                        output += `[+] Retrieved flag.txt: MAPLE{client_files}\n`;
                        helpers.findFlagInText('MAPLE{client_files}');
                    }
                }
                return output;
            } else {
                return `smbclient: target not recognized. Try 'ClientFiles$'`;
            }
        },

        wpscan: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let url = parsed.flags['--url'] || parsed.targets[0] || 'https://www.mapleashlegal.ca';
            let vulnPlugins = parsed.flags['-e vp'] || false;
            let vulnThemes = parsed.flags['-e vt'] || false;
            let plugins = parsed.flags['-e p'] || false;
            
            if (url.includes('mapleashlegal.ca')) {
                let output = `[+] WordPress 5.2.3 detected\n`;
                if (vulnPlugins || plugins) {
                    output += `[+] Vulnerable plugins:\n`;
                    output += `    - wp-file-upload 4.2 (arbitrary file upload) → /careers\n`;
                    output += `    - wp-sql-injection 1.0 (SQLi in client-login)\n`;
                }
                output += `[+] Admin user: admin (password: password) — default\n`;
                output += `[+] Found /wp-login.php\n`;
                output += `[+] Found /client-login (SQL injection possible)\n`;
                output += `[+] Found /careers (file upload) → MAPLE{recruitment_malware}\n`;
                output += `[+] Hidden comment in source: <!-- SQLi at /client-login?user= -->\n`;
                helpers.findFlagInText('MAPLE{recruitment_malware}');
                return output;
            } else {
                return `wpscan: url not recognized. Use --url https://www.mapleashlegal.ca`;
            }
        },

        sqlmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let url = parsed.flags['-u'] || parsed.targets[0] || '';
            let dbs = parsed.flags['--dbs'] || false;
            let tables = parsed.flags['--tables'] || false;
            let dump = parsed.flags['--dump'] || false;
            
            if (url.includes('client-login')) {
                let output = `[+] SQLMap started on ${url}\n`;
                output += `[+] Parameter 'user' seems vulnerable to boolean-based blind\n`;
                if (dbs) {
                    output += `[+] Extracted databases: wordpress, clients, employees\n`;
                }
                if (tables) {
                    output += `[+] Table 'clients' contains columns: id, name, email, phone, case_data\n`;
                }
                if (dump) {
                    output += `[+] Dumping sample: \n    id: 1, name: 'Acme Corp', email: 'contact@acme.com'\n`;
                    output += `[+] Found admin credentials: admin / password123\n`;
                    output += `[+] Flag: MAPLE{initial_access} (OWA)\n`;
                    helpers.findFlagInText('MAPLE{initial_access}');
                }
                return output;
            } else {
                return `sqlmap: provide target URL with -u "https://www.mapleashlegal.ca/client-login?user=1"`;
            }
        },

        hydra: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '';
            let user = parsed.flags['-l'] || '';
            let pass = parsed.flags['-p'] || '';
            
            let protocol = 'rdp';
            if (target.includes('owa') || target.includes('mail')) protocol = 'owa';
            if (target.includes('rdp://')) protocol = 'rdp';
            
            if (protocol === 'rdp' || target.includes('203.0.113.66')) {
                let output = `[+] Hydra starting at ${new Date().toLocaleTimeString()}\n`;
                output += `[+] Target: 203.0.113.66:3389\n`;
                output += `[+] Password found: Maple2020!\n`;
                output += `[+] Login successful! Use xfreerdp.\n`;
                output += `[+] Flag: MAPLE{initial_access} (RDP)\n`;
                helpers.findFlagInText('MAPLE{initial_access}');
                return output;
            } else if (protocol === 'owa' || target.includes('mail')) {
                let output = `[+] Hydra on mail.mapleashlegal.ca (OWA)\n`;
                output += `[+] Found credentials:\n`;
                scenario.users.forEach(u => {
                    if (u.email && u.password) {
                        output += `    ${u.username || u.email}: ${u.password}\n`;
                    }
                });
                output += `[+] Flag: MAPLE{initial_access} (OWA)\n`;
                helpers.findFlagInText('MAPLE{initial_access}');
                return output;
            } else {
                return `hydra: supported: rdp://203.0.113.66 or owa target`;
            }
        },

        xfreerdp: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let v = parsed.flags['/v'] || parsed.targets[0] || '';
            let u = parsed.flags['/u'] || '';
            let p = parsed.flags['/p'] || '';
            if (v !== '203.0.113.66') return `xfreerdp: target not recognized. Use /v:203.0.113.66`;
            if (!u || !p) return `xfreerdp: credentials required. Use /v:203.0.113.66 /u:Administrator /p:<password>. Obtain credentials from scenario evidence first.`;
            const account = (scenario.users||[]).find(x=>String(x.username||'').toLowerCase()===String(u).toLowerCase());
            if (!account || String(account.password)!==String(p)) return `[!] Login failed: invalid fictional credentials for ${u}@${v}`;
            let output = `[+] Connecting to ${v} ...\n`;
            output += `[+] Username: ${u}\n`;
            output += `[+] Login successful!\n`;
            output += `[+] RDP session established on ${v}.\n`;
            output += `[+] Remote host: ${account.role||'Windows Server'}\n`;
            return output;
        },

        careers: function(args, scenario, helpers) {
            const action = String((args||[])[0]||'inspect').toLowerCase();
            if (action === 'inspect') return `[+] Careers portal (SIMULATED)\n[+] Endpoint: /careers\n[+] Upload workflow: enabled\n[+] Accepted attachment: .exe\n[+] Use the Browser to open the careers portal and submit the fictional payload.`;
            if (action === 'upload' || action === 'submit') {
                const file = (args||[])[1] || 'payload.exe';
                if (!/payload\.exe$|\.exe$/i.test(file)) return `careers: upload rejected. This training workflow accepts a fictional .exe attachment.`;
                helpers.findFlagInText('MAPLE{recruitment_malware}');
                return `[+] Careers upload accepted (SIMULATED)\n[+] Attachment: ${file}\n[+] Flag: MAPLE{recruitment_malware}`;
            }
            return `careers inspect | careers upload <file> — fictional careers portal workflow.`;
        },
        gobuster: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let url = parsed.flags['-u'] || parsed.targets[0] || 'https://www.mapleashlegal.ca';
            
            if (url.includes('mapleashlegal.ca')) {
                return `[+] Gobuster scanning ${url}\n` +
                       `[+] Found: /wp-admin (301)\n` +
                       `[+] Found: /wp-login.php (200)\n` +
                       `[+] Found: /client-login (200) → SQLi\n` +
                       `[+] Found: /careers (200) → file upload\n` +
                       `[+] Found: /backup (403)\n` +
                       `[+] Found: /hidden (200) — check with curl`;
            }
            return `gobuster: use -u https://www.mapleashlegal.ca`;
        },

        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('smb') || keyword.includes('eternal')) {
                return `[+] Exploit: MS17-010 EternalBlue\n    use exploit/windows/smb/ms17_010_eternalblue\n[+] Exploit: SMBGhost (CVE-2020-0796)`;
            } else if (keyword.includes('rdp') || keyword.includes('bluekeep')) {
                return `[+] Exploit: BlueKeep (CVE-2019-0708)\n    use exploit/windows/rdp/cve_2019_0708_bluekeep`;
            } else if (keyword.includes('wordpress')) {
                return `[+] Exploit: WordPress 5.2.3 File Upload\n    use exploit/multi/http/wp_file_upload`;
            } else {
                return `searchsploit: try 'smb', 'rdp', or 'wordpress'`;
            }
        },

        msfconsole: function(args, scenario, helpers) {
            let output = `[+] Metasploit console started.\n`;
            output += `msf6 > use exploit/windows/smb/ms17_010_eternalblue\n`;
            output += `msf6 exploit(ms17_010_eternalblue) > set RHOSTS 203.0.113.67\n`;
            output += `msf6 exploit(ms17_010_eternalblue) > run\n`;
            output += `[*] 203.0.113.67:445 - Exploit successful, shell opened!\n`;
            output += `[+] Flag: MAPLE{domain_admin}\n`;
            helpers.findFlagInText('MAPLE{domain_admin}');
            return output;
        }
    }
};

// ─── Helper: parseArgs for flag handling ───
function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('/') && arg.length >= 3) {
            const m = arg.match(/^(\/[^:]+):(.*)$/);
            if (m) result.flags[m[1]] = m[2];
            else result.flags[arg] = true;
        } else if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) {
                result.flags[parts[0]] = parts[1];
            } else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else {
                    result.flags[arg] = true;
                }
            }
        } else if (arg.startsWith('-')) {
            const flagName = arg;
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) {
                            result.flags['-' + c] = true;
                        }
                    }
                } else {
                    result.flags[name] = value || true;
                }
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else {
                    result.flags[arg] = true;
                }
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else {
                result.remaining.push(arg);
            }
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 1) throw new Error("Scenario 1 failed registration");
window.SCENARIO_LIBRARY[1] = window.SCENARIO;
window.SCENARIO = null;
})();

/* SCENARIO 2: plan-02.js */
(function() {
// scenario-p2.js — Brix Dental Partners
window.SCENARIO = {
    id: 2,

    name: "Brix Dental Partners",
    welcomeMessage: "🔒 Target: 203.0.113.80/29 — PACS, CCTV, webmail, patient portal",
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },
    network: {
        subnets: [
            { cidr: "203.0.113.80/29", description: "Public IP range" },
            { cidr: "10.20.1.0/24", description: "Internal clinic network" }
        ],
        hosts: [
            {
                ip: "203.0.113.80",
                hostname: "www.brixdental.co.za",
                os: "Ubuntu 20.04",
                services: [
                    { port: 80, protocol: "tcp", service: "http", product: "Apache", version: "2.4.41" },
                    { port: 443, protocol: "tcp", service: "https", product: "Apache", version: "2.4.41" }
                ],
                vulnerabilities: [
                    { id: "WP-FM", name: "wp-file-manager vulnerable", description: "WordPress plugin allows file upload", exploit: "wpscan" }
                ]
            },
            {
                ip: "203.0.113.83",
                hostname: "cctv.brixdental.co.za",
                os: "Linux (Hikvision)",
                services: [
                    { port: 8080, protocol: "tcp", service: "http", product: "Hikvision CCTV", version: "V5.5.0" }
                ],
                vulnerabilities: [
                    { id: "Hikvision-Default", name: "Default Hikvision Credentials", description: "admin / 12345", exploit: "hydra, browser" }
                ]
            },
            {
                ip: "203.0.113.84",
                hostname: "pacs.brixdental.co.za",
                os: "Windows Server 2019",
                services: [
                    { port: 8042, protocol: "tcp", service: "http", product: "Orthanc PACS", version: "1.9.0" }
                ],
                vulnerabilities: [
                    { id: "Orthanc-Default", name: "Default Orthanc Credentials", description: "orthanc / orthanc", exploit: "browser, API" }
                ]
            },
            {
                ip: "203.0.113.85",
                hostname: "mail.brixdental.co.za",
                os: "Ubuntu 18.04",
                services: [
                    { port: 80, protocol: "tcp", service: "http", product: "Roundcube Webmail", version: "1.4.10" },
                    { port: 443, protocol: "tcp", service: "https", product: "Roundcube Webmail", version: "1.4.10" }
                ],
                vulnerabilities: [
                    { id: "Roundcube-1.4.10", name: "Roundcube 1.4.10", description: "Multiple vulnerabilities, weak password reuse", exploit: "sqlmap, hydra" }
                ]
            }
        ]
    },
    users: [
        { username: "pbrix", password: "BrixDental!2023", email: "pbrix@brixdental.co.za", role: "Owner", osint: "LinkedIn post mentions PACS URL in screenshot" },
        { username: "snkosi", password: "BrixDental!2023", email: "snkosi@brixdental.co.za", role: "Office Manager", osint: "Facebook photo of computer screen showing password" },
        { username: "avdm", password: "BrixDental!2023", email: "avdm@brixdental.co.za", role: "Dentist", osint: "Uses personal Gmail, LinkedIn password from breach" },
        { username: "tkhumalo", password: "BrixDental!2023", email: "tkhumalo@brixdental.co.za", role: "IT Support", osint: "GitHub has clinic network diagram" },
        { username: "orthanc", password: "orthanc", role: "PACS Admin", osint: "Default PACS credentials" },
        { username: "admin", password: "12345", role: "CCTV Admin", osint: "Default Hikvision credentials" }
    ],
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", "Downloads", ".bashrc"],
        "/home/kali/Desktop": ["notes.txt", "scan_results.txt"],
        "/etc": ["hosts", "passwd", "hostname"],
        "/var": ["log", "www"],
        "/var/www": ["html"],
        "/var/www/html": ["index.html", "wp-config.php"],
        "/tmp": []
    },
    fileContents: {
        "/home/kali/Desktop/notes.txt": "Brix Dental targets:\n- PACS at 203.0.113.84:8042 - investigate the Orthanc default-credential lead.\n- CCTV at 203.0.113.83:8080 - investigate the Hikvision default-credential lead.\n- A shared workstation password-reuse lead exists; corroborate it before use.\n- Record objective evidence through the relevant tool, not from this note.",
        "/home/kali/Desktop/scan_results.txt": "Nmap scan 203.0.113.80/29:\n203.0.113.80: 80,443 (WordPress)\n203.0.113.83: 8080 (CCTV)\n203.0.113.84: 8042 (PACS)\n203.0.113.85: 80,443 (Roundcube)",
        "/etc/hostname": "proto",
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nkali:x:1000:1000:Kali:/home/kali:/bin/bash",
        "/var/www/html/wp-config.php": "<?php\ndefine('DB_NAME', 'wordpress');\ndefine('DB_USER', 'wpuser');\ndefine('DB_PASSWORD', 'password');\ndefine('DB_HOST', 'localhost');\n?>"
    },
    flags: [
        { id: "BRIX{frontdesk_cctv}", description: "Access CCTV admin", hint: "Hikvision default creds" },
        { id: "BRIX{pacs_images}", description: "Exfiltrate DICOM data", hint: "Orthanc default creds" },
        { id: "BRIX{email_compromise}", description: "Access OWA", hint: "Roundcube weak passwords" },
        { id: "BRIX{patient_records}", description: "IDOR on patient portal", hint: "SQLi or IDOR in /patient-portal" }
    ],
    commands: {
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.80/29';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            let hosts = scenario.network.hosts;
            let matchedHosts = [];
            if (target === '203.0.113.80/29' || target === '203.0.113.80') {
                matchedHosts = hosts;
            } else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }
            if (matchedHosts.length === 0) return `nmap: scan for ${target} not found.`;
            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os}\nPORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    output += `${String(service.port).padStart(5)}/${service.protocol}  open   ${service.service}\n`;
                });
            });
            output += `\nNmap done: ${matchedHosts.length} IP addresses scanned`;
            return output;
        },
        wpscan: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let url = parsed.flags['--url'] || parsed.targets[0] || 'https://www.brixdental.co.za';
            if (url.includes('brixdental')) {
                return `[+] WordPress 5.2.3 detected\n[+] Vulnerable plugin: wp-file-manager\n[+] Admin user: admin (password: password)\n[+] Found /wp-login.php\n[+] Found /patient-portal (IDOR)\n[+] Found /careers (PDF upload)`;
            }
            return `wpscan: use --url https://www.brixdental.co.za`;
        },
        hydra: function(args, scenario, helpers) {
            const target = (args||[]).find(x => /^(https?:\/\/|rdp:\/\/|owa:\/\/)/i.test(x)) || (args||[]).find(x => /brixdental|203\.0\.113\./i.test(x)) || '';
            if (/203\.0\.113\.83(?::8080)?|cctv\.brixdental\.co\.za(?::8080)?/i.test(target)) {
                return `[+] Hydra starting\n[+] Target: cctv.brixdental.co.za:8080 (Hikvision)\n[+] Found: admin:12345\n[+] Login successful!\n[+] Flag: BRIX{frontdesk_cctv}`;
            }
            if (/mail\.brixdental\.co\.za|203\.0\.113\.85/i.test(target)) {
                return `[+] Hydra starting\n[+] Target: mail.brixdental.co.za (Roundcube)\n[+] Found: pbrix:BrixDental!2023\n[+] Found: snkosi:BrixDental!2023\n[+] Flag: BRIX{email_compromise}`;
            }
            return `hydra: target required. Supported Brix targets: http://cctv.brixdental.co.za:8080 or https://mail.brixdental.co.za`;
        },
        // ... other commands similar to p1 with Brix-specific responses
        enum4linux: function(args, scenario, helpers) { return 'enum4linux: SMB not exposed on this target.'; },
        smbclient: function(args, scenario, helpers) { return 'smbclient: SMB not exposed on this target.'; },
        sqlmap: function(args, scenario, helpers) { return 'sqlmap: No SQLi found on this target.'; },
        xfreerdp: function(args, scenario, helpers) { return 'xfreerdp: RDP not exposed on this target.'; },
        gobuster: function(args, scenario, helpers) {
            return `[+] Gobuster scanning\n[+] Found: /patient-portal (IDOR)\n[+] Found: /careers (upload)\n[+] Found: /wp-admin`;
        },
        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('hikvision')) return `[+] Exploit: Hikvision default creds\n    Use: admin/12345 on port 8080`;
            if (keyword.includes('orthanc')) return `[+] Exploit: Orthanc default creds\n    Use: orthanc/orthanc on port 8042`;
            if (keyword.includes('wordpress')) return `[+] Exploit: wp-file-manager\n    Use: file upload to get shell`;
            return `searchsploit: try 'hikvision', 'orthanc', or 'wordpress'`;
        },
        msfconsole: function(args, scenario, helpers) {
            return `[+] Metasploit console\nmsf6 > use exploit/multi/http/wp_file_upload\nmsf6 > set RHOSTS 203.0.113.80\nmsf6 > run\n[*] Uploaded shell!`;
        },
        theHarvester: function(args, scenario, helpers) {
            return `[+] Found emails:\n    pbrix@brixdental.co.za\n    snkosi@brixdental.co.za\n    avdm@brixdental.co.za\n    tkhumalo@brixdental.co.za`;
        },
        shodan: function(args, scenario, helpers) {
            return `[+] Shodan results:\n    203.0.113.84:8042 - Orthanc PACS (default creds)\n    203.0.113.83:8080 - Hikvision CCTV (admin/12345)`;
        }
    }
};

function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) result.flags[parts[0]] = parts[1];
            else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else if (arg.startsWith('-')) {
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) result.flags['-' + c] = true;
                    }
                } else result.flags[name] = value || true;
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else result.remaining.push(arg);
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 2) throw new Error("Scenario 2 failed registration");
window.SCENARIO_LIBRARY[2] = window.SCENARIO;
window.SCENARIO = null;
})();

/* SCENARIO 3: plan-03.js */
(function() {
// scenario-p3.js — RheinWerk Commerce
window.SCENARIO = {
    id: 3,

    name: "RheinWerk Commerce GmbH",
    welcomeMessage: "🔒 Target: 203.0.113.96/28 — Magento, API, Jenkins, S3 bucket",
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },
    network: {
        subnets: [
            { cidr: "203.0.113.96/28", description: "Public IP range" },
            { cidr: "10.30.0.0/16", description: "Internal network" }
        ],
        hosts: [
            {
                ip: "203.0.113.97",
                hostname: "www.rheinwerk-commerce.de",
                os: "Ubuntu 20.04",
                services: [
                    { port: 80, protocol: "tcp", service: "http", product: "Apache", version: "2.4.41" },
                    { port: 443, protocol: "tcp", service: "https", product: "Apache", version: "2.4.41" }
                ],
                vulnerabilities: [
                    { id: "Magento-SQLi", name: "Amasty_Shopby SQL injection", description: "Plugin allows SQLi", exploit: "sqlmap" }
                ]
            },
            {
                ip: "203.0.113.98",
                hostname: "api.rheinwerk-commerce.de",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Node.js API", version: "14.x" }
                ],
                vulnerabilities: [
                    { id: "Swagger-Exposed", name: "Public Swagger", description: "API docs with leaked key sk_live_9f3e...", exploit: "curl, browser" }
                ]
            },
            {
                ip: "203.0.113.99",
                hostname: "ci.rheinwerk-commerce.de",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Jenkins", version: "2.319" }
                ],
                vulnerabilities: [
                    { id: "Jenkins-NoAuth", name: "No authentication", description: "Public Jenkins console", exploit: "browser" }
                ]
            }
        ]
    },
    users: [
        { username: "jweber", password: "Winter2024!", email: "jweber@rheinwerk-commerce.de", role: "CTO", osint: "GitHub commits reveal Jenkins URL" },
        { username: "cbrandt", password: "Winter2024!", email: "cbrandt@rheinwerk-commerce.de", role: "Head of Marketing", osint: "Instagram story shows admin login" },
        { username: "fhartmann", password: "Winter2024!", email: "fhartmann@rheinwerk-commerce.de", role: "DevOps Engineer", osint: "Pasted API key in Slack" },
        { username: "aschmidt", password: "Winter2024!", email: "aschmidt@rheinwerk-commerce.de", role: "HR Manager", osint: "LinkedIn job post lists tech stack" },
        { username: "myilmaz", password: "Winter2024!", email: "myilmaz@rheinwerk-commerce.de", role: "Returns Support", osint: "Uses password Winter2024!" },
        { username: "admin", password: "admin123", role: "Magento Admin", osint: "Weak admin password" }
    ],
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", ".bashrc"],
        "/home/kali/Desktop": ["notes.txt", "api_key.txt"],
        "/etc": ["hosts", "passwd", "hostname"],
        "/var": ["log", "www"],
        "/var/www": ["html"],
        "/var/www/html": ["index.html", "wp-config.php"],
        "/tmp": []
    },
    fileContents: {
        "/home/kali/Desktop/notes.txt": "RheinWerk targets:\n- Magento at www.rheinwerk-commerce.de - investigate the Amasty_Shopby SQLi lead.\n- API at api.rheinwerk-commerce.de - Swagger is publicly visible; inspect it for exposed secrets.\n- Jenkins at ci.rheinwerk-commerce.de - no-auth lead.\n- Returns portal - ZIP upload behavior requires investigation.\n- Confirm objective evidence through the appropriate tool.",
        "/home/kali/Desktop/api_key.txt": "sk_live_9f3e8a7d6c5b4a3f2e1d0c9b8a7f6e5d",
        "/etc/hostname": "proto",
        "/var/www/html/wp-config.php": "<?php\ndefine('DB_NAME', 'magento');\ndefine('DB_USER', 'magento');\ndefine('DB_PASSWORD', 'password');\n?>"
    },
    flags: [
        { id: "RHEIN{api_key_leaked}", description: "Use exposed API key", hint: "Swagger docs" },
        { id: "RHEIN{orders_db}", description: "Dump customer database", hint: "SQLi in Magento" },
        { id: "RHEIN{web_shell}", description: "Upload web shell via returns portal", hint: "ZIP upload" },
        { id: "RHEIN{warehouse_access}", description: "Pivot to internal warehouse systems", hint: "Jenkins" }
    ],
    commands: {
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.96/28';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            let hosts = scenario.network.hosts;
            let matchedHosts = [];
            if (target === '203.0.113.96/28' || target === '203.0.113.96') matchedHosts = hosts;
            else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }
            if (matchedHosts.length === 0) return `nmap: scan for ${target} not found.`;
            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os}\nPORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    output += `${String(service.port).padStart(5)}/${service.protocol}  open   ${service.service}\n`;
                });
            });
            return output;
        },
        wpscan: function(args, scenario, helpers) {
            return `[+] Magento 2.3.7 detected\n[+] Vulnerable plugin: Amasty_Shopby (SQLi)\n[+] Admin user: admin / admin123\n[+] Found /admin\n[+] Found /returns (ZIP upload)`;
        },
        sqlmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            if (parsed.targets.some(t => t.includes('amasty'))) {
                return `[+] SQLMap injecting Amasty_Shopby\n[+] Extracted admin hash: admin / admin123\n[+] Flag: RHEIN{orders_db}`;
            }
            return `sqlmap: use target with Amasty_Shopby parameter`;
        },
        hydra: function(args, scenario, helpers) {
            return `[+] Hydra on admin panel\n[+] Found: admin / admin123\n[+] Flag: RHEIN{admin_access}`;
        },
        // ... other commands
        enum4linux: function(args, scenario, helpers) { return 'enum4linux: SMB not exposed.'; },
        smbclient: function(args, scenario, helpers) { return 'smbclient: SMB not exposed.'; },
        xfreerdp: function(args, scenario, helpers) { return 'xfreerdp: RDP not exposed.'; },
        gobuster: function(args, scenario, helpers) {
            return `[+] Found: /admin\n[+] Found: /returns\n[+] Found: /api\n[+] Found: /jenkins`;
        },
        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('magento')) return `[+] Exploit: Magento SQLi\n[+] Exploit: Amasty_Shopby SQLi`;
            if (keyword.includes('jenkins')) return `[+] Jenkins: no auth, view console output`;
            return `searchsploit: try 'magento' or 'jenkins'`;
        },
        msfconsole: function(args, scenario, helpers) {
            return `[+] Metasploit\nmsf6 > use exploit/multi/http/magento_sqli\nmsf6 > set RHOSTS 203.0.113.97\nmsf6 > run\n[*] Shell obtained!\n[+] Flag: RHEIN{web_shell}`;
        },
        theHarvester: function(args, scenario, helpers) {
            return `[+] Found emails:\n    jweber@rheinwerk-commerce.de\n    cbrandt@rheinwerk-commerce.de\n    fhartmann@rheinwerk-commerce.de\n    aschmidt@rheinwerk-commerce.de\n    myilmaz@rheinwerk-commerce.de`;
        },
        shodan: function(args, scenario, helpers) {
            return `[+] Shodan results:\n    203.0.113.97:443 - Magento 2.3.7 (SQLi)\n    203.0.113.98:443 - API (Swagger exposed)\n    203.0.113.99:443 - Jenkins (no auth)`;
        }
    }
};

function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) result.flags[parts[0]] = parts[1];
            else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else if (arg.startsWith('-')) {
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) result.flags['-' + c] = true;
                    }
                } else result.flags[name] = value || true;
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else result.remaining.push(arg);
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 3) throw new Error("Scenario 3 failed registration");
window.SCENARIO_LIBRARY[3] = window.SCENARIO;
window.SCENARIO = null;
})();

/* SCENARIO 4: plan-04.js */
(function() {
// scenario-p4.js — PixelForge Interactive
window.SCENARIO = {
    id: 4,

    name: "PixelForge Interactive Pte Ltd",
    welcomeMessage: "🔒 Target: 203.0.113.112/28 — Docker registry, CI/CD, Confluence, VPN",
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },
    network: {
        subnets: [
            { cidr: "203.0.113.112/28", description: "Public IP range" },
            { cidr: "10.40.0.0/16", description: "Internal network" }
        ],
        hosts: [
            {
                ip: "203.0.113.112",
                hostname: "www.pixelforge.sg",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Static Site", version: "CDN" }
                ]
            },
            {
                ip: "203.0.113.113",
                hostname: "registry.pixelforge.sg",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Docker Registry", version: "2.0" }
                ],
                vulnerabilities: [
                    { id: "Registry-Basic", name: "Weak Basic Auth", description: "ci-bot / CIbot2023!", exploit: "docker login" }
                ]
            },
            {
                ip: "203.0.113.114",
                hostname: "ci.pixelforge.sg",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "GitLab CI", version: "14.0" }
                ],
                vulnerabilities: [
                    { id: "GitLab-Public", name: "Public job logs", description: "CI logs with secrets", exploit: "browser" }
                ]
            },
            {
                ip: "203.0.113.115",
                hostname: "wiki.pixelforge.sg",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Confluence", version: "7.12" }
                ],
                vulnerabilities: [
                    { id: "Confluence-NoAuth", name: "Unauthenticated space", description: "Public deploy space", exploit: "browser" }
                ]
            }
        ]
    },
    users: [
        { username: "mtan", password: "Secure123!", email: "mtan@pixelforge.sg", role: "CTO", osint: "Uses handle mtan-dev" },
        { username: "pnair", password: "Secure123!", email: "pnair@pixelforge.sg", role: "DevOps Lead", osint: "GitHub profile with CI script" },
        { username: "jwong", password: "Secure123!", email: "jwong@pixelforge.sg", role: "Game Designer", osint: "Tweets screenshot with internal IP" },
        { username: "echen", password: "Secure123!", email: "echen@pixelforge.sg", role: "HR", osint: "Job postings list tech stack" },
        { username: "qa-test", password: "QaTest2023!", role: "QA Test Account", osint: "VPN account with MFA bypass" },
        { username: "ci-bot", password: "CIbot2023!", role: "CI/CD Bot", osint: "Docker registry basic auth" }
    ],
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", ".bashrc"],
        "/home/kali/Desktop": ["notes.txt", "github_secret.txt"],
        "/etc": ["hosts", "passwd", "hostname"],
        "/tmp": []
    },
    fileContents: {
        "/home/kali/Desktop/notes.txt": "PixelForge targets:\n- GitHub: pixelforge/legacy-tools has a CI-secret lead.\n- Docker registry: registry.pixelforge.sg has a credential lead; corroborate before use.\n- Confluence: wiki.pixelforge.sg has a deploy space.\n- VPN: qa-test account has an MFA-bypass lead.\n- Confirm objective evidence through the relevant tool.",
        "/home/kali/Desktop/github_secret.txt": "AWS_SECRET_KEY: AKIA... (from .gitlab-ci.yml)",
        "/etc/hostname": "proto",
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nkali:x:1000:1000:Kali:/home/kali:/bin/bash"
    },
    flags: [
        { id: "PIXEL{github_secret}", description: "Find CI secret", hint: "GitHub repo" },
        { id: "PIXEL{registry_creds}", description: "Access Docker registry", hint: "ci-bot/CIbot2023!" },
        { id: "PIXEL{game_build}", description: "Exfiltrate game build", hint: "Docker registry" },
        { id: "PIXEL{internal_db}", description: "Access production database", hint: "VPN test account" }
    ],
    commands: {
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.112/28';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            let hosts = scenario.network.hosts;
            let matchedHosts = [];
            if (target === '203.0.113.112/28' || target === '203.0.113.112') matchedHosts = hosts;
            else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }
            if (matchedHosts.length === 0) return `nmap: scan for ${target} not found.`;
            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os}\nPORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    output += `${String(service.port).padStart(5)}/${service.protocol}  open   ${service.service}\n`;
                });
            });
            return output;
        },
        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('docker')) return `[+] Docker registry basic auth: ci-bot/CIbot2023!`;
            if (keyword.includes('confluence')) return `[+] Confluence unauthenticated space: /deploy`;
            if (keyword.includes('gitlab')) return `[+] GitLab public job logs with secrets`;
            return `searchsploit: try 'docker', 'confluence', or 'gitlab'`;
        },
        hydra: function(args, scenario, helpers) {
            return `[+] Hydra on registry.pixelforge.sg\n[+] Found: ci-bot / CIbot2023!\n[+] Flag: PIXEL{registry_creds}`;
        },
        // ... other commands
        enum4linux: function(args, scenario, helpers) { return 'enum4linux: SMB not exposed.'; },
        smbclient: function(args, scenario, helpers) { return 'smbclient: SMB not exposed.'; },
        sqlmap: function(args, scenario, helpers) { return 'sqlmap: No SQLi targets found.'; },
        wpscan: function(args, scenario, helpers) { return 'wpscan: No WordPress found.'; },
        xfreerdp: function(args, scenario, helpers) { return 'xfreerdp: RDP not exposed.'; },
        gobuster: function(args, scenario, helpers) {
            return `[+] Found: /deploy (Confluence space)\n[+] Found: /v2 (Docker registry)\n[+] Found: /api (GitLab)`;
        },
        msfconsole: function(args, scenario, helpers) {
            return `[+] Metasploit\nmsf6 > use exploit/multi/http/confluence\nmsf6 > set RHOSTS 203.0.113.115\nmsf6 > run\n[*] Confluence exploited!\n[+] Flag: PIXEL{game_build}`;
        },
        theHarvester: function(args, scenario, helpers) {
            return `[+] Found emails:\n    mtan@pixelforge.sg\n    pnair@pixelforge.sg\n    jwong@pixelforge.sg\n    echen@pixelforge.sg`;
        },
        shodan: function(args, scenario, helpers) {
            return `[+] Shodan results:\n    203.0.113.113:443 - Docker Registry (basic auth)\n    203.0.113.114:443 - GitLab CI\n    203.0.113.115:443 - Confluence (public space)`;
        }
    }
};

function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) result.flags[parts[0]] = parts[1];
            else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else if (arg.startsWith('-')) {
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) result.flags['-' + c] = true;
                    }
                } else result.flags[name] = value || true;
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else result.remaining.push(arg);
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 4) throw new Error("Scenario 4 failed registration");
window.SCENARIO_LIBRARY[4] = window.SCENARIO;
window.SCENARIO = null;
})();

/* SCENARIO 5: plan-05.js */
(function() {
// scenario-p5.js — Al Nahda Capital
window.SCENARIO = {
    id: 5,

    name: "Al Nahda Capital Limited",
    welcomeMessage: "🔒 Target: 203.0.113.128/27 — Pulse VPN, deal room, investor portal, PBX",
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },
    network: {
        subnets: [
            { cidr: "203.0.113.128/27", description: "Public IP range" },
            { cidr: "10.50.0.0/16", description: "Internal network" }
        ],
        hosts: [
            {
                ip: "203.0.113.128",
                hostname: "www.alnahdacapital.ae",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Static Site", version: "Nginx" }
                ]
            },
            {
                ip: "203.0.113.129",
                hostname: "vpn.alnahdacapital.ae",
                os: "Pulse Secure",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Pulse Secure VPN", version: "8.0" }
                ],
                vulnerabilities: [
                    { id: "CVE-2019-11510", name: "Pulse Secure VPN RCE", description: "Read /etc/passwd, steal sessions", exploit: "Metasploit" }
                ]
            },
            {
                ip: "203.0.113.130",
                hostname: "pbx.alnahdacapital.ae",
                os: "Linux",
                services: [
                    { port: 5060, protocol: "udp", service: "sip", product: "Asterisk PBX", version: "13.x" }
                ],
                vulnerabilities: [
                    { id: "SIP-Extensions", name: "Weak SIP extensions", description: "Extension 1001/1002 weak", exploit: "sipvicious" }
                ]
            }
        ]
    },
    users: [
        { username: "ralmansoor", password: "Secure2024!", email: "ralmansoor@alnahdacapital.ae", role: "CIO", osint: "High-profile, LinkedIn" },
        { username: "lfischer", password: "Secure2024!", email: "lfischer@alnahdacapital.ae", role: "Head of Compliance", osint: "Enforces security" },
        { username: "knassar", password: "password123", email: "knassar@alnahdacapital.ae", role: "Investment Analyst", osint: "Disgruntled, password reused from Adobe" },
        { username: "sosei", password: "Secure2024!", email: "sosei@alnahdacapital.ae", role: "IT Security Lead", osint: "Blog about security tools" },
        { username: "yrahman", password: "Secure2024!", email: "yrahman@alnahdacapital.ae", role: "Facilities", osint: "Voicemail mentions server room door code" },
        { username: "admin", password: "Admin@123", role: "Deal Room Admin", osint: "Basic auth weak" }
    ],
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", ".bashrc"],
        "/home/kali/Desktop": ["notes.txt", "pulse_exploit.txt"],
        "/etc": ["hosts", "passwd", "hostname"],
        "/tmp": []
    },
    fileContents: {
        "/home/kali/Desktop/notes.txt": "Al Nahda targets:\n- Pulse VPN: vpn.alnahdacapital.ae (CVE-2019-11510).\n- Deal Room: dealroom.alnahdacapital.ae has a default-credential lead.\n- Investor Portal: IDOR on documents.\n- SIP PBX: 203.0.113.130:5060 has weak-extension clues.\n- Confirm objective evidence through the relevant tool.",
        "/home/kali/Desktop/pulse_exploit.txt": "CVE-2019-11510 exploit steps:\n1. https://vpn.alnahdacapital.ae/dana-na/.../auth.cgi\n2. Read /etc/passwd\n3. Steal VPN session",
        "/etc/hostname": "proto",
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nkali:x:1000:1000:Kali:/home/kali:/bin/bash"
    },
    flags: [
        { id: "NAHDA{pulse_vpn}", description: "Exploit VPN CVE", hint: "CVE-2019-11510" },
        { id: "NAHDA{insider_docs}", description: "Access Karim's exfiltrated docs", hint: "Dropbox link" },
        { id: "NAHDA{deal_room}", description: "Access legacy deal room", hint: "admin/Admin@123" },
        { id: "NAHDA{wire_transfer}", description: "Complete fraudulent wire", hint: "Deal room templates" },
        { id: "NAHDA{insider_detected}", description: "Defensive: detect insider", hint: "SIEM alert" }
    ],
    commands: {
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.128/27';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            let hosts = scenario.network.hosts;
            let matchedHosts = [];
            if (target === '203.0.113.128/27' || target === '203.0.113.128') matchedHosts = hosts;
            else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }
            if (matchedHosts.length === 0) return `nmap: scan for ${target} not found.`;
            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os}\nPORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    output += `${String(service.port).padStart(5)}/${service.protocol}  open   ${service.service}\n`;
                });
            });
            return output;
        },
        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('pulse')) return `[+] Exploit: Pulse Secure CVE-2019-11510\n    Use: /dana-na/../auth.cgi\n    Read /etc/passwd`;
            if (keyword.includes('sip')) return `[+] SIP extensions: 1001, 1002 weak`;
            return `searchsploit: try 'pulse' or 'sip'`;
        },
        hydra: function(args, scenario, helpers) {
            return `[+] Hydra on dealroom.alnahdacapital.ae\n[+] Found: admin / Admin@123\n[+] Flag: NAHDA{deal_room}`;
        },
        msfconsole: function(args, scenario, helpers) {
            return `[+] Metasploit\nmsf6 > use exploit/linux/http/pulse_secure\nmsf6 > set RHOSTS 203.0.113.129\nmsf6 > run\n[*] VPN session stolen!\n[+] Flag: NAHDA{pulse_vpn}`;
        },
        // ... other commands
        enum4linux: function(args, scenario, helpers) { return 'enum4linux: SMB not exposed.'; },
        smbclient: function(args, scenario, helpers) { return 'smbclient: SMB not exposed.'; },
        sqlmap: function(args, scenario, helpers) { return 'sqlmap: No SQLi targets found.'; },
        wpscan: function(args, scenario, helpers) { return 'wpscan: No WordPress found.'; },
        xfreerdp: function(args, scenario, helpers) { return 'xfreerdp: RDP not exposed.'; },
        gobuster: function(args, scenario, helpers) {
            return `[+] Found: /dealroom (basic auth)\n[+] Found: /investor (IDOR)\n[+] Found: /dana-na (Pulse VPN)`;
        },
        theHarvester: function(args, scenario, helpers) {
            return `[+] Found emails:\n    ralmansoor@alnahdacapital.ae\n    lfischer@alnahdacapital.ae\n    knassar@alnahdacapital.ae\n    sosei@alnahdacapital.ae\n    yrahman@alnahdacapital.ae`;
        },
        shodan: function(args, scenario, helpers) {
            return `[+] Shodan results:\n    203.0.113.129:443 - Pulse Secure VPN (CVE-2019-11510)\n    203.0.113.130:5060 - SIP PBX (weak extensions)`;
        }
    }
};

function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) result.flags[parts[0]] = parts[1];
            else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else if (arg.startsWith('-')) {
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) result.flags['-' + c] = true;
                    }
                } else result.flags[name] = value || true;
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else result.remaining.push(arg);
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 5) throw new Error("Scenario 5 failed registration");
window.SCENARIO_LIBRARY[5] = window.SCENARIO;
window.SCENARIO = null;
})();

/* SCENARIO 6: plan-06.js */
(function() {
// scenario-p6.js — Rede Vida Hospital Network
window.SCENARIO = {
    id: 6,

    name: "Rede Vida Saúde S.A.",
    welcomeMessage: "🔒 Target: 203.0.113.144/27 — Apache Struts, PACS, Citrix, CCTV, vendor VPN",
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },
    network: {
        subnets: [
            { cidr: "203.0.113.144/27", description: "Public IP range" },
            { cidr: "10.60.0.0/12", description: "Internal network" }
        ],
        hosts: [
            {
                ip: "203.0.113.144",
                hostname: "www.redevida.com.br",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "WordPress", version: "5.2" }
                ],
                vulnerabilities: [
                    { id: "Revslider", name: "Revslider vulnerable", description: "WordPress plugin RCE", exploit: "wpscan" }
                ]
            },
            {
                ip: "203.0.113.145",
                hostname: "patient.redevida.com.br",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Patient Portal", version: "1.0" }
                ],
                vulnerabilities: [
                    { id: "SQLi", name: "SQL injection", description: "Patient portal SQLi", exploit: "sqlmap" }
                ]
            },
            {
                ip: "203.0.113.146",
                hostname: "vidalab.com.br",
                os: "Ubuntu 18.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Apache Struts", version: "2.3" }
                ],
                vulnerabilities: [
                    { id: "CVE-2017-5638", name: "Apache Struts RCE", description: "Remote code execution", exploit: "Metasploit" }
                ]
            },
            {
                ip: "203.0.113.149",
                hostname: "cctv.redevida.com.br",
                os: "Linux (Hikvision)",
                services: [
                    { port: 8080, protocol: "tcp", service: "http", product: "Hikvision CCTV", version: "V5.5.0" }
                ]
            },
            {
                ip: "203.0.113.150",
                hostname: "pacs.redevida.com.br",
                os: "Windows Server 2019",
                services: [
                    { port: 8042, protocol: "tcp", service: "http", product: "Orthanc PACS", version: "1.9.0" }
                ],
                vulnerabilities: [
                    { id: "Orthanc-Default", name: "Default Orthanc Credentials", description: "orthanc / orthanc", exploit: "browser" }
                ]
            }
        ]
    },
    users: [
        { username: "asouza", password: "Hospital2023!", email: "asouza@redevida.com.br", role: "Chief Medical Officer", osint: "Twitter posts photos with badge" },
        { username: "cmendes", password: "Hospital2023!", email: "cmendes@redevida.com.br", role: "CIO", osint: "LinkedIn article about security" },
        { username: "jcosta", password: "Hospital2023!", email: "jcosta@redevida.com.br", role: "Head Nurse", osint: "Facebook posts sharing workstation password" },
        { username: "balmeida", password: "Hospital2023!", email: "balmeida@redevida.com.br", role: "BioMed Engineer", osint: "GitHub has DICOM server scripts" },
        { username: "flima", password: "Hospital2023!", email: "flima@redevida.com.br", role: "HR", osint: "Job postings for nurses" },
        { username: "biomed", password: "Biomed@2023", role: "Citrix Admin", osint: "Shared Citrix credentials" },
        { username: "orthanc", password: "orthanc", role: "PACS Admin", osint: "Default Orthanc" }
    ],
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", ".bashrc"],
        "/home/kali/Desktop": ["notes.txt", "struts_exploit.txt"],
        "/etc": ["hosts", "passwd", "hostname"],
        "/tmp": []
    },
    fileContents: {
        "/home/kali/Desktop/notes.txt": "Rede Vida targets:\n- Apache Struts: vidalab.com.br/lis (CVE-2017-5638).\n- PACS: 203.0.113.150:8042 has an Orthanc default-credential lead.\n- Citrix: citrix.redevida.com.br has a credential lead.\n- Patient portal: SQLi lead.\n- CCTV: 203.0.113.149:8080.\n- Confirm objective evidence through the relevant tool.",
        "/home/kali/Desktop/struts_exploit.txt": "CVE-2017-5638 exploit:\n1. POST /lis/login.action\n2. Content-Type: %{(#_='multipart/form-data')...}\n3. Get shell",
        "/etc/hostname": "proto",
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nkali:x:1000:1000:Kali:/home/kali:/bin/bash"
    },
    flags: [
        { id: "REDE{network_seg_bypass}", description: "Pivot from lab to hospital", hint: "Struts to PACS" },
        { id: "REDE{patient_db}", description: "Access patient database", hint: "Domain Admin" },
        { id: "REDE{domain_admin}", description: "Compromise domain controller", hint: "Citrix shared creds" },
        { id: "REDE{medical_iot}", description: "Access or disrupt a medical device", hint: "Medical IoT" }
    ],
    commands: {
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.144/27';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            let hosts = scenario.network.hosts;
            let matchedHosts = [];
            if (target === '203.0.113.144/27' || target === '203.0.113.144') matchedHosts = hosts;
            else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }
            if (matchedHosts.length === 0) return `nmap: scan for ${target} not found.`;
            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os}\nPORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    output += `${String(service.port).padStart(5)}/${service.protocol}  open   ${service.service}\n`;
                });
            });
            return output;
        },
        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('struts')) return `[+] Exploit: Apache Struts CVE-2017-5638\n    use exploit/multi/http/struts2_content_type_ognl`;
            if (keyword.includes('orthanc')) return `[+] Orthanc default creds: orthanc/orthanc`;
            if (keyword.includes('revslider')) return `[+] Revslider WordPress plugin RCE`;
            return `searchsploit: try 'struts', 'orthanc', or 'revslider'`;
        },
        wpscan: function(args, scenario, helpers) {
            return `[+] WordPress 5.2 detected\n[+] Vulnerable plugin: revslider (RCE)\n[+] Found /wp-login.php`;
        },
        sqlmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            if (parsed.targets.some(t => t.includes('patient'))) {
                return `[+] SQLMap on patient.redevida.com.br\n[+] Extracted patient database\n[+] Flag: REDE{patient_db}`;
            }
            return `sqlmap: use target /patient-portal`;
        },
        hydra: function(args, scenario, helpers) {
            return `[+] Hydra on citrix.redevida.com.br\n[+] Found: biomed / Biomed@2023\n[+] Flag: REDE{domain_admin}`;
        },
        msfconsole: function(args, scenario, helpers) {
            return `[+] Metasploit\nmsf6 > use exploit/multi/http/struts2_content_type_ognl\nmsf6 > set RHOSTS 203.0.113.146\nmsf6 > run\n[*] Shell obtained!\n[+] Flag: REDE{network_seg_bypass}`;
        },
        // ... other commands
        enum4linux: function(args, scenario, helpers) { return 'enum4linux: SMB not exposed.'; },
        smbclient: function(args, scenario, helpers) { return 'smbclient: SMB not exposed.'; },
        xfreerdp: function(args, scenario, helpers) { return 'xfreerdp: RDP not exposed.'; },
        gobuster: function(args, scenario, helpers) {
            return `[+] Found: /lis (Struts)\n[+] Found: /pacs (Orthanc)\n[+] Found: /citrix\n[+] Found: /patient-portal (SQLi)`;
        },
        theHarvester: function(args, scenario, helpers) {
            return `[+] Found emails:\n    asouza@redevida.com.br\n    cmendes@redevida.com.br\n    jcosta@redevida.com.br\n    balmeida@redevida.com.br\n    flima@redevida.com.br`;
        },
        shodan: function(args, scenario, helpers) {
            return `[+] Shodan results:\n    203.0.113.146:443 - Apache Struts (CVE-2017-5638)\n    203.0.113.150:8042 - Orthanc PACS (default creds)\n    203.0.113.149:8080 - Hikvision CCTV`;
        }
    }
};

function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) result.flags[parts[0]] = parts[1];
            else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else if (arg.startsWith('-')) {
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) result.flags['-' + c] = true;
                    }
                } else result.flags[name] = value || true;
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else result.remaining.push(arg);
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 6) throw new Error("Scenario 6 failed registration");
window.SCENARIO_LIBRARY[6] = window.SCENARIO;
window.SCENARIO = null;
})();

/* SCENARIO 7: plan-07.js */
(function() {
// scenario-p7.js — Hanul Logistics & Manufacturing
window.SCENARIO = {
    id: 7,

    name: "Hanul Group Co., Ltd.",
    welcomeMessage: "🔒 Target: 203.0.113.160/27 — OT networks, OPC UA, crane HMI, vendor VPN",
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },
    network: {
        subnets: [
            { cidr: "203.0.113.160/27", description: "Public IP range" },
            { cidr: "10.70.0.0/16", description: "Internal IT network" },
            { cidr: "10.71.0.0/16", description: "OT/ICS network" }
        ],
        hosts: [
            {
                ip: "203.0.113.160",
                hostname: "www.hanulgroup.kr",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Static Site", version: "Nginx" }
                ]
            },
            {
                ip: "203.0.113.161",
                hostname: "vendor.hanulgroup.kr",
                os: "Fortinet",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Vendor VPN", version: "6.0" }
                ],
                vulnerabilities: [
                    { id: "Vendor-Shared", name: "Shared Vendor Credentials", description: "vendor / HanulVendor!2024", exploit: "VPN login" }
                ]
            },
            {
                ip: "203.0.113.162",
                hostname: "port.hanulgroup.kr",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Port Tracking", version: "1.0" }
                ],
                vulnerabilities: [
                    { id: "SQLi", name: "SQL injection in tracking", description: "/track?container=123", exploit: "sqlmap" }
                ]
            }
        ],
        otHosts: [
            {
                ip: "10.71.1.10",
                hostname: "crane-hmi",
                os: "Linux (PLC)",
                services: [
                    { port: 80, protocol: "tcp", service: "http", product: "Crane HMI", version: "Web" }
                ],
                vulnerabilities: [
                    { id: "Crane-Default", name: "Default Crane Credentials", description: "admin / admin", exploit: "browser" }
                ]
            },
            {
                ip: "10.71.2.25",
                hostname: "scada-historian",
                os: "Windows Server 2016",
                services: [
                    { port: 4840, protocol: "tcp", service: "opcua", product: "OPC UA Server", version: "1.4" }
                ],
                vulnerabilities: [
                    { id: "OPC-Anon", name: "Anonymous OPC UA Access", description: "No authentication", exploit: "opcua-client" }
                ]
            }
        ]
    },
    users: [
        { username: "mpark", password: "Hanul2024!", email: "mpark@hanulgroup.kr", role: "CISO", osint: "Security conference speaker" },
        { username: "jlee", password: "Hanul2024!", email: "jlee@hanulgroup.kr", role: "OT Engineer", osint: "Instagram photo of SCADA screen" },
        { username: "skim", password: "Hanul2024!", email: "skim@hanulgroup.kr", role: "HR Manager", osint: "Job postings for temp workers" },
        { username: "dchoi", password: "Hanul2024!", email: "dchoi@hanulgroup.kr", role: "Port Operations Manager", osint: "Voicemail mentions crane PLC" },
        { username: "vendor", password: "HanulVendor!2024", role: "Vendor Account", osint: "Shared with multiple vendors" }
    ],
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", ".bashrc"],
        "/home/kali/Desktop": ["notes.txt", "ot_map.txt"],
        "/etc": ["hosts", "passwd", "hostname"],
        "/tmp": []
    },
    fileContents: {
        "/home/kali/Desktop/notes.txt": "Hanul targets:\n- Vendor VPN: vendor.hanulgroup.kr has a shared-credential lead.\n- Crane HMI: 10.71.1.10:80 has a default-credential lead.\n- OPC UA: 10.71.2.25:4840 allows anonymous access.\n- Port tracking: SQLi lead.\n- Confirm objective evidence through the relevant tool.",
        "/home/kali/Desktop/ot_map.txt": "OT Network Map:\n10.71.1.0/24 - Port operations (cranes, PLCs)\n10.71.2.0/24 - Battery manufacturing (SCADA)\n10.71.3.0/24 - Freight",
        "/etc/hostname": "proto",
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nkali:x:1000:1000:Kali:/home/kali:/bin/bash"
    },
    flags: [
        { id: "HANUL{ot_access}", description: "Access OT network", hint: "Vendor VPN" },
        { id: "HANUL{shipping_manifest}", description: "Exfiltrate port manifests", hint: "SQLi in tracking" },
        { id: "HANUL{battery_ip}", description: "Steal battery manufacturing IP", hint: "OPC UA anonymous" },
        { id: "HANUL{ransomware_contained}", description: "Defensive: stop ransomware in OT", hint: "OT monitoring" }
    ],
    commands: {
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.160/27';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            let hosts = scenario.network.hosts;
            let matchedHosts = [];
            if (target === '203.0.113.160/27' || target === '203.0.113.160') matchedHosts = hosts;
            else if (target === '10.71.1.0/24' || target === '10.71.1.10') matchedHosts = scenario.otHosts || [];
            else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }
            if (matchedHosts.length === 0) return `nmap: scan for ${target} not found.`;
            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os}\nPORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    output += `${String(service.port).padStart(5)}/${service.protocol}  open   ${service.service}\n`;
                });
            });
            return output;
        },
        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('opc')) return `[+] OPC UA anonymous access\n    Use: opcua-client to connect`;
            if (keyword.includes('crane')) return `[+] Crane HMI default creds: admin/admin`;
            if (keyword.includes('sql')) return `[+] SQLi in port tracking: /track?container=123`;
            return `searchsploit: try 'opc', 'crane', or 'sql'`;
        },
        sqlmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            if (parsed.targets.some(t => t.includes('track'))) {
                return `[+] SQLMap on port.hanulgroup.kr/track\n[+] Extracted shipping manifests\n[+] Flag: HANUL{shipping_manifest}`;
            }
            return `sqlmap: use target /track?container=123`;
        },
        hydra: function(args, scenario, helpers) {
            return `[+] Hydra on vendor VPN\n[+] Found: vendor / HanulVendor!2024\n[+] Flag: HANUL{ot_access}`;
        },
        // ... other commands
        enum4linux: function(args, scenario, helpers) { return 'enum4linux: SMB not exposed.'; },
        smbclient: function(args, scenario, helpers) { return 'smbclient: SMB not exposed.'; },
        wpscan: function(args, scenario, helpers) { return 'wpscan: No WordPress found.'; },
        xfreerdp: function(args, scenario, helpers) { return 'xfreerdp: RDP not exposed.'; },
        gobuster: function(args, scenario, helpers) {
            return `[+] Found: /vendor\n[+] Found: /track (SQLi)\n[+] Found: /crane (HMI)`;
        },
        msfconsole: function(args, scenario, helpers) {
            return `[+] Metasploit\nmsf6 > use auxiliary/scanner/scada/modbus_finder\nmsf6 > set RHOSTS 10.71.1.0/24\nmsf6 > run\n[*] Found OT devices\n[+] Flag: HANUL{ot_access}`;
        },
        theHarvester: function(args, scenario, helpers) {
            return `[+] Found emails:\n    mpark@hanulgroup.kr\n    jlee@hanulgroup.kr\n    skim@hanulgroup.kr\n    dchoi@hanulgroup.kr`;
        },
        shodan: function(args, scenario, helpers) {
            return `[+] Shodan results:\n    203.0.113.161:443 - Vendor VPN (shared creds)\n    10.71.2.25:4840 - OPC UA (anonymous)`;
        }
    }
};

function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) result.flags[parts[0]] = parts[1];
            else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else if (arg.startsWith('-')) {
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) result.flags['-' + c] = true;
                    }
                } else result.flags[name] = value || true;
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else result.remaining.push(arg);
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 7) throw new Error("Scenario 7 failed registration");
window.SCENARIO_LIBRARY[7] = window.SCENARIO;
window.SCENARIO = null;
})();

/* SCENARIO 8: plan-08.js */
(function() {
// scenario-p8.js — Borealis Energy Group
window.SCENARIO = {
    id: 8,

    name: "Borealis Energy Group ASA",
    welcomeMessage: "🔒 Target: 203.0.113.192/27 — Grafana, vendor portal, SCADA, SNMP",
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },
    network: {
        subnets: [
            { cidr: "203.0.113.192/27", description: "Public IP range" },
            { cidr: "10.80.0.0/12", description: "Internal network" }
        ],
        hosts: [
            {
                ip: "203.0.113.192",
                hostname: "www.borealisenergy.com",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Static Site", version: "Nginx" }
                ]
            },
            {
                ip: "203.0.113.196",
                hostname: "grafana.borealisenergy.com",
                os: "Ubuntu 20.04",
                services: [
                    { port: 3000, protocol: "tcp", service: "http", product: "Grafana", version: "8.3" }
                ],
                vulnerabilities: [
                    { id: "Grafana-Anon", name: "Grafana Anonymous Read", description: "SCADA dashboards exposed", exploit: "browser" }
                ]
            },
            {
                ip: "203.0.113.197",
                hostname: "vendor.borealisenergy.com",
                os: "Fortinet",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Vendor Portal", version: "6.0" }
                ],
                vulnerabilities: [
                    { id: "Vendor-Default", name: "Default Vendor Credentials", description: "vendor / BorealisVendor!2024", exploit: "browser" }
                ]
            },
            {
                ip: "203.0.113.198",
                hostname: "files.borealisenergy.com",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "File Share", version: "Nginx" }
                ],
                vulnerabilities: [
                    { id: "Public-Share", name: "Public Document Share", description: "Network diagrams exposed", exploit: "browser" }
                ]
            }
        ],
        otHosts: [
            {
                ip: "10.80.3.25",
                hostname: "scada-controller",
                os: "Linux",
                services: [
                    { port: 161, protocol: "udp", service: "snmp", product: "SNMP", version: "2c" }
                ],
                vulnerabilities: [
                    { id: "SNMP-Public", name: "SNMP Public Community", description: "community: public", exploit: "snmpwalk" },
                    { id: "SNMP-Private", name: "SNMP Private Community", description: "community: private (write)", exploit: "snmpwalk" }
                ]
            }
        ]
    },
    users: [
        { username: "lberg", password: "Borealis2024!", email: "lberg@borealisenergy.com", role: "CIO", osint: "Security conference speaker" },
        { username: "iolsen", password: "Borealis2024!", email: "iolsen@borealisenergy.com", role: "OT Security Lead", osint: "Blog about OT security" },
        { username: "ehansen", password: "Borealis2024!", email: "ehansen@borealisenergy.com", role: "Grid Operations", osint: "LinkedIn photos of control room" },
        { username: "egarcia", password: "Borealis2024!", email: "egarcia@borealisenergy.com", role: "Solar Plant Engineer", osint: "GitHub has SCADA configs" },
        { username: "vendor", password: "BorealisVendor!2024", role: "Vendor Account", osint: "Shared, static password" }
    ],
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", ".bashrc"],
        "/home/kali/Desktop": ["notes.txt", "snmp.txt"],
        "/etc": ["hosts", "passwd", "hostname"],
        "/tmp": []
    },
    fileContents: {
        "/home/kali/Desktop/notes.txt": "Borealis targets:\n- Grafana: 203.0.113.196:3000 allows anonymous read.\n- Vendor portal: vendor.borealisenergy.com has a shared-credential lead.\n- SNMP: 10.80.3.25:161 exposes public/private community clues.\n- Document share: public network diagrams.\n- Confirm objective evidence through the relevant tool.",
        "/home/kali/Desktop/snmp.txt": "SNMP communities:\npublic - read-only\nprivate - read-write\nOIDs: 1.3.6.1.2.1.2.2.1 - interface table",
        "/etc/hostname": "proto",
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nkali:x:1000:1000:Kali:/home/kali:/bin/bash"
    },
    flags: [
        { id: "BOREALIS{grafana_dash}", description: "Access Grafana", hint: "Anonymous read on port 3000" },
        { id: "BOREALIS{scada_snmp}", description: "Use SNMP to control a device", hint: "SNMP private community" },
        { id: "BOREALIS{wind_farm}", description: "Access wind farm control", hint: "SCADA dashboards" },
        { id: "BOREALIS{vendor_portal}", description: "Compromise vendor portal", hint: "default creds" }
    ],
    commands: {
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.192/27';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            let hosts = scenario.network.hosts;
            let matchedHosts = [];
            if (target === '203.0.113.192/27' || target === '203.0.113.192') matchedHosts = hosts;
            else if (target === '10.80.3.25') matchedHosts = scenario.otHosts || [];
            else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }
            if (matchedHosts.length === 0) return `nmap: scan for ${target} not found.`;
            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os}\nPORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    output += `${String(service.port).padStart(5)}/${service.protocol}  open   ${service.service}\n`;
                });
            });
            return output;
        },
        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('grafana')) return `[+] Grafana anonymous read\n    URL: http://203.0.113.196:3000/dashboards`;
            if (keyword.includes('snmp')) return `[+] SNMP public community: public\n    Use: snmpwalk -v2c -c public 10.80.3.25`;
            if (keyword.includes('vendor')) return `[+] Vendor portal: vendor/BorealisVendor!2024`;
            return `searchsploit: try 'grafana', 'snmp', or 'vendor'`;
        },
        hydra: function(args, scenario, helpers) {
            return `[+] Hydra on vendor.borealisenergy.com\n[+] Found: vendor / BorealisVendor!2024\n[+] Flag: BOREALIS{vendor_portal}`;
        },
        // ... other commands
        enum4linux: function(args, scenario, helpers) { return 'enum4linux: SMB not exposed.'; },
        smbclient: function(args, scenario, helpers) { return 'smbclient: SMB not exposed.'; },
        wpscan: function(args, scenario, helpers) { return 'wpscan: No WordPress found.'; },
        sqlmap: function(args, scenario, helpers) { return 'sqlmap: No SQLi targets found.'; },
        xfreerdp: function(args, scenario, helpers) { return 'xfreerdp: RDP not exposed.'; },
        gobuster: function(args, scenario, helpers) {
            return `[+] Found: /dashboards (Grafana)\n[+] Found: /vendor\n[+] Found: /public (document share)`;
        },
        msfconsole: function(args, scenario, helpers) {
            return `[+] Metasploit\nmsf6 > use auxiliary/scanner/snmp/snmp_enum\nmsf6 > set RHOSTS 10.80.3.25\nmsf6 > run\n[*] SNMP data extracted\n[+] Flag: BOREALIS{scada_snmp}`;
        },
        theHarvester: function(args, scenario, helpers) {
            return `[+] Found emails:\n    lberg@borealisenergy.com\n    iolsen@borealisenergy.com\n    ehansen@borealisenergy.com\n    egarcia@borealisenergy.com`;
        },
        shodan: function(args, scenario, helpers) {
            return `[+] Shodan results:\n    203.0.113.196:3000 - Grafana (anonymous read)\n    10.80.3.25:161 - SNMP (public/private)`;
        }
    }
};

function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) result.flags[parts[0]] = parts[1];
            else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else if (arg.startsWith('-')) {
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) result.flags['-' + c] = true;
                    }
                } else result.flags[name] = value || true;
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else result.remaining.push(arg);
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 8) throw new Error("Scenario 8 failed registration");
window.SCENARIO_LIBRARY[8] = window.SCENARIO;
window.SCENARIO = null;
})();

/* SCENARIO 9: plan-09.js */
(function() {
// scenario-p9.js — Aurora Media & Entertainment
window.SCENARIO = {
    id: 9,

    name: "Aurora Media & Entertainment Group",
    welcomeMessage: "🔒 Target: 203.0.113.208/27 — S3 bucket, AWS role, GitHub, streaming API",
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },
    network: {
        subnets: [
            { cidr: "203.0.113.208/27", description: "Public IP range" },
            { cidr: "10.90.0.0/12", description: "Internal network" }
        ],
        hosts: [
            {
                ip: "203.0.113.208",
                hostname: "www.auroramedia.com",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Static Site", version: "Nginx" }
                ]
            },
            {
                ip: "203.0.113.209",
                hostname: "api.stream.auroramedia.com",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Streaming API", version: "Node.js" }
                ],
                vulnerabilities: [
                    { id: "API-Key", name: "API key in mobile app", description: "Leaked in decompiled app", exploit: "curl" }
                ]
            },
            {
                ip: "203.0.113.210",
                hostname: "wiki.auroramedia.com",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Confluence", version: "7.12" }
                ],
                vulnerabilities: [
                    { id: "Confluence-Anon", name: "Anonymous space", description: "One space public", exploit: "browser" }
                ]
            }
        ]
    },
    users: [
        { username: "ohayes", password: "Aurora2024!", email: "ohayes@auroramedia.com", role: "CISO", osint: "Security conference speaker" },
        { username: "jtanaka", password: "Aurora2024!", email: "jtanaka@auroramedia.com", role: "VP Engineering", osint: "GitHub profile with AWS role" },
        { username: "smartinez", password: "Aurora2024!", email: "smartinez@auroramedia.com", role: "Film Producer", osint: "Instagram story shows editing suite" },
        { username: "dkim", password: "Aurora2024!", email: "dkim@auroramedia.com", role: "DevOps", osint: "Pasted AWS secret in Slack" },
        { username: "aurora-temp", password: "AuroraTemp!2024", role: "Freelancer Account", osint: "Default password, no MFA" }
    ],
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", ".bashrc"],
        "/home/kali/Desktop": ["notes.txt", "aws_keys.txt"],
        "/etc": ["hosts", "passwd", "hostname"],
        "/tmp": []
    },
    fileContents: {
        "/home/kali/Desktop/notes.txt": "Aurora targets:\n- S3 bucket: aurora-media-assets is publicly readable.\n- GitHub: public repo exposes an AWS-role lead.\n- AWS role has broad S3/Lambda permissions; verify scope from the repo evidence.\n- Freelancer account has a credential-reuse lead.\n- Confirm objective evidence through the relevant tool.",
        "/home/kali/Desktop/aws_keys.txt": "AWS_ACCESS_KEY_ID: AKIA...\nAWS_SECRET_ACCESS_KEY: ...\narn:aws:iam::123456789012:role/aurora-github-runner",
        "/etc/hostname": "proto",
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nkali:x:1000:1000:Kali:/home/kali:/bin/bash"
    },
    flags: [
        { id: "AURORA{s3_public}", description: "Exfiltrate public S3", hint: "aurora-media-assets" },
        { id: "AURORA{aws_role}", description: "Abuse over-privileged role", hint: "GitHub runner role" },
        { id: "AURORA{unreleased_media}", description: "Access unreleased film/music", hint: "S3 bucket" },
        { id: "AURORA{source_code}", description: "Access streaming source code", hint: "GitHub" }
    ],
    commands: {
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.208/27';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            let hosts = scenario.network.hosts;
            let matchedHosts = [];
            if (target === '203.0.113.208/27' || target === '203.0.113.208') matchedHosts = hosts;
            else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }
            if (matchedHosts.length === 0) return `nmap: scan for ${target} not found.`;
            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os}\nPORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    output += `${String(service.port).padStart(5)}/${service.protocol}  open   ${service.service}\n`;
                });
            });
            return output;
        },
        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('s3')) return `[+] S3 bucket public: aurora-media-assets\n    Use: aws s3 ls s3://aurora-media-assets/ --no-sign-request`;
            if (keyword.includes('aws')) return `[+] AWS role over-privileged\n    arn:aws:iam::123456789012:role/aurora-github-runner`;
            return `searchsploit: try 's3' or 'aws'`;
        },
        hydra: function(args, scenario, helpers) {
            return `[+] Hydra on freelancer VPN\n[+] Found: aurora-temp / AuroraTemp!2024\n[+] Flag: AURORA{unreleased_media}`;
        },
        // ... other commands
        enum4linux: function(args, scenario, helpers) { return 'enum4linux: SMB not exposed.'; },
        smbclient: function(args, scenario, helpers) { return 'smbclient: SMB not exposed.'; },
        wpscan: function(args, scenario, helpers) { return 'wpscan: No WordPress found.'; },
        sqlmap: function(args, scenario, helpers) { return 'sqlmap: No SQLi targets found.'; },
        xfreerdp: function(args, scenario, helpers) { return 'xfreerdp: RDP not exposed.'; },
        gobuster: function(args, scenario, helpers) {
            return `[+] Found: /api (streaming)\n[+] Found: /wiki (Confluence)\n[+] Found: /s3 (bucket listing)`;
        },
        msfconsole: function(args, scenario, helpers) {
            return `[+] Metasploit\nmsf6 > use auxiliary/cloud/aws/enum_iam\nmsf6 > set ROLE arn:aws:iam::123456789012:role/aurora-github-runner\nmsf6 > run\n[*] Enumerated S3 buckets\n[+] Flag: AURORA{aws_role}`;
        },
        theHarvester: function(args, scenario, helpers) {
            return `[+] Found emails:\n    ohayes@auroramedia.com\n    jtanaka@auroramedia.com\n    smartinez@auroramedia.com\n    dkim@auroramedia.com`;
        },
        shodan: function(args, scenario, helpers) {
            return `[+] Shodan results:\n    203.0.113.209:443 - Streaming API\n    203.0.113.210:443 - Confluence (anonymous space)`;
        }
    }
};

function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) result.flags[parts[0]] = parts[1];
            else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else if (arg.startsWith('-')) {
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) result.flags['-' + c] = true;
                    }
                } else result.flags[name] = value || true;
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else result.remaining.push(arg);
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 9) throw new Error("Scenario 9 failed registration");
window.SCENARIO_LIBRARY[9] = window.SCENARIO;
window.SCENARIO = null;
})();

/* SCENARIO 10: plan-10.js */
(function() {
// scenario-p10.js — Meridian Global Shipping
window.SCENARIO = {
    id: 10,

    name: "Meridian Global Shipping Ltd",
    welcomeMessage: "🔒 Target: 203.0.113.224/27 — EDI, tracking, satellite, crane HMI, vendor VPN",
    env: {
        PS1: "Protocol Breach@proto:\\w$ ",
        PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        HOME: "/home/kali",
        USER: "kali",
        SHELL: "/bin/bash",
        TERM: "xterm-256color"
    },
    network: {
        subnets: [
            { cidr: "203.0.113.224/27", description: "Public IP range" },
            { cidr: "10.100.0.0/12", description: "Internal network" }
        ],
        hosts: [
            {
                ip: "203.0.113.224",
                hostname: "www.meridianglobal.com",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Static Site", version: "Nginx" }
                ]
            },
            {
                ip: "203.0.113.225",
                hostname: "edi.meridianglobal.com",
                os: "Windows Server 2016",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "AS2 Gateway", version: "Legacy" }
                ],
                vulnerabilities: [
                    { id: "EDI-Default", name: "Default Admin Credentials", description: "admin / admin", exploit: "browser" }
                ]
            },
            {
                ip: "203.0.113.226",
                hostname: "track.meridianglobal.com",
                os: "Ubuntu 20.04",
                services: [
                    { port: 443, protocol: "tcp", service: "https", product: "Tracking Portal", version: "Legacy" }
                ],
                vulnerabilities: [
                    { id: "SQLi", name: "SQL injection in tracking", description: "/track?container=123", exploit: "sqlmap" }
                ]
            },
            {
                ip: "203.0.113.227",
                hostname: "legacy-dmz",
                os: "Windows Server 2008",
                services: [
                    { port: 3389, protocol: "tcp", service: "rdp", product: "Microsoft RDP", version: "6.1" }
                ],
                vulnerabilities: [
                    { id: "Win2008", name: "Windows 2008 RDP", description: "Legacy OS, weak RDP", exploit: "hydra, xfreerdp" }
                ]
            }
        ],
        otHosts: [
            {
                ip: "10.100.8.20",
                hostname: "satellite-terminal",
                os: "Linux",
                services: [
                    { port: 8080, protocol: "tcp", service: "http", product: "Satellite Terminal", version: "Web" }
                ],
                vulnerabilities: [
                    { id: "Satellite-Default", name: "Default Satellite Credentials", description: "admin / admin", exploit: "browser" }
                ]
            },
            {
                ip: "10.100.9.10",
                hostname: "crane-hmi",
                os: "Linux (PLC)",
                services: [
                    { port: 80, protocol: "tcp", service: "http", product: "Crane HMI", version: "Web" }
                ],
                vulnerabilities: [
                    { id: "Crane-Default", name: "Default Crane Credentials", description: "admin / admin", exploit: "browser" }
                ]
            }
        ]
    },
    users: [
        { username: "wliang", password: "Meridian2024!", email: "wliang@meridianglobal.com", role: "Global CISO", osint: "No OSINT leaks" },
        { username: "arahman", password: "Meridian2024!", email: "arahman@meridianglobal.com", role: "SOC Lead", osint: "Blog on AI threat hunting" },
        { username: "tsato", password: "Meridian2024!", email: "tsato@meridianglobal.com", role: "OT Engineer", osint: "Instagram photo of crane control" },
        { username: "hpapadopoulos", password: "Meridian2024!", email: "hpapadopoulos@meridianglobal.com", role: "Shipping Ops", osint: "LinkedIn post about EDI upgrade" },
        { username: "admin", password: "admin", role: "EDI Admin", osint: "Default EDI credentials" },
        { username: "service", password: "MeridianService!2023", role: "Vendor Account", osint: "Backdoor credentials" }
    ],
    filesystem: {
        "/": ["home", "etc", "var", "tmp", "root", "opt"],
        "/home": ["kali"],
        "/home/kali": ["Desktop", "Documents", ".bashrc"],
        "/home/kali/Desktop": ["notes.txt", "edi.txt"],
        "/etc": ["hosts", "passwd", "hostname"],
        "/tmp": []
    },
    fileContents: {
        "/home/kali/Desktop/notes.txt": "Meridian targets:\n- EDI: edi.meridianglobal.com has a default-credential lead.\n- Tracking: SQLi lead.\n- Satellite: 10.100.8.20:8080 has a default-credential lead.\n- Crane HMI: 10.100.9.10:80 has a default-credential lead.\n- Vendor VPN: shared-credential lead.\n- Legacy DMZ: 203.0.113.227:3389 exposes RDP.\n- Confirm objective evidence through the relevant tool.",
        "/home/kali/Desktop/edi.txt": "AS2 Gateway:\nadmin/admin\nEDI messages contain shipping manifests",
        "/etc/hostname": "proto",
        "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nkali:x:1000:1000:Kali:/home/kali:/bin/bash"
    },
    flags: [
        { id: "MERIDIAN{edi_backdoor}", description: "Access EDI", hint: "admin/admin on EDI gateway" },
        { id: "MERIDIAN{crane_ot}", description: "Control crane PLC", hint: "Crane HMI default creds" },
        { id: "MERIDIAN{satellite}", description: "Access satellite terminal", hint: "admin/admin on satellite" },
        { id: "MERIDIAN{manifest_data}", description: "Exfiltrate manifests", hint: "SQLi in tracking" },
        { id: "MERIDIAN{zero_trust_bypass}", description: "Pivot from IT to OT", hint: "Vendor VPN" }
    ],
    commands: {
        nmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            let target = parsed.targets[0] || '203.0.113.224/27';
            let output = `Starting Nmap 7.92 at ${new Date().toLocaleTimeString()}\n`;
            let hosts = scenario.network.hosts;
            let matchedHosts = [];
            if (target === '203.0.113.224/27' || target === '203.0.113.224') matchedHosts = hosts;
            else if (target === '10.100.8.20' || target === '10.100.9.10') matchedHosts = scenario.otHosts || [];
            else {
                const host = hosts.find(h => h.ip === target);
                if (host) matchedHosts = [host];
            }
            if (matchedHosts.length === 0) return `nmap: scan for ${target} not found.`;
            matchedHosts.forEach(host => {
                output += `\nNmap scan report for ${host.ip} (${host.hostname})\n`;
                output += `Host is up (0.0012s latency).\n`;
                output += `OS: ${host.os}\nPORT     STATE SERVICE\n`;
                host.services.forEach(service => {
                    output += `${String(service.port).padStart(5)}/${service.protocol}  open   ${service.service}\n`;
                });
            });
            return output;
        },
        searchsploit: function(args, scenario, helpers) {
            let keyword = args.join(' ');
            if (keyword.includes('edi')) return `[+] EDI gateway default creds: admin/admin\n    Use: https://edi.meridianglobal.com`;
            if (keyword.includes('satellite')) return `[+] Satellite terminal default creds: admin/admin\n    Use: http://10.100.8.20:8080`;
            if (keyword.includes('crane')) return `[+] Crane HMI default creds: admin/admin\n    Use: http://10.100.9.10:80`;
            if (keyword.includes('vendor')) return `[+] Vendor backdoor: service/MeridianService!2023`;
            return `searchsploit: try 'edi', 'satellite', 'crane', or 'vendor'`;
        },
        sqlmap: function(args, scenario, helpers) {
            const parsed = parseArgs(args);
            if (parsed.targets.some(t => t.includes('track'))) {
                return `[+] SQLMap on track.meridianglobal.com\n[+] Extracted shipping manifests\n[+] Flag: MERIDIAN{manifest_data}`;
            }
            return `sqlmap: use target /track?container=123`;
        },
        hydra: function(args, scenario, helpers) {
            return `[+] Hydra on EDI gateway\n[+] Found: admin / admin\n[+] Flag: MERIDIAN{edi_backdoor}`;
        },
        xfreerdp: function(args, scenario, helpers) {
            return `[+] xfreerdp to 203.0.113.227\n[+] Username: Administrator\n[+] Password: guessed\n[+] Access to legacy Windows 2008\n[+] Flag: MERIDIAN{zero_trust_bypass}`;
        },
        // ... other commands
        enum4linux: function(args, scenario, helpers) { return 'enum4linux: SMB not exposed.'; },
        smbclient: function(args, scenario, helpers) { return 'smbclient: SMB not exposed.'; },
        wpscan: function(args, scenario, helpers) { return 'wpscan: No WordPress found.'; },
        gobuster: function(args, scenario, helpers) {
            return `[+] Found: /edi (AS2 gateway)\n[+] Found: /track (SQLi)\n[+] Found: /vendor\n[+] Found: /crane (HMI)`;
        },
        msfconsole: function(args, scenario, helpers) {
            return `[+] Metasploit\nmsf6 > use exploit/multi/http/vendor_backdoor\nmsf6 > set RHOSTS 10.100.9.10\nmsf6 > run\n[*] Crane PLC controlled\n[+] Flag: MERIDIAN{crane_ot}`;
        },
        theHarvester: function(args, scenario, helpers) {
            return `[+] Found emails:\n    wliang@meridianglobal.com\n    arahman@meridianglobal.com\n    tsato@meridianglobal.com\n    hpapadopoulos@meridianglobal.com`;
        },
        shodan: function(args, scenario, helpers) {
            return `[+] Shodan results:\n    203.0.113.225:443 - EDI gateway (default creds)\n    10.100.8.20:8080 - Satellite terminal\n    10.100.9.10:80 - Crane HMI (default creds)`;
        }
    }
};

function parseArgs(args) {
    const result = { flags: {}, targets: [], remaining: [] };
    let i = 0;
    while (i < args.length) {
        const arg = args[i];
        if (arg.startsWith('--')) {
            const parts = arg.split('=');
            if (parts.length === 2) result.flags[parts[0]] = parts[1];
            else {
                if (i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else if (arg.startsWith('-')) {
            if (arg.length > 2 && !arg.includes('=')) {
                const name = arg.substring(0, 2);
                const value = arg.substring(2);
                if (value && !value.match(/^[0-9]+$/)) {
                    result.flags[name] = true;
                    for (let j = 2; j < arg.length; j++) {
                        const c = arg[j];
                        if (c.match(/[a-zA-Z]/)) result.flags['-' + c] = true;
                    }
                } else result.flags[name] = value || true;
            } else {
                if (arg.length === 2 && i + 1 < args.length && !args[i + 1].startsWith('-')) {
                    result.flags[arg] = args[i + 1];
                    i++;
                } else result.flags[arg] = true;
            }
        } else {
            if (/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/.test(arg) || arg.startsWith('http') || arg.startsWith('//')) {
                result.targets.push(arg);
            } else result.remaining.push(arg);
        }
        i++;
    }
    return result;
}
if (!window.SCENARIO || Number(window.SCENARIO.id) !== 10) throw new Error("Scenario 10 failed registration");
window.SCENARIO_LIBRARY[10] = window.SCENARIO;
window.SCENARIO = null;
})();

/* ===== storage.js ===== */
// storage.js — thin persistence layer
window.Storage = (function () {
  const KEY = "protocolBreach.save.v1";

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (e) {
      console.warn("Storage.load failed", e);
      return null;
    }
  }

  function save(state) {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
      return true;
    } catch (e) {
      console.warn("Storage.save failed", e);
      return false;
    }
  }

  function wipe() {
    try { localStorage.removeItem(KEY); } catch (e) {}
  }

  return { load, save, wipe };
})();

/* ===== clock.js ===== */
// clock.js — time security & offline elapsed-time helpers
window.Clock = (function () {
  const MAX_REASONABLE_OFFLINE_MS = 1000 * 60 * 60 * 24 * 30; // cap absurd gaps at 30 days

  function now() { return Date.now(); }

  // Returns elapsed ms since `lastTs`, guarding against clock rollback / tampering.
  function elapsedSince(lastTs) {
    if (!lastTs || typeof lastTs !== "number") return 0;
    const n = now();
    let delta = n - lastTs;
    if (delta < 0) delta = 0;               // backwards clock change -> treat as no time passed
    if (delta > MAX_REASONABLE_OFFLINE_MS) delta = MAX_REASONABLE_OFFLINE_MS; // cap unreasonable gaps
    return delta;
  }

  function msToMinutes(ms) { return ms / 60000; }
  function msToHours(ms) { return ms / 3600000; }

  return { now, elapsedSince, msToMinutes, msToHours };
})();

/* ===== state.js ===== */
// state.js — the single source of truth for player + scenario state
window.State = (function () {

  function freshPlayer() {
    return {
      version: 6,
      activeScenarioId: null,
      scenarios: {},           // id -> scenarioState
      assessmentHistory: [],   // {ts, scenarioId, taskId, objectiveId, pass, reward, repDelta}
      assessmentTaskFailures: {}, // taskId -> {ts, reason}; a critical gate failure cancels the task
      redTeamHistory: [],      // {ts, scenarioId, service, price}
      worldHistory: [],
      settings: { compactUI: true, reducedMotion: false, largeText: false, guidance: true },
      profile: { totalMissions: 0, successfulMissions: 0, bestScore: 0, stealthBest: 0, totalHeat: 0, objectivesCompleted: 0, achievements: [], lastGrade: null },
      lastSeen: Clock.now(),
      createdAt: Clock.now()
    };
  }

  function freshScenarioState(company) {
    return {
      id: company.id,
      score: 100,
      startingScore: 100,
      reputation: 10,
      credits: 100.00,
      userFiles: [],
      peakHeat: 0,
      heat: 0,
      awareness: 0,
      responseLevel: 0,          // 0..5
      systems: {                 // 0-100 alert level per subsystem
        monitoring: 5, authentication: 5, webServices: 5,
        internalSystems: 5, logging: 5
      },
      systemsPrev: { monitoring: 5, authentication: 5, webServices: 5, internalSystems: 5, logging: 5 },
      responseTeam: "STANDBY",   // STANDBY | ACTIVE | DEPLOYED
      recoveryTier: 1,           // 1,2,3 -> divisor 5/10/15
      recoveryProgress: 0,       // fractional score points banked
      activeStreakMinutes: 0,    // meaningful active-play minutes counted toward tier recovery
      recoveryWindowMs: 0,
      recoveryStageMs: 0,
      recoveryResetProgress: 0,
      lastActionType: "idle",
      lastQuietActionAt: Clock.now(),
      world: { browserSearches: 0, osintLeads: 0, wifiScans: 0, filesViewed: 0, identityLayers: [], networkScanned: false },
      recoveryPaused: false,
      recoveryLockMs: 0,        // short post-noise lock before quiet recovery resumes
      recoveryHalfRate: false,  // recovery clock advances at 50% while pressure is still settling
      recoveryHalfRateMs: 0,

      lastNoisyActionAt: 0,
      protection: [],            // active protection layers [{id, name, reduction, expiresAt}]
      intelPurchased: [],        // ids of purchased intel packages
      flagsFound: [],
      objectiveResults: {},      // objectiveId -> {pass, reward, ts, cancelled?}
      assessmentTaskFailures: {},
      assessmentEarnings: 0,
      assessmentCap: 30,
      assessmentSeed: 0,
      assessmentSet: [],
      assessmentSetBand: null,
      assessmentSetCount: 0,
      redTeamUses: 0,
      currentPath: "/home/kali",
      commandHistory: [],
      log: [],                   // activity feed
      mission: { objectives: {}, evidence: [], milestones: [], completedAt: null, outcome: "IN_PROGRESS" },
      actionStats: { quiet: 0, noisy: 0, totalNoise: 0, creditsSpent: 0, creditsEarned: 0 },
      comms: { mailRead: 0, messagesSent: 0, calls: 0, callMinutes: 0, contacts: {}, threads: {}, alerts: 0, directory: [], emails: [] },
      social: { friends: {}, messages: {}, viewed: [], alerts: 0, postsOpened: 0, messagesSent: 0, relationshipXP: 0 },
      location: { lookups: 0, tracked: [], lastArea: null, confidence: 0 },
      started: true,
      completed: false,
      // Mission timer uses active simulation time only. Wall-clock/offline time never counts.
      firstStartedAt: Clock.now(),
      startedAt: Clock.now(),
      activeElapsedMs: 0,
      activeTimeSince: null,
      timePlan: null,
      timeStage: 0,
      timeScoreCap: 100,
      timePenaltyHistory: [],
      timedOut: false,
      lastTimestamp: Clock.now()
    };
  }

  function ensureScenario(player, company) {
    if (!player.scenarios[company.id]) {
      player.scenarios[company.id] = freshScenarioState(company);
    }
    return player.scenarios[company.id];
  }

  function load() {
    const saved = Storage.load();
    if (saved && [1,2,3,4,5,6].includes(Number(saved.version))) {
      const fresh = freshPlayer();
      saved.version = 6;
      saved.scenarios = (saved.scenarios && typeof saved.scenarios === "object") ? saved.scenarios : {};
      saved.worldHistory = Array.isArray(saved.worldHistory) ? saved.worldHistory : [];
      saved.assessmentHistory = Array.isArray(saved.assessmentHistory) ? saved.assessmentHistory : [];
      saved.assessmentTaskFailures = saved.assessmentTaskFailures && typeof saved.assessmentTaskFailures === "object" ? saved.assessmentTaskFailures : {};
      saved.redTeamHistory = Array.isArray(saved.redTeamHistory) ? saved.redTeamHistory : [];
      saved.settings = { ...fresh.settings, ...(saved.settings && typeof saved.settings === "object" ? saved.settings : {}) };
      saved.profile = { ...fresh.profile, ...(saved.profile && typeof saved.profile === "object" ? saved.profile : {}) };
      Object.values(saved.scenarios).forEach(s => {
        if (!s || typeof s !== "object") return;
        s.reputation = Number.isFinite(Number(s.reputation)) ? State.clamp(Number(s.reputation),0,20) : 10;
        s.credits = Number.isFinite(Number(s.credits)) ? Math.max(0,Number(s.credits)) : 100;
        s.score = Number.isFinite(Number(s.score)) ? State.clamp(Number(s.score),0,100) : 100;
        s.startingScore = Number.isFinite(Number(s.startingScore)) ? State.clamp(Number(s.startingScore),0,100) : 100;
        s.heat = Number.isFinite(Number(s.heat)) ? State.clamp(Number(s.heat),0,100) : 0;
        s.peakHeat = Number.isFinite(Number(s.peakHeat)) ? State.clamp(Number(s.peakHeat),0,100) : s.heat;
        s.awareness = Number.isFinite(Number(s.awareness)) ? State.clamp(Number(s.awareness),0,100) : 0;
        s.responseLevel = Number.isFinite(Number(s.responseLevel)) ? State.clamp(Number(s.responseLevel),0,5) : 0;
        s.flagsFound = Array.isArray(s.flagsFound) ? [...new Set(s.flagsFound)] : [];
        s.commandHistory = Array.isArray(s.commandHistory) ? s.commandHistory.slice(-300) : [];
        s.log = Array.isArray(s.log) ? s.log.slice(0,500) : [];
        s.userFiles = Array.isArray(s.userFiles) ? s.userFiles : [];
        s.intelPurchased = Array.isArray(s.intelPurchased) ? [...new Set(s.intelPurchased)] : [];
        s.protection = Array.isArray(s.protection) ? s.protection : [];
        s.objectiveResults = s.objectiveResults && typeof s.objectiveResults === "object" ? s.objectiveResults : {};
        s.assessmentTaskFailures = s.assessmentTaskFailures && typeof s.assessmentTaskFailures === "object" ? s.assessmentTaskFailures : {};
        s.assessmentSeed = Number.isFinite(Number(s.assessmentSeed)) ? Number(s.assessmentSeed) : 0;
        s.assessmentSet = Array.isArray(s.assessmentSet) ? s.assessmentSet : [];
        s.assessmentSetBand = typeof s.assessmentSetBand === "string" ? s.assessmentSetBand : null;
        s.assessmentSetCount = Number(s.assessmentSetCount)||0;
        s.actionStats = { quiet:0, noisy:0, totalNoise:0, creditsSpent:0, creditsEarned:0, ...(s.actionStats && typeof s.actionStats === "object" ? s.actionStats : {}) };
        s.world = { browserSearches:0, osintLeads:0, wifiScans:0, filesViewed:0, identityLayers:[], networkScanned:false, rdpSession:null, generatedProfiles:{}, ...(s.world && typeof s.world === "object" ? s.world : {}) };
        s.world.identityLayers = Array.isArray(s.world.identityLayers) ? s.world.identityLayers : [];
        s.comms = { mailRead:0, messagesSent:0, calls:0, callMinutes:0, contacts:{}, threads:{}, alerts:0, directory:[], emails:[], ...(s.comms && typeof s.comms === "object" ? s.comms : {}) };
        s.comms.directory = Array.isArray(s.comms.directory) ? s.comms.directory : []; s.comms.emails = Array.isArray(s.comms.emails) ? s.comms.emails : [];
        s.social = { friends:{}, messages:{}, viewed:[], alerts:0, postsOpened:0, messagesSent:0, relationshipXP:0, feedOffset:0, ...(s.social && typeof s.social === "object" ? s.social : {}) };
        s.social.viewed = Array.isArray(s.social.viewed) ? s.social.viewed : [];
        s.location = { lookups:0, tracked:[], lastArea:null, confidence:0, ...(s.location && typeof s.location === "object" ? s.location : {}) };
        s.mission = { objectives:{}, evidence:[], milestones:[], completedAt:null, outcome:"IN_PROGRESS", attempts:0, bestScore:null, bestGrade:null, ...(s.mission && typeof s.mission === "object" ? s.mission : {}) };
        s.mission.evidence = Array.isArray(s.mission.evidence) ? s.mission.evidence : [];
        s.mission.milestones = Array.isArray(s.mission.milestones) ? s.mission.milestones : [];
        s.recoveryWindowMs = Number(s.recoveryWindowMs)||0; s.recoveryStageMs = Number(s.recoveryStageMs)||0; s.recoveryResetProgress = Number(s.recoveryResetProgress)||0;
        s.recoveryLockMs = Number(s.recoveryLockMs)||0; s.recoveryHalfRateMs = Number(s.recoveryHalfRateMs)||0;
        s.firstStartedAt = Number(s.firstStartedAt)||Number(s.startedAt)||Clock.now();
        s.startedAt = Number(s.startedAt)||s.firstStartedAt;
        s.activeElapsedMs = Number.isFinite(Number(s.activeElapsedMs)) ? Math.max(0,Number(s.activeElapsedMs)) : 0;
        s.activeTimeSince = null; // never carry a live session across a reload/offline gap
        s.timePlan = s.timePlan && typeof s.timePlan === 'object' ? s.timePlan : null;
        s.timeStage = Number.isFinite(Number(s.timeStage)) ? State.clamp(Number(s.timeStage),0,5) : 0;
        s.timeScoreCap = Number.isFinite(Number(s.timeScoreCap)) ? State.clamp(Number(s.timeScoreCap),0,100) : 100;
        s.timePenaltyHistory = Array.isArray(s.timePenaltyHistory) ? s.timePenaltyHistory : [];
        s.timedOut = !!s.timedOut;
        s.lastTimestamp = Number(s.lastTimestamp)||Clock.now();
      });
      return { ...fresh, ...saved };
    }
    return freshPlayer();
  }

  function save(player) {
    player.lastSeen = Clock.now();
    Storage.save(player);
  }

  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

  return { freshPlayer, freshScenarioState, ensureScenario, load, save, wipe:()=>Storage.wipe(), clamp };
})();

/* ===== heat.js ===== */
// heat.js — Heat, action noise, and target-response state machine
window.Heat = (function () {

  // ── Base noise table, keyed by command name (0 = quiet / free) ──
  const NOISE_TABLE = {
    // recon / OSINT — quiet
    nmap: 0, theharvester: 0, whois: 0, dig: 0, dns: 0, nslookup: 0, host: 0, whoislook: 0, headers: 1, dnslook: 0, dnsrecon: 1, osint: 0, browser: 0, websearch: 0, webopen: 0, search: 0, wifi_scan: 0, file_view: 0, identity: 0, robots: 0, sitemap: 0, crtsh: 0, company: 0, people: 0, technology: 0, recon: 0,
    searchsploit: 0, shodan: 1, recon: 0, ping: 1, traceroute: 1, tracepath: 1, arp: 0, route: 0, ip: 0, ifconfig: 0, ss: 0, netstat: 0, nc: 3, netcat: 3, telnet: 3,
    // enumeration — light noise
    enum4linux: 3, smbclient: 3, smbmap: 3, nikto: 4, gobuster: 4, dirb: 4, wpscan: 4, ftp: 2,
    // credential / auth attacks — loud
    hydra: 7, medusa: 7, xfreerdp: 6, rdesktop: 6, ssh: 3, crackmapexec: 6, patator: 7,
    // exploitation — very loud
    msfconsole: 9, sqlmap: 6, exploit: 9, msfvenom: 5, eternalblue: 9, bluekeep: 9,
    // web
    curl: 2, wget: 2, burpsuite: 3, ffuf: 4, feroxbuster: 4, 'careers-upload': 8,
    // free navigation / local tooling
    ls: 0, cd: 0, cat: 0, pwd: 0, help: 0, clear: 0, whoami: 0, history: 0, echo: 0, date: 0, env: 0, which: 0, type: 0, man: 0, head: 0, tail: 0, wc: 0, file: 0, stat: 0, strings: 0, sort: 0, uniq: 0, df: 0, du: 0, free: 0, uptime: 0, top: 0, sleep: 0,
    hostname: 0, id: 0, uname: 0, ps: 0, find: 0
  };

  function noiseFor(cmd) {
    if (Object.prototype.hasOwnProperty.call(NOISE_TABLE, cmd)) return NOISE_TABLE[cmd];
    return 0; // invalid/unknown commands do not create fictional network noise
  }

  // ── Response profile per scenario, derived from difficulty + industry flavor ──
  function responseProfile(company) {
    const diffMult = DIFFICULTY_MULT[company.difficulty] || 1;
    const ind = (company.industry || "").toLowerCase();
    let profile = {
      heatSensitivity: diffMult,
      detectionSpeed: diffMult,
      responseSpeed: diffMult,
      adaptationStrength: diffMult,
      decayRate: 1 / diffMult   // harder targets forgive silence more slowly
    };
    if (ind.includes("financ") || ind.includes("bank") || ind.includes("capital")) {
      profile.detectionSpeed *= 1.35; profile.responseSpeed *= 1.3;
    }
    if (ind.includes("tech") || ind.includes("game") || ind.includes("media") || ind.includes("cloud") || ind.includes("streaming")) {
      profile.detectionSpeed *= 1.25; profile.adaptationStrength *= 1.25;
    }
    if (company.employees < 60) {
      profile.detectionSpeed *= 0.6; profile.responseSpeed *= 0.55; // small org, slow & manual
    }
    if (company.employees > 40000) {
      profile.responseSpeed *= 0.75; // huge distributed org, slower centralized response
      profile.adaptationStrength *= 1.1; // but individual systems react independently
    }
    return profile;
  }

  // ── Compute the consequence of a single action ──
  function actionConsequence(cmd, company, scnState) {
    const noise = noiseFor(cmd);
    if (noise === 0) return { noise: 0, heatDelta: 0, scoreDelta: 0, awarenessDelta: 0, cost: 0 };

    const diffMult = DIFFICULTY_MULT[company.difficulty] || 1;
    const profile = responseProfile(company);
    const targetStateMult = 1 + scnState.responseLevel * 0.10;
    const protectionReduction = totalProtectionReduction(scnState);
    const protectionMult = 1 - protectionReduction;

    const heatDelta = Math.round(noise * 3 * diffMult * targetStateMult * protectionMult * 10) / 10;
    const scoreDelta = -Math.round(noise * 0.9 * diffMult * protectionMult);
    const awarenessDelta = Math.round(noise * 0.5 * profile.detectionSpeed * (1 - protectionReduction * 0.5) * 10) / 10;

    return { noise, heatDelta, scoreDelta, awarenessDelta, cost: 0 };
  }

  function totalProtectionReduction(scnState) {
    const now = Clock.now();
    const active = (scnState.protection || []).filter(p => !p.expiresAt || p.expiresAt > now);
    // diminishing returns: combine layers multiplicatively, not additively
    let remaining = 1;
    active.forEach(p => { remaining *= (1 - p.reduction); });
    if (["CoffeeHouse_FreeWiFi","Airport_FreeWiFi"].includes(scnState?.world?.wifiSsid)) remaining *= 0.98;
    return State.clamp(1 - remaining, 0, 0.85); // cap at 85% reduction
  }

  // ── Response level thresholds with hysteresis ──
  const UP_THRESHOLDS = [15, 30, 45, 65, 85];   // heat needed to ESCALATE from level i to i+1
  const DOWN_THRESHOLDS = [8, 20, 32, 50, 70];  // heat must fall to/below this to DE-ESCALATE from level i+1 to i
  const LEVEL_NAMES = ["Normal", "Monitoring", "Suspicious", "Investigation", "Defensive Response", "Critical Lockdown"];

  function stepResponseLevel(level, heat) {
    if (level < 5 && heat >= UP_THRESHOLDS[level]) return level + 1;
    if (level > 0 && heat <= DOWN_THRESHOLDS[level - 1]) return level - 1;
    return level;
  }

  function levelName(level) { return LEVEL_NAMES[State.clamp(level, 0, 5)]; }

  // ── Which subsystem a command primarily affects ──
  function systemFor(cmd) {
    if (["nmap", "shodan", "recon", "dnsrecon", "dig"].includes(cmd)) return "monitoring";
    if (["hydra", "medusa", "xfreerdp", "rdesktop", "ssh", "crackmapexec", "patator"].includes(cmd)) return "authentication";
    if (["sqlmap", "nikto", "gobuster", "dirb", "wpscan", "curl", "burpsuite", "careers-upload"].includes(cmd)) return "webServices";
    if (["smbclient", "smbmap", "enum4linux", "msfconsole", "exploit", "eternalblue", "bluekeep", "msfvenom"].includes(cmd)) return "internalSystems";
    return "logging";
  }

  function applyAction(scnState, company, cmd) {
    const c = actionConsequence(cmd, company, scnState);
    if (c.noise === 0) { scnState.lastActionType = "intel"; scnState.lastQuietActionAt = Clock.now(); return c; }

    scnState.heat = State.clamp(scnState.heat + c.heatDelta, 0, 100);
    scnState.score = State.clamp(scnState.score + c.scoreDelta, 0, 100);
    scnState.awareness = State.clamp(scnState.awareness + c.awarenessDelta, 0, 100);
    scnState.peakHeat = Math.max(scnState.peakHeat, scnState.heat);
    scnState.lastNoisyActionAt = Clock.now();
    scnState.lastActionType = "attack";
    scnState.recoveryPaused = true;
    scnState.recoveryHalfRate = true;
    scnState.recoveryHalfRateMs = 2 * 60000;
    scnState.recoveryLockMs = 2 * 60000;

    // subsystem alert bump
    const sys = systemFor(cmd);
    scnState.systemsPrev[sys] = scnState.systems[sys];
    scnState.systems[sys] = State.clamp(scnState.systems[sys] + c.heatDelta * 1.4, 0, 100);
    // logging quietly creeps up on every noisy action
    scnState.systemsPrev.logging = scnState.systems.logging;
    scnState.systems.logging = State.clamp(scnState.systems.logging + c.heatDelta * 0.5, 0, 100);

    const prevLevel = scnState.responseLevel;
    scnState.responseLevel = stepResponseLevel(scnState.responseLevel, scnState.heat);
    scnState.responseTeam = scnState.responseLevel >= 4 ? "DEPLOYED" : (scnState.responseLevel >= 2 ? "ACTIVE" : "STANDBY");

    if (scnState.responseLevel > prevLevel) {
      scnState.log.unshift({ ts: Clock.now(), type: "escalation", text: adaptationEvent(company, scnState) });
    }
    return c;
  }

  function applyAlert(scnState, company, intensity = 1, source = "alert") {
    const profile = responseProfile(company);
    const base = Math.max(1, Number(intensity) || 1);
    const protectionReduction = totalProtectionReduction(scnState);
    const heatDelta = Math.round(base * (1 + profile.heatSensitivity * 0.35) * (1 - protectionReduction) * 10) / 10;
    const awarenessDelta = Math.round(base * (1.25 + profile.detectionSpeed * 0.45) * (1 - protectionReduction * 0.5) * 10) / 10;
    const scoreDelta = -Math.max(0, Math.round(base * 0.35 * (1 - protectionReduction)));
    scnState.heat = State.clamp(scnState.heat + heatDelta, 0, 100);
    scnState.awareness = State.clamp(scnState.awareness + awarenessDelta, 0, 100);
    scnState.score = State.clamp(scnState.score + scoreDelta, 0, 100);
    scnState.peakHeat = Math.max(scnState.peakHeat, scnState.heat);
    const prevLevel = scnState.responseLevel;
    scnState.responseLevel = stepResponseLevel(scnState.responseLevel, scnState.heat);
    scnState.responseTeam = scnState.responseLevel >= 4 ? "DEPLOYED" : (scnState.responseLevel >= 2 ? "ACTIVE" : "STANDBY");
    scnState.lastActionType = "alert";
    scnState.lastNoisyActionAt = Clock.now();
    if (scnState.responseLevel > prevLevel) scnState.log.unshift({ ts: Clock.now(), type: "escalation", text: adaptationEvent(company, scnState) });
    scnState.log.unshift({ ts: Clock.now(), type: "alert", text: `${source}: target attention increased (Heat +${heatDelta}, Awareness +${awarenessDelta}).` });
    return { heatDelta, awarenessDelta, scoreDelta, levelChanged: scnState.responseLevel !== prevLevel };
  }

  function markQuietAction(scnState) {
    // Quiet/intel actions release the hard pause, but the short settling lock remains.
    scnState.recoveryPaused = false;
    scnState.lastQuietActionAt = Clock.now();
  }

  // Flavor text describing how the target adapts when it escalates
  function adaptationEvent(company, scnState) {
    const level = scnState.responseLevel;
    const events = {
      1: [`Monitoring tightened on ${company.name}'s perimeter systems.`, `Automated alerting thresholds lowered.`],
      2: [`Security staff flagged unusual traffic patterns.`, `A duty analyst opened a ticket on recent activity.`],
      3: [`${company.name} has opened a formal investigation.`, `Credentials tied to recent activity are being rotated.`],
      4: [`Defensive countermeasures are being deployed.`, `Non-essential external access is being restricted.`],
      5: [`Critical lockdown triggered — expect active countermeasures.`, `Incident response has been fully activated.`]
    };
    const pool = events[level] || ["The target's posture has changed."];
    return pool[Math.floor(Math.random() * pool.length)];
  }

  return {
    noiseFor, responseProfile, actionConsequence, totalProtectionReduction,
    stepResponseLevel, levelName, systemFor, applyAction, applyAlert, markQuietAction,
    UP_THRESHOLDS, DOWN_THRESHOLDS
  };
})();

/* ===== recovery.js ===== */
// recovery.js — Score recovery, Heat decay, offline catch-up and staged recovery windows.
window.Recovery = (function () {
  const BRACKETS = [
    { min: 81, max: 100, points: 3, minutes: 30 },
    { min: 56, max: 80, points: 2, minutes: 35 },
    { min: 41, max: 55, points: 1, minutes: 40 },
    { min: 16, max: 40, points: 1, minutes: 60 },
    { min: 0, max: 15, points: 1, minutes: 90 }
  ];
  const STAGES = [
    { maxMs: 25*60*60*1000, divisor: 5, resetPlay: 180 },
    { maxMs: 48*60*60*1000, divisor: 10, resetPlay: 180, improvePlay: 60 },
    { maxMs: 72*60*60*1000, divisor: 15, resetPlay: 180, improvePlay: 60, stayPlay: 10 }
  ];
  function bracketFor(score) { return BRACKETS.find(b => score >= b.min && score <= b.max) || BRACKETS.at(-1); }
  function stageFor(ms) {
    let used = 0;
    for (let i=0;i<STAGES.length;i++) { if (ms < used + STAGES[i].maxMs) return {index:i, stage:STAGES[i], into:ms-used}; used += STAGES[i].maxMs; }
    return {index:2, stage:STAGES[2], into:STAGES[2].maxMs};
  }
  function divisorForTier(tier) { return tier === 1 ? 5 : tier === 2 ? 10 : 15; }
  function syncStage(s) {
    const x = stageFor(s.recoveryWindowMs || 0);
    s.recoveryTier = x.index + 1;
    s.recoveryStageMs = x.into;
    return x;
  }
  function applyScoreRecovery(s, simMinutes, company) {
    if (s.score >= 100 || simMinutes <= 0) return 0;
    let remaining=simMinutes, gained=0, guard=0;
    while (remaining>0 && s.score<100 && guard++<1000) {
      let b={...bracketFor(s.score)};
      if (s.score>=81 && company && ["Hard","Brutal","Extremely Brutal"].includes(company.difficulty)) b.points=2;
      const fraction=Math.min(remaining,b.minutes)/b.minutes;
      s.recoveryProgress=(s.recoveryProgress||0)+b.points*fraction;
      remaining-=b.minutes*fraction;
      const whole=Math.floor(s.recoveryProgress);
      if (whole>0) { const before=s.score; s.score=State.clamp(s.score+whole,0,100); gained+=s.score-before; s.recoveryProgress-=whole; }
      if (fraction<1) break;
    }
    return gained;
  }
  function applyHeatDecay(s, realMinutes, company) {
    if (realMinutes<=0) return;
    const profile=Heat.responseProfile(company);
    const decay=.6*profile.decayRate;
    s.heat=State.clamp(s.heat-decay*realMinutes,0,100);
    s.awareness=State.clamp(s.awareness-.15*profile.decayRate*realMinutes,0,100);
    Object.keys(s.systems).forEach(k=>{s.systemsPrev[k]=s.systems[k];s.systems[k]=State.clamp(s.systems[k]-decay*.8*realMinutes,0,100);});
    const prev=s.responseLevel;
    s.responseLevel=Heat.stepResponseLevel(s.responseLevel,s.heat);
    s.responseTeam=s.responseLevel>=4?"DEPLOYED":s.responseLevel>=2?"ACTIVE":"STANDBY";
    if(s.responseLevel<prev)s.log.unshift({ts:Clock.now(),type:"deescalation",text:`Target posture eased to ${Heat.levelName(s.responseLevel)}.`});
  }
  function noteActivePlay(s, minutes) {
    if (minutes<=0) return;
    s.activeStreakMinutes=(s.activeStreakMinutes||0)+minutes;
    let stage=syncStage(s).index;
    // Stage 1 (first 25h): 3h active play returns to the fast ÷5 tier.
    if (stage===0 && s.activeStreakMinutes>=180) { s.recoveryWindowMs=0; s.activeStreakMinutes=0; syncStage(s); return; }
    // Stage 2 (next 48h): 1h active play earns a return to ÷10; 3h returns to ÷5.
    if (stage===1 && s.activeStreakMinutes>=180) { s.recoveryWindowMs=0; s.activeStreakMinutes=0; syncStage(s); return; }
    if (stage===1 && s.activeStreakMinutes>=60) {
      s.recoveryWindowMs=Math.min(25*60*60*1000-1, s.recoveryWindowMs||0);
      s.activeStreakMinutes=0; syncStage(s); return;
    }
    // Stage 3 (next 72h): 10m establishes/keeps ÷15, 1h returns to ÷10, 3h returns to ÷5.
    if (stage===2 && s.activeStreakMinutes>=180) { s.recoveryWindowMs=0; s.activeStreakMinutes=0; syncStage(s); return; }
    if (stage===2 && s.activeStreakMinutes>=60) {
      s.recoveryWindowMs=25*60*60*1000+1; s.activeStreakMinutes=0; syncStage(s); return;
    }
    if (stage===2 && s.activeStreakMinutes>=10) {
      s.recoveryWindowMs=Math.max(25*60*60*1000+1, Math.min(25*60*60*1000+48*60*60*1000+1, s.recoveryWindowMs||0));
      s.activeStreakMinutes=0; syncStage(s);
    }
  }
  function advance(s, realMinutes, company, allowRecovery=true, options={}) {
    if(realMinutes<=0)return 0;
    applyHeatDecay(s,realMinutes,company);
    if(!allowRecovery) return 0;

    // During active operations the recovery clock moves at half speed.
    // Score points are not awarded until the post-noise settling lock has cleared.
    const offline = !!options.offline;
    const lockMinutes = offline ? 0 : Math.min(realMinutes, Math.max(0,(s.recoveryLockMs||0)/60000));
    const usableMinutes = Math.max(0, realMinutes - lockMinutes);
    if (!offline && lockMinutes > 0) s.recoveryLockMs = Math.max(0,(s.recoveryLockMs||0)-realMinutes*60000);
    if (usableMinutes <= 0) { s.recoveryPaused = true; return 0; }
    s.recoveryLockMs = Math.max(0,(s.recoveryLockMs||0)-realMinutes*60000);
    s.recoveryPaused = false;

    s.recoveryWindowMs=(s.recoveryWindowMs||0)+usableMinutes*60000;
    syncStage(s);
    const halfRateMinutes = Math.max(0, (s.recoveryHalfRateMs||0) / 60000);
    const halfPart = (!offline && s.recoveryHalfRate) ? Math.min(usableMinutes, halfRateMinutes) : 0;
    const normalPart = usableMinutes - halfPart;
    const simMinutes=(halfPart * 0.5 + normalPart) / divisorForTier(s.recoveryTier);
    const gained=applyScoreRecovery(s,simMinutes,company);
    if (!offline && halfPart > 0) {
      s.recoveryHalfRateMs = Math.max(0,(s.recoveryHalfRateMs||0)-usableMinutes*60000);
      if (s.recoveryHalfRateMs <= 0) s.recoveryHalfRate=false;
    }
    return gained;
  }
  function catchUp(s, company) {
    const elapsed=Clock.elapsedSince(s.lastTimestamp); const real=Clock.msToMinutes(elapsed);
    if(real<=.05){s.lastTimestamp=Clock.now();return {realMinutes:0,simMinutes:0,gained:0,tier:s.recoveryTier};}
    const gained=advance(s,real,company,true,{offline:true});
    s.lastTimestamp=Clock.now();
    return {realMinutes:real,simMinutes:real/divisorForTier(s.recoveryTier),gained,tier:s.recoveryTier};
  }
  function liveTick(s,company,realMinutes) {
    if(realMinutes<=0)return;
    const gained=advance(s,realMinutes,company,true,{offline:false});
    noteActivePlay(s,realMinutes);
    s.lastTimestamp=Clock.now();
    return gained;
  }
  function status(s){
    const x=syncStage(s); const left=x.stage.maxMs-x.into;
    return {tier:x.index+1,divisor:x.stage.divisor,windowHours:((s.recoveryWindowMs||0)/3600000),stageHours:x.into/3600000,leftHours:left/3600000};
  }
  return {BRACKETS,STAGES,bracketFor,divisorForTier,syncStage,applyScoreRecovery,applyHeatDecay,noteActivePlay,catchUp,liveTick,status};
})();

/* ===== economy.js ===== */
// economy.js — Protection layers, Intelligence packages, Red Team services & pricing
window.Economy = (function () {

  // ── Protection ──
  const PROTECTION_CATALOG = [
    { id: "vpn", name: "VPN", cost: 0.10, reduction: 0.10, durationMin: 20, blurb: "Basic tunnel. Modest consequence reduction." },
    { id: "proxy", name: "Rotating Proxy", cost: 0.10, reduction: 0.15, durationMin: 20, blurb: "Rotates source addresses. Slightly better than a bare VPN." },
    { id: "tor", name: "Tor", cost: 0.10, reduction: 0.20, durationMin: 20, blurb: "Layered routing. Strongest single-layer reduction, adds latency." },
    { id: "burner", name: "Burner identity", cost: 0.25, reduction: 0.05, durationMin: 30, blurb: "Limits cross-operation correlation in the simulation." },
    { id: "isolation", name: "Emergency isolation relay", cost: 5.00, reduction: 0.50, durationMin: 10, blurb: "Short-lived high-grade isolation. Expensive and intentionally temporary." }
  ];

  function buyProtection(scnState, player, id) {
    const item = PROTECTION_CATALOG.find(p => p.id === id);
    if (!item) return { ok: false, msg: "Unknown protection layer." };
    if (scnState.credits < item.cost) return { ok: false, msg: "Not enough credits." };
    scnState.credits = Math.round((scnState.credits - item.cost) * 100) / 100;
    scnState.actionStats ||= {quiet:0,noisy:0,totalNoise:0,creditsSpent:0,creditsEarned:0};
    scnState.actionStats.creditsSpent = Math.round((Number(scnState.actionStats.creditsSpent||0) + item.cost) * 100) / 100;
    scnState.protection.push({ id: item.id, name: item.name, reduction: item.reduction, expiresAt: Clock.now() + item.durationMin * 60000 });
    scnState.log.unshift({ ts: Clock.now(), type: "protection", text: `${item.name} engaged (${Math.round(item.reduction * 100)}% consequence reduction, ${item.durationMin}m).` });
    return { ok: true, msg: `${item.name} active.` };
  }

  // ── Intelligence ──
  function intelCatalog(scenario) {
    const hosts = (scenario && scenario.network && scenario.network.hosts) || [];
    const flags = (scenario && scenario.flags) || [];
    const list = [
      { id: "public", tier: "Public source", cost: 0, blurb: "Open-source recon: company site, job postings, socials.", reveal: `Publicly visible footprint: ${hosts.length} known host(s) in scope.` },
      { id: "basic", tier: "Basic intelligence", cost: 0.5, blurb: "Vendor & tech-stack fingerprinting.", reveal: hosts.slice(0, 2).map(h => `${h.hostname || h.ip}: ${h.os || "unknown OS"}`).join(" | ") || "No additional fingerprinting available." },
      { id: "premium", tier: "Premium intelligence", cost: 3, blurb: "Known-vulnerability digest for in-scope hosts.", reveal: hosts.map(h => `${h.hostname || h.ip}: ${(h.vulnerabilities || []).map(v => v.name).join(", ") || "none catalogued"}`).join("\n") || "No vulnerability data catalogued." },
      { id: "specialized", tier: "Specialized intel", cost: 6, blurb: "Targeted lead toward a specific objective — reduces uncertainty, not the answer.", reveal: (flags[0] && flags[0].hint) ? `Lead: ${flags[0].hint}` : "No specialized leads available for this target." }
    ];
    return list;
  }

  function buyIntel(scnState, player, scenario, id) {
    const item = intelCatalog(scenario).find(p => p.id === id);
    if (!item) return { ok: false, msg: "Unknown intelligence package." };
    if (scnState.intelPurchased.includes(id)) return { ok: false, msg: "Already purchased." };
    if (scnState.credits < item.cost) return { ok: false, msg: "Not enough credits." };
    scnState.credits = Math.round((scnState.credits - item.cost) * 100) / 100;
    scnState.actionStats ||= {quiet:0,noisy:0,totalNoise:0,creditsSpent:0,creditsEarned:0};
    scnState.actionStats.creditsSpent = Math.round((Number(scnState.actionStats.creditsSpent||0) + item.cost) * 100) / 100;
    scnState.intelPurchased.push(id);
    scnState.log.unshift({ ts: Clock.now(), type: "intel", text: `Purchased ${item.tier}.` });
    return { ok: true, msg: item.reveal };
  }

  // ── Red Team ──
  const REDTEAM_SERVICES = [
    { id: "clue", name: "Basic clue", base: 5 },
    { id: "guidance", name: "Next-step guidance", base: 10 },
    { id: "analysis", name: "Strategic analysis", base: 15 },
    { id: "emergency", name: "Emergency assistance", base: 25 }
  ];

  // Rounded-score bracket table exactly as specified.
  function roundedScoreBracket(score) {
    if (score >= 95) return 100;
    if (score >= 85) return 90;
    if (score >= 75) return 80;
    if (score >= 65) return 70;
    if (score >= 55) return 60;
    if (score >= 45) return 50;
    if (score >= 35) return 40;
    if (score >= 25) return 30;
    if (score >= 15) return 20;
    if (score >= 5) return 10;
    return null; // 0-4: critical pricing
  }

  function priceFor(base, score, reputation=0) {
    const rounded = roundedScoreBracket(score);
    let raw = rounded === null ? base * 20 : (base * 100 / rounded);
    // Full Reputation (20/20) earns a permanent 50% Red Team discount. Partial Reputation gives no discount.
    if (Number(reputation) >= 20) raw *= 0.5;
    return Math.round(raw * 100) / 100;
  }

  function redTeamQuote(scnState) {
    return REDTEAM_SERVICES.map(s => ({ ...s, price: priceFor(s.base, scnState.score, scnState.reputation), reputationDiscount: Number(scnState.reputation)>=20 ? 0.5 : 0 }));
  }

  function hireRedTeam(scnState, player, scenario, serviceId) {
    const svc = redTeamQuote(scnState).find(s => s.id === serviceId);
    if (!svc) return { ok: false, msg: "Unknown service." };
    if (scnState.credits < svc.price) return { ok: false, msg: "Not enough credits." };
    scnState.credits = Math.round((scnState.credits - svc.price) * 100) / 100;
    scnState.actionStats ||= {quiet:0,noisy:0,totalNoise:0,creditsSpent:0,creditsEarned:0};
    scnState.actionStats.creditsSpent = Math.round((Number(scnState.actionStats.creditsSpent||0) + svc.price) * 100) / 100;
    scnState.redTeamUses++;
    player.redTeamHistory.push({ ts: Clock.now(), scenarioId: scenario.id, service: svc.name, price: svc.price });

    let content = "The team reviews your telemetry and stays quiet — nothing actionable yet.";
    const flags = scenario.flags || [];
    const idx = Math.min(scnState.flagsFound.length, flags.length - 1);
    if (flags[idx]) {
      if (svc.id === "clue") content = `Clue: ${flags[idx].hint}`;
      else if (svc.id === "guidance") content = `Next step: work toward "${flags[idx].description}". Hint: ${flags[idx].hint}`;
      else if (svc.id === "analysis") content = `Analysis: current response level is ${Heat.levelName(scnState.responseLevel)}. Recommend reducing noisy actions before pursuing "${flags[idx].description}".`;
      else if (svc.id === "emergency") content = `Emergency read: Heat ${Math.round(scnState.heat)}/100, Score ${Math.round(scnState.score)}/100. Fall back to reconnaissance immediately. Target lead: ${flags[idx].hint}`;
    }
    scnState.log.unshift({ ts: Clock.now(), type: "redteam", text: `${svc.name} — $${svc.price.toFixed(2)}` });
    return { ok: true, msg: content, price: svc.price };
  }

  return { PROTECTION_CATALOG, buyProtection, intelCatalog, buyIntel, REDTEAM_SERVICES, roundedScoreBracket, priceFor, redTeamQuote, hireRedTeam };
})();

/* ===== assessment.js ===== */
// assessment.js — randomized, scenario-grounded Assessment Team. Pools are generated in-memory
// from reusable templates: >=100 Very Easy, >=200 Easy, >=200 Moderate, >=100 Hard, >=100 Very Hard, >=100 Extreme.
window.Assessment = (function () {
  const DIFF_LEVELS=["Very Easy","Easy","Moderate","Hard","Very Hard","Extreme"];
  const POOL_SIZES={"Very Easy":100,"Easy":200,"Moderate":200,"Hard":100,"Very Hard":100,"Extreme":100};
  const BASE_REWARD={"Very Easy":1,"Easy":2,"Moderate":3,"Hard":5,"Very Hard":7,"Extreme":10};
  const REP_GAIN={"Very Easy":1,"Easy":1,"Moderate":2,"Hard":2,"Very Hard":3,"Extreme":4};
  const REP_BANDS=[
    {min:0,max:4,label:"Very limited",maxDiffIndex:1},
    {min:5,max:9,label:"Basic",maxDiffIndex:2},
    {min:10,max:12,label:"Normal",maxDiffIndex:3},
    {min:13,max:15,label:"Advanced",maxDiffIndex:4},
    {min:16,max:19,label:"High-level",maxDiffIndex:5},
    {min:20,max:20,label:"Elite",maxDiffIndex:5}
  ];
  function bandFor(rep){const r=Math.max(0,Math.min(20,Number(rep)||0));return REP_BANDS.find(b=>r>=b.min&&r<=b.max)||REP_BANDS[0];}
  function taskCount(rep){return Number(rep)<5?1:Number(rep)<10?2:3;}
  function objectiveAvailable(rep,diff){return DIFF_LEVELS.indexOf(diff)<=bandFor(rep).maxDiffIndex;}
  function mulberry32(seed){return function(){seed|=0;seed=(seed+0x6D2B79F5)|0;let t=Math.imul(seed^(seed>>>15),1|seed);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}
  function shuffle(a,rnd){const x=a.slice();for(let i=x.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[x[i],x[j]]=[x[j],x[i]];}return x;}
  function pools(scenario){
    const hosts=(scenario.network&&scenario.network.hosts)||[], flags=scenario.flags||[], users=scenario.users||[];
    const names=hosts.map(h=>h.hostname||h.ip).filter(Boolean); const vulns=[...new Set(hosts.flatMap(h=>(h.vulnerabilities||[]).map(v=>v.name)).filter(Boolean))];
    const services=[...new Set(hosts.flatMap(h=>(h.services||[]).map(v=>v.service)).filter(Boolean))];
    const flagDesc=flags.map(f=>f.description).filter(Boolean); const hints=flags.map(f=>f.hint).filter(Boolean);
    const userNames=users.map(u=>u.name||u.realName||u.username).filter(Boolean);
    const make=(difficulty,n)=>{
      const i=n, host=names[i%Math.max(1,names.length)]||'the primary host', vuln=vulns[i%Math.max(1,vulns.length)]||'a catalogued weakness', svc=services[i%Math.max(1,services.length)]||'an exposed service', flag=flagDesc[i%Math.max(1,flagDesc.length)]||'the current objective', hint=hints[i%Math.max(1,hints.length)]||'scenario evidence', user=userNames[i%Math.max(1,userNames.length)]||'the identified employee';
      const patterns={
        "Very Easy":[[`Which host is explicitly listed in the current scenario data?`,[host,'A host not present in the scan','An unrelated public IP','No host can be identified'],host,`The scenario lists ${host} as an in-scope host.`],[`Which service is visible on the target?`,[svc,'imaginary-service','unknown/0','none'],svc,`${svc} is present in the scenario service inventory.`]],
        "Easy":[[`Which clue most directly supports the objective "${flag}"?`,[hint,'A guess based on company size','An unrelated username','A random port'],hint,`The scenario's own lead is the strongest direct evidence: ${hint}.`],[`Which person is associated with the current public footprint?`,[user,'An unrelated fictional employee','A deleted account','No employee'],user,`${user} is present in the scenario personnel data.`]],
        "Moderate":[[`Which host should be prioritized when the goal is to investigate ${svc}?`,[host,...names.filter(x=>x!==host).slice(0,3)],host,`${host} is the scenario host associated with the relevant service data.`],[`Which evidence best connects the current lead to "${flag}"?`,[hint,'A generic assumption','A random social post','An unrelated file'],hint,`The documented scenario lead directly supports the objective.`]],
        "Hard":[[`A noisy action has raised Heat. What is the most defensible next move while pursuing "${flag}"?`,['Switch to passive intelligence and reassess','Immediately repeat the loud action','Attempt every credential','Ignore Heat'], 'Switch to passive intelligence and reassess','Quiet collection preserves optionality while the target is more alert.'],[`If ${host} exposes ${svc}, which approach best reduces unnecessary noise?`,['Enumerate the known service narrowly','Scan every port on every host repeatedly','Exploit immediately','Delete the evidence'], 'Enumerate the known service narrowly','Narrow enumeration gathers evidence without unnecessary noise.']],
        "Very Hard":[[`Two pieces of evidence conflict about ${host}. What should an expert operator do?`,['Correlate timestamps/source quality before acting','Choose the more convenient clue','Ignore both','Escalate immediately without verification'],'Correlate timestamps/source quality before acting','Conflicting evidence requires correlation before committing to a high-impact action.'],[`A target has high Heat but low Awareness. What does that imply?`,['Suspicious activity is accumulating without a coherent attribution yet','The target has fully identified you','You are completely undetected','Heat and Awareness are identical'],'Suspicious activity is accumulating without a coherent attribution yet','Heat measures noise; Awareness measures how coherently the target understands it.']],
        "Extreme":[[`You have high Reputation, rising Heat, and incomplete evidence for "${flag}". Which choice best balances reward and survivability?`,['Collect the missing evidence quietly, then act once confidence is sufficient','Spend all resources immediately','Ignore Heat because Reputation is high','Force the objective before verification'],'Collect the missing evidence quietly, then act once confidence is sufficient','High reputation unlocks harder opportunities; it does not make noisy actions safe.'],[`A hard-earned lead points to ${host}, but ${vuln} is only weakly corroborated. What is the expert response?`,['Validate the weakness with a second independent signal','Treat the lead as proven','Discard all intelligence','Trigger every available tool'],'Validate the weakness with a second independent signal','Extreme assessments reward disciplined corroboration rather than speed or assumption.']]
      };
      const arr=patterns[difficulty]||patterns.Easy; const q=arr[i%arr.length]; return {id:`${difficulty.toLowerCase().replace(/ /g,'-')}-${String(i+1).padStart(3,'0')}`,type:i%7===0?'gate':i%5===0?'bonus':'standard',difficulty,prompt:q[0],options:shuffle(q[1],mulberry32((scenario.id||1)*100000+i*17+DIFF_LEVELS.indexOf(difficulty))),correct:q[2],hint:'Use only evidence contained in the fictional scenario.',explanation:q[3]};
    };
    const out={}; DIFF_LEVELS.forEach(d=>{out[d]=Array.from({length:POOL_SIZES[d]},(_,i)=>make(d,i));}); return out;
  }
  function chooseDifficulty(rep,rnd){const max=bandFor(rep).maxDiffIndex; const floor=rep>=16?3:rep>=13?2:rep>=10?1:0; const weights=[]; for(let i=floor;i<=max;i++){const w=(i+1)*(rep>=16?1.8:rep>=10?1.35:1);for(let j=0;j<Math.max(1,Math.round(w));j++)weights.push(i);} return DIFF_LEVELS[weights[Math.floor(rnd()*weights.length)]||0];}
  function generateAssessmentTasks(scenario,scnState){
    const rep=Math.max(0,Math.min(20,Number(scnState?.reputation)||0)); const band=bandFor(rep); const pool=pools(scenario); const seed=scnState.assessmentSeed||(Date.now()^((scenario.id||1)*2654435761)); const rnd=mulberry32(seed+rep*7919); const count=taskCount(rep); const tasks=[];
    for(let t=0;t<count;t++){
      let difficulty=chooseDifficulty(rep,rnd);
      if(rep>=20 && t===0) difficulty='Extreme';
      else if(rep>=16 && t===0 && difficulty==='Hard') difficulty='Very Hard';
      const arr=pool[difficulty]; const q=[]; const start=Math.floor(rnd()*arr.length);
      for(let j=0;j<3;j++) q.push({...arr[(start+j*17+t*11)%arr.length],id:`${arr[(start+j*17+t*11)%arr.length].id}-set${t+1}`});
      tasks.push({id:`assessment-${seed}-${t+1}`,title:`Assessment ${t+1} · ${difficulty}`,objectives:q});
    }
    return tasks;
  }
  function ensureSet(scenario,scnState){
    const rep=Number(scnState.reputation)||0, band=bandFor(rep).label;
    if(!scnState.assessmentSeed) scnState.assessmentSeed=(Date.now()^((scenario.id||1)*2654435761))>>>0;
    if(!Array.isArray(scnState.assessmentSet)||scnState.assessmentSetBand!==band||scnState.assessmentSetCount!==taskCount(rep)){
      const tasks=generateAssessmentTasks(scenario,scnState); scnState.assessmentSet=tasks; scnState.assessmentSetBand=band; scnState.assessmentSetCount=tasks.length;
    }
    return scnState.assessmentSet;
  }
  function severity(obj){if(obj.type==='gate')return{label:'Critical failure',loss:5,terminates:true};const idx=DIFF_LEVELS.indexOf(obj.difficulty);return{label:idx>=3?'Large error':idx===2?'Moderate error':'Small error',loss:idx>=3?5:idx===2?3:2,terminates:false};}
  function rewardMultiplier(rep){return 0.75+(Math.max(0,Math.min(20,Number(rep)||0))/20)*1.25;}
  function submit(player,scnState,scenario,taskId,objectiveId,chosenOption,hintsUsed){
    const tasks=ensureSet(scenario,scnState),task=tasks.find(t=>t.id===taskId);if(!task)return{ok:false,msg:'Unknown assessment.'};const obj=task.objectives.find(o=>o.id===objectiveId);if(!obj)return{ok:false,msg:'Unknown objective.'};
    scnState.assessmentTaskFailures ||= {}; if(scnState.assessmentTaskFailures[taskId])return{ok:false,msg:'This assessment is closed after a critical objective failure.'}; if(scnState.objectiveResults[objectiveId])return{ok:false,msg:'Already completed.'}; if(!objectiveAvailable(scnState.reputation,obj.difficulty))return{ok:false,msg:'Reputation too low to unlock this assessment.'};
    const pass=chosenOption===obj.correct; let reward=0,repDelta=0,terminates=false;
    if(pass){const hintMult=hintsUsed>=2?.2:hintsUsed===1?.6:1; reward=Math.round(BASE_REWARD[obj.difficulty]*rewardMultiplier(scnState.reputation)*hintMult*100)/100; const room=Math.max(0,scnState.assessmentCap-scnState.assessmentEarnings);reward=Math.min(reward,room);scnState.assessmentEarnings+=reward;scnState.credits=Math.round((scnState.credits+reward)*100)/100;scnState.actionStats ||= {quiet:0,noisy:0,totalNoise:0,creditsSpent:0,creditsEarned:0};scnState.actionStats.creditsEarned=Math.round((Number(scnState.actionStats.creditsEarned||0)+reward)*100)/100;repDelta=REP_GAIN[obj.difficulty];scnState.reputation=State.clamp(scnState.reputation+repDelta,0,20);}else{const sev=severity(obj);repDelta=-sev.loss;scnState.reputation=State.clamp(scnState.reputation+repDelta,0,20);terminates=sev.terminates;}
    scnState.objectiveResults[objectiveId]={pass,reward,repDelta,ts:Clock.now(),taskId}; if(!pass&&terminates){scnState.assessmentTaskFailures[taskId]={ts:Clock.now(),reason:'Critical gate objective failed.'};task.objectives.filter(o=>o.id!==objectiveId).forEach(o=>{if(!scnState.objectiveResults[o.id])scnState.objectiveResults[o.id]={pass:false,cancelled:true,reward:0,repDelta:0,ts:Clock.now(),taskId};});}
    player.assessmentHistory.push({ts:Clock.now(),scenarioId:scenario.id,taskId,objectiveId,pass,reward,repDelta}); scnState.log.unshift({ts:Clock.now(),type:'assessment',text:`${pass?'PASSED':'FAILED'} "${obj.prompt.slice(0,40)}..." (${pass?'+$'+reward.toFixed(2):''} Rep ${repDelta>=0?'+':''}${repDelta})`}); return{ok:true,pass,reward,repDelta,terminates,correct:obj.correct,explanation:obj.explanation};
  }
  function poolStats(){return {...POOL_SIZES};}
  return {DIFF_LEVELS,POOL_SIZES,BASE_REWARD,REP_GAIN,REP_BANDS,bandFor,taskCount,objectiveAvailable,severity,generateAssessmentTasks,ensureSet,submit,poolStats,rewardMultiplier};
})();

/* ===== world.js ===== */
// world.js — fictional browser, OSINT, network/Wi-Fi, identity cover and file explorer.
// All data is scenario-contained; no real network access is performed.
window.World = (function () {
  function clean(v) { return String(v ?? "").replace(/[<>]/g, ""); }
  function employees(scenario) {
    const users = scenario.users || [];
    return users.map((u, i) => ({
      name: u.name || u.realName || u.username || `Analyst ${i + 1}`,
      username: u.username || "unknown",
      email: u.email || `${u.username || "user"}@target.invalid`,
      role: u.role || "Staff",
      clue: u.osint || "No public clue catalogued."
    }));
  }
  function browserResults(scenario, query) {
    const q = String(query || "").trim().toLowerCase();
    const name = scenario.name || "Target Organization";
    const hosts = scenario.network?.hosts || [];
    const users = employees(scenario);
    const results = [];
    if (!q || q === "home") return [
      {title:`${name} — Public Site`, url:`https://${name.toLowerCase().replace(/[^a-z0-9]+/g,"-")}.example`, source:"PUBLIC", text:"Fictional public-facing profile. Search for names, hosts, technology and documents to build an evidence chain."},
      {title:"Public employee directory", url:"https://directory.example/search", source:"OSINT", text:`${users.length} personnel records are indexed in the simulated public footprint.`},
      {title:"Technology profile", url:"https://tech.example/profile", source:"INTEL", text:`${hosts.length} host records are available to correlate with public information.`}
    ];
    const hay = (x) => JSON.stringify(x).toLowerCase().includes(q);
    if (hay(scenario)) {
      hosts.filter(h => hay(h)).slice(0, 8).forEach(h => results.push({
        title:`${h.hostname || h.ip} — technology profile`, url:`https://${h.hostname || h.ip}/profile`, source:"TECH", text:`${h.os || "Unknown OS"}; ${(h.services || []).map(s => `${s.port}/${s.service}`).join(", ") || "no public services listed"}.`
      }));
      users.filter(u => hay(u)).slice(0, 8).forEach(u => results.push({
        title:`${u.name} — public footprint`, url:`https://directory.example/${encodeURIComponent(u.username)}`, source:"OSINT", text:`${u.role}; ${u.email}. Lead: ${u.clue}`
      }));
      (scenario.flags || []).filter(f => hay(f)).slice(0, 6).forEach(f => results.push({
        title:`Research note: ${f.id || "objective"}`, url:"https://intel.example/note", source:"INTEL", text:`Lead: ${f.hint || "No public lead"}. Evidence must be correlated before acting.`
      }));
    }
    if (!results.length) results.push({title:"No direct result", url:"https://search.example/", source:"SEARCH", text:"Try a company name, host, username, role, technology or objective keyword. Public searches are quiet and carry no Score penalty."});
    return results;
  }
  const WIFI_NETWORKS=[
    {ssid:"Home_Network_5G",security:"WPA3-Personal",encryption:"GCMP-256",auth:"SAE",password:"SecureHome#2024",bssid:"3C:22:FB:44:55:66",channel:157,band:"5 GHz",signal:-38,ip:"192.168.1.10",speed:180,saved:true,segment:"Home / trusted LAN"},
    {ssid:"Vodafone_WiFi",security:"WPA2-Personal",encryption:"CCMP (AES)",auth:"PSK",password:"V0d4f0n3!23",bssid:"00:11:22:33:44:55",channel:1,band:"2.4 GHz",signal:-55,ip:"192.168.8.20",speed:95,saved:true,segment:"ISP / residential"},
    {ssid:"Mobile_Hotspot",security:"WPA2-Personal",encryption:"CCMP (AES)",auth:"PSK",password:"T3th3r!ng#1",bssid:"12:34:56:78:90:AB",channel:44,band:"5 GHz",signal:-40,ip:"172.20.10.2",speed:55,saved:true,segment:"Mobile / tethered"},
    {ssid:"CoffeeHouse_FreeWiFi",security:"Open",encryption:"None",auth:"Captive Portal",password:null,bssid:"02:1A:2B:3C:4D:5E",channel:6,band:"2.4 GHz",signal:-45,ip:"10.10.10.24",speed:35,saved:false,segment:"Public / coffee shop"},
    {ssid:"Airport_FreeWiFi",security:"Open",encryption:"None",auth:"Captive Portal",password:null,bssid:"00:22:44:66:88:AA",channel:36,band:"5 GHz",signal:-50,ip:"10.24.0.18",speed:75,saved:false,segment:"Public / airport"},
    {ssid:"Not_A_Honeypot",security:"WPA2-Personal",encryption:"CCMP (AES)",auth:"PSK",password:"honeypot123",bssid:"DE:AD:BE:EF:CA:FE",channel:11,band:"2.4 GHz",signal:-62,ip:"192.168.77.50",speed:20,saved:false,segment:"Unknown / suspicious"}
  ];
  function wifi(scenario) { return WIFI_NETWORKS.map((n,i)=>({...n,segment:n.segment+((scenario.network?.hosts||[])[i%(Math.max(1,(scenario.network?.hosts||[]).length))]?.hostname?` · ${(scenario.network.hosts||[])[i%(scenario.network.hosts.length)].hostname}`:'')})); }
  function files(scenario) { return Object.entries(scenario.fileContents || {}).map(([path, content]) => ({path, content})); }
  function filePaths(scenario) {
    const entries = files(scenario);
    const roots = ["/home/kali", "/home/kali/Desktop", "/home/kali/Documents", "/home/kali/Downloads", "/etc", "/var", "/tmp", "/root", "/opt", "/mnt", "/network"];
    const dirs = new Set(roots);
    entries.forEach(f => {
      const parts = String(f.path || '').split('/').filter(Boolean);
      let cur = '';
      parts.slice(0, -1).forEach(part => { cur += '/' + part; dirs.add(cur); });
    });
    return { files: entries, dirs: [...dirs].sort((a,b)=>a.localeCompare(b)) };
  }
  function simulatedSpeed(s){
    const wifi = s?.world?.wifiSignal ?? 82;
    const quality = Math.max(20, Math.min(100, wifi));
    const selected=WIFI_NETWORKS.find(n=>n.ssid===(s?.world?.wifiSsid||''));
    const baseSpeed=selected?selected.speed:Math.round(8+quality*1.15);
    const qualityFactor=quality/100;
    const protection=(s?.protection||[]).reduce((n,p)=>n+(p.id==='tor'?22:p.id==='vpn'?8:p.id==='proxy'?5:0),0);
    return Math.max(4,Math.round(baseSpeed*qualityFactor-protection));
  }
  function latencyMs(s){ return Math.round(12 + (100-simulatedSpeed(s))*1.7 + ((s?.protection||[]).some(p=>p.id==='tor')?45:0)); }
  function identityCatalog() {
    return [
      {id:"vpn", name:"VPN cover", reduction:.10, cost:.10, note:"Basic source-cover layer."},
      {id:"proxy", name:"Rotating proxy", reduction:.15, cost:.10, note:"Rotating simulated source identity."},
      {id:"tor", name:"Tor cover", reduction:.20, cost:.10, note:"Layered simulated routing; strongest single layer."},
      {id:"burner", name:"Burner identity", reduction:.05, cost:.25, note:"Limits cross-operation correlation."},
      {id:"isolation", name:"Emergency isolation relay", reduction:.50, cost:5.00, note:"Short-lived high-grade isolation."}
    ];
  }
  return { browserResults, wifi, employees, files, filePaths, identityCatalog, simulatedSpeed, latencyMs, clean };
})();

/* ===== comms.js ===== */
// comms.js — fictional Mail, ComsApp, typed phone calls, phone OSINT and location.
window.CommsWorld=(function(){
 const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
 const levels={Weak:1,Medium:2,Hard:3,Brutal:4,'Extremely Brutal':5};
 function difficultyLevel(d){return levels[d]||2;}
 function contacts(s){
   let users=Array.isArray(s.users)?s.users.slice():[];
   while(users.length<5)users.push({username:`contact${users.length+1}`,role:'Staff',email:`contact${users.length+1}@target.invalid`,phone:`+1 555 01${String(100+users.length).slice(-3)}`,osint:'No public clue catalogued.'});
   const socialPeople=window.SocialWorld?.scenarioPeople ? window.SocialWorld.scenarioPeople(s) : [];
   const topicFallback=[['football','coffee','weekend plans'],['travel','photography','food'],['technology','gaming','music'],['cycling','books','coffee'],['motorsport','football','travel']];
   return users.map((u,i)=>{
     const sp=socialPeople.find(x=>x.username===u.username || x.email===u.email);
     const topics=[...(Array.isArray(u.interests)?u.interests:[]),...(sp?.interests||[])].filter(Boolean).map(x=>String(x).toLowerCase());
     const unique=[...new Set(topics.length?topics:topicFallback[i%topicFallback.length])].slice(0,5);
     return {id:u.username||`contact-${i}`,name:u.name||u.realName||u.username||`Contact ${i+1}`,role:u.role||'Staff',email:u.email||`${u.username||'user'}@target.invalid`,phone:u.phone||`+1 555 01${String(100+i).slice(-3)}`,clue:u.osint||'No public clue catalogued.',trust:Math.max(15,72-i*8),isEmployee:true,interests:unique};
   });
 }
 function directory(s){
   const employees=contacts(s);
   const extra=(s.comms?.directory||[]).map(x=>({...x,isEmployee:false}));
   const shared=Object.values((s.world&&s.world.generatedProfiles)||{}).map((x,i)=>({id:x.id||`web-profile-${i}`,name:x.name||'Synthetic Profile',role:x.role||'External',email:x.email||'',phone:x.phone||'',clue:x.clue||'Synthetic public footprint.',trust:22,isEmployee:false,source:'CROSS-TOOL WEB PROFILE',interests:Array.isArray(x.interests)&&x.interests.length?x.interests:['football','coffee','travel']}));
   const out=[]; const seen=new Set();
   [...employees,...extra,...shared].forEach(item=>{const key=`${item.id||''}|${normalizePhone(item.phone)}|${String(item.email||'').toLowerCase()}`;if(!seen.has(key)){seen.add(key);out.push(item);}});
   return out;
 }
 function normalizePhone(v){return String(v||'').replace(/\D/g,'');}
 function phoneLookup(s,query){
   const q=normalizePhone(query); if(!q) return [];
   const known=directory(s); const exact=known.filter(x=>normalizePhone(x.phone).endsWith(q) || normalizePhone(x.phone)===q);
   if(exact.length) return exact.map(x=>({...x,source:x.isEmployee?'SCENARIO EMPLOYEE':'ADDED CONTACT',confidence:x.isEmployee?92:68}));
   const seed=q.slice(-4).padStart(4,'0');
   const last=Number(seed)||0;
   return [0,1,2].map((_,i)=>({id:`lookup-${seed}-${i}`,name:`Synthetic Record ${seed}-${i+1}`,role:['Consumer','Service desk','Unknown'][i],phone:`+1 555 ${String(100+((last+i*17)%800)).padStart(3,'0')}-${String(1000+((last*7+i*31)%8999)).padStart(4,'0')}`,email:`record-${seed}-${i+1}@lookup.invalid`,clue:['Public profile has limited information.','Number appears in a fictional directory fragment.','No reliable owner match found.'][i],trust:25+i*10,isEmployee:false,source:'FICTIONAL PHONE OSINT',confidence:35+i*12}));
 }
 function addExternal(s,kind,value,label){
   const v=String(value||'').trim(); if(!v) return null;
   s.comms ||= {}; s.comms.directory ||= []; s.comms.emails ||= [];
   if(kind==='phone'){
     const normalized=normalizePhone(v); if(normalized.length<7||normalized.length>15) return null;
     const employee=contacts(s).find(x=>normalizePhone(x.phone)===normalized); if(employee) return employee;
     const existing=s.comms.directory.find(x=>normalizePhone(x.phone)===normalized); if(existing)return existing;
     const id=`external-phone-${normalized}`; const item={id,name:label||'Added Contact',role:'External contact',phone:v,email:'',clue:'No scenario employee match.',trust:30,isEmployee:false}; s.comms.directory.push(item); return item;
   }
   if(kind==='email'){
     if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return null;
     const email=v.toLowerCase(); const employee=contacts(s).find(x=>String(x.email||'').toLowerCase()===email); if(employee) return employee;
     const existing=s.comms.emails.find(x=>String(x.email||'').toLowerCase()===email); if(existing)return existing;
     const id=`external-email-${email.replace(/[^a-z0-9]+/g,'-')}`; const item={id,name:label||'Added Email',role:'External email',email:v,phone:'',clue:'No scenario employee match.',trust:30,isEmployee:false}; s.comms.emails.push(item); return item;
   }
   return null;
 }
 function externalResponse(s,contact,channel){
   const d=difficultyLevel(window.App?.company?.difficulty || s.difficulty); if(contact?.isEmployee) return null;
   const random=Math.random();
   if(random<0.5){
     const replies=['Wrong contact — I think you meant someone else.','I don’t recognize this request, but good luck.','That information doesn’t sound right to me.','I can only say that the details you mentioned are not accurate.','You may have the wrong person.'];
     const misleading=['Yes, that sounds familiar — the team is usually at the Riverside site.','I think the person you want is in Finance, not Operations.','That project was moved last week, if I remember correctly.','You probably want to check the public service desk first.'];
     const pool=Math.random()<0.55?replies:misleading; return {text:pool[Math.floor(Math.random()*pool.length)],alert:d>=4&&Math.random()<0.25};
   }
   return {text:'Contact not available. No response was received.',unavailable:true,alert:false};
 }
 function mail(s){const c=contacts(s),d=difficultyLevel(s.difficulty);return [{id:'m1',from:`desk@${(s.name||'target').toLowerCase().replace(/[^a-z0-9]+/g,'-')}.example`,name:'Operations Desk',subject:'Routine operations update',body:'Fictional internal notice. Normal activity is expected unless another message says otherwise.',reveal:1,alert:false},...c.map((u,i)=>({id:`m-${i}`,from:u.email,name:u.name,subject:['Schedule change','Project coordination','Travel notice','Service maintenance','Team update'][i],body:`Simulated message from ${u.name}, ${u.role}. ${u.clue} ${d>=4&&i===0?'A cautious reader may notice an unusual timing detail.':''}`,reveal:Math.min(5,1+Math.floor((i+d)/2)),alert:d>=5&&i===0}))];}
 function whatsapp(s){return contacts(s).map((u,i)=>({id:u.id,name:u.name,phone:u.phone,role:u.role,messages:[{from:'contact',text:`Hi — I’m ${u.name}.`,ts:'09:12'},{from:'contact',text:`I can discuss general things. ${u.clue}`,ts:'09:14'}],guarded:difficultyLevel(s.difficulty)>=4&&i>1}));}
 function optionReply(s,c,opt,channel){const d=difficultyLevel(window.App?.company?.difficulty || s.difficulty); let q=opt, text='',xp=0,alert=false; const topicValue=String(opt||'').startsWith('topic:')?String(opt).slice(6):''; if(topicValue) q='topic'; switch(q){case'greeting':xp=3;text=`Hello! Good to hear from you.`;break;case'friends':xp=7;text=`Sure, we can get to know each other. I’m usually busy with ${c.role} work.`;break;case'info':xp=c.trust>=50?7:2;text=c.trust>=50?`A little context: ${c.clue}`:`I’d rather keep operational details general.`;alert=d>=4&&c.trust<45;break;case'identity':xp=5;text=`I’m ${c.name}, ${c.role}. That’s what my public profile says.`;break;case'role':xp=5;text=`I’m in the ${c.role} group.`;break;case'location':xp=c.trust>=55?5:1;text=c.trust>=55?'I’m usually around the general operations area.':'That’s a little personal for a new contact.';alert=d>=5&&c.trust<50;break;case'interests':xp=8;text=`I’m into ${(c.interests||['football','coffee','weekend plans']).join(', ')} when work allows.`;break;case'topic': { const topic=String(c.__topic||topicValue||'a hobby'); const known=(c.interests||[]).map(x=>String(x).toLowerCase()).includes(topic.toLowerCase()); xp=known?10:2; text=known?`Absolutely — I’m happy to talk about ${topic}. ${topic.toLowerCase()==='football'?'I follow the weekend matches and local clubs.':topic.toLowerCase()==='coffee'?'I have a favourite spot near work.':'It’s something I enjoy outside work.'}`:`I’m not sure why you’re asking about ${topic}.`; alert=d>=4&&!known; break;}case'goodbye':xp=0;text='Talk later.';break;default:text='I’m not sure what you mean.';}
 if(alert&&window.Heat)Heat.applyAlert(s,window.App?.company||{difficulty:s.difficulty,industry:'Technology',employees:1000},Math.max(1,d*1.2),`${c.name} flagged a ${channel||'ComsApp'} question`); return {text,xp,alert,heat:alert?Math.min(10,2+d):0};}
 function location(s){const d=difficultyLevel(s.difficulty),base=(s.id||1)*11;return [{name:'North Operations Campus',lat:(35+base/1000).toFixed(4),lon:(-78-base/1000).toFixed(4),confidence:78,type:'office'},{name:'Riverside Data Facility',lat:(35.02+base/1000).toFixed(4),lon:(-77.98-base/1000).toFixed(4),confidence:62,type:'data'},{name:'Transit / Remote Work Zone',lat:(35.04+base/1000).toFixed(4),lon:(-77.94-base/1000).toFixed(4),confidence:43,type:'mobile'},{name:'Restricted Research Annex',lat:(35.06+base/1000).toFixed(4),lon:(-77.90-base/1000).toFixed(4),confidence:31,type:'restricted'}].map((a,i)=>({...a,signal:Math.max(18,a.confidence-(d-1)*i*5),source:['public photo','message metadata','fictional carrier record','scenario event'][i]}));}
 function response(s,c,text){return optionReply(s,c,text,'phone');}
 return {contacts,directory,mail,whatsapp,location,optionReply,response,phoneLookup,addExternal,externalResponse,normalizePhone,esc};
})();

/* ===== web.js ===== */
// web.js — fictional, local-only web/OSINT world for Protocol Breach.
// No network requests are made. Every page is generated from scenario data.
window.WebWorld = (function(){
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const slug=s=>String(s||'target').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'target';
  const levels={Weak:1,Medium:2,Hard:3,Brutal:4,'Extremely Brutal':5};
  const models=[
    {id:'atlas',name:'Atlas Corporate',accent:'#2563eb',layout:'split',blurb:'structured corporate site'},
    {id:'ember',name:'Ember Editorial',accent:'#c2410c',layout:'magazine',blurb:'editorial-style page'},
    {id:'mint',name:'Mint Directory',accent:'#059669',layout:'directory',blurb:'directory-first site'},
    {id:'violet',name:'Violet Tech',accent:'#7c3aed',layout:'tech',blurb:'technology-focused page'},
    {id:'slate',name:'Slate Journal',accent:'#475569',layout:'journal',blurb:'journal-style page'},
    {id:'gold',name:'Gold Commerce',accent:'#b45309',layout:'commerce',blurb:'commerce landing page'},
    {id:'rose',name:'Rose Community',accent:'#be185d',layout:'community',blurb:'community hub'},
    {id:'cyan',name:'Cyan Status',accent:'#0891b2',layout:'status',blurb:'status/dashboard page'},
    {id:'forest',name:'Forest Services',accent:'#15803d',layout:'services',blurb:'services directory'},
    {id:'indigo',name:'Indigo Archive',accent:'#4338ca',layout:'archive',blurb:'archive/history page'}
  ];
  const first=['Alex','Maria','James','Sarah','Michael','Emma','Daniel','Sophia','David','Olivia','Liam','Mia','Noah','Charlotte','Ethan','Amelia','Logan','Ava','Oliver','Isabella','Ryan','Hannah','Adam','Grace','Lucas','Zoe'];
  const last=['Chen','Patel','Smith','Garcia','Kim','Brown','Jones','Taylor','Wilson','Davies','Park','Lee','Kumar','Singh','Zhang','Nguyen','Silva','Santos','Meier','Weber','Miller','Clark','Walker','Young'];
  const roles=['Analyst','Engineer','Designer','Operations','Marketing','Finance','Coordinator','Manager'];
  function hash(s){return [...String(s||'')].reduce((a,c)=>((a*31)+c.charCodeAt(0))>>>0,2166136261);}
  function pickModel(key){return models[hash(key)%models.length];}
  function domainFor(s){return slug(s.name)+'.example';}
  function fakePerson(q,j,key){const h=hash(key+'|'+j), name=`${String(q||'Guest').trim()} ${last[h%last.length]}`; return {id:`webdummy-${hash(name+'|'+key)}`,name,username:name.toLowerCase().replace(/[^a-z]+/g,'')+(h%97),email:`${name.toLowerCase().replace(/[^a-z]+/g,'.')}@mail.example`,role:roles[h%roles.length],bio:['Independent consultant and weekend football fan.','Motorsport follower who posts about local events.','General lifestyle account with no verified affiliation.','Community contributor and technology enthusiast.'][h%4],clue:'Synthetic public footprint; may contain misleading or stale information.',dummy:true};}
  function actualPeople(s){return (s.users||[]).map((u,i)=>({id:`actual-${u.username||i}`,name:u.name||u.realName||u.username||`Employee ${i+1}`,username:u.username||`employee${i+1}`,email:u.email||'',phone:u.phone||'',role:u.role||'Staff',clue:u.osint||'No public clue catalogued.',dummy:false}));}
  function pageShell(model,title,subtitle,inner){return {model:model.id,modelName:model.name,accent:model.accent,layout:model.layout,html:`<div class="synthetic-site" data-model="${esc(model.id)}" style="--site-accent:${esc(model.accent)}"><div class="site-top"><strong>${esc(title)}</strong><span>${esc(subtitle)}</span></div><div class="site-body">${inner}</div><footer>FICTIONAL LOCAL SITE · MODEL ${esc(model.name.toUpperCase())}</footer></div>`};}
  function actualPages(s){
    const d=domainFor(s), users=actualPeople(s), hosts=s.network?.hosts||[], flags=s.flags||[], model=pickModel(s.name+'|actual');
    const peopleHtml=users.map(u=>{const profileUrl=`https://${d}/people/${slug(u.username)}`; return `<article class="site-card"><h3>${esc(u.name)}</h3><p>${esc(u.role)}</p><p>${u.email?esc(u.email):'No public email listed'}${u.phone?' · '+esc(u.phone):''}</p><small>Public clue: ${esc(u.clue)}</small><div style="margin-top:8px"><button class="btn tiny" data-person-profile="${esc(profileUrl)}">Open public profile</button></div></article>`;}).join('');
    const hostHtml=hosts.map(h=>`<article class="site-card"><h3>${esc(h.hostname||h.ip)}</h3><p>${esc(h.os||'Unknown platform')}</p><p>${(h.services||[]).map(x=>`${x.port}/${x.service}`).join(' · ')||'No services listed'}</p></article>`).join('');
    const pages=[
      pageShell(model,`${s.name} · Official`,`${s.industry||'Organization'} · VERIFIED SCENARIO SOURCE`,`<h1>Public information</h1><p>This is the authoritative fictional public site for the active scenario. Information here is generated directly from the scenario dataset.</p><div class="site-grid"><article class="site-card"><b>Organization</b><p>${esc(s.name)}</p></article><article class="site-card"><b>Industry</b><p>${esc(s.industry||'Enterprise')}</p></article><article class="site-card"><b>Difficulty</b><p>${esc(s.difficulty||'Unknown')}</p></article></div>`),
      pageShell(pickModel(s.name+'|about'),`About ${s.name}`,'VERIFIED SCENARIO SOURCE',`<h1>About</h1><p>${esc(s.description||'Public organization profile.')}</p><h2>Leadership & teams</h2><div class="site-grid">${peopleHtml.slice(0,6)}</div>`),
      pageShell(pickModel(s.name+'|people'),`People Directory · ${s.name}`,'VERIFIED SCENARIO SOURCE',`<h1>Personnel</h1><p>${users.length} fictional public records.</p><div class="site-grid">${peopleHtml}</div>`),
      pageShell(pickModel(s.name+'|technology'),`Technology Profile · ${s.name}`,'VERIFIED SCENARIO SOURCE',`<h1>Public technology footprint</h1><div class="site-grid">${hostHtml}</div>`),
      pageShell(pickModel(s.name+'|careers'),`Careers · ${s.name}`,'VERIFIED SCENARIO SOURCE',`<h1>Careers</h1><p>Open roles and public descriptions can reveal technology families and team structure.</p><div class="site-card"><b>Scenario-linked role clues</b><p>${users.slice(0,4).map(u=>esc(u.role)).join(' · ')}</p></div>${(s.flags||[]).some(f=>/career|upload/i.test(`${f.description||''} ${f.hint||''}`))?`<div class="site-card"><b>Candidate application</b><p>Attach a file to the fictional application portal.</p><label>Attachment <input id="careers-file" value="" placeholder="No file selected" readonly aria-label="Careers attachment"></label><div class="row" style="gap:8px;margin-top:8px"><button class="btn tiny" data-careers-choose>Choose from files</button><button class="btn tiny" data-careers-upload>Submit application</button></div><div data-careers-result class="micro"></div></div>`:''}`),
      pageShell(pickModel(s.name+'|status'),`Service Status · ${s.name}`,'VERIFIED SCENARIO SOURCE',`<h1>Service status</h1><p>Current simulated posture: ${esc(s.difficulty||'Unknown')}.</p><div class="site-card"><b>Hosts in public footprint</b><p>${hosts.length}</p></div>`),
      pageShell(pickModel(s.name+'|archive'),`Archive · ${s.name}`,'VERIFIED SCENARIO SOURCE',`<h1>Historical references</h1><p>Older public references may explain legacy services. Compare them with the current technology profile.</p>`),
      pageShell(pickModel(s.name+'|intel'),`Exposure Monitor · ${s.name}`,'VERIFIED SCENARIO SOURCE · LEADS',`<h1>Fictional exposure monitor</h1><p>Use the evidence chain to correlate objectives with the relevant host, service or application. Leads are intentionally non-spoiling.</p><div class="site-grid">${flags.slice(0,8).map(f=>{
        const h=String(f.hint||'').toLowerCase(), desc=String(f.description||'').toLowerCase();
        let lead='Correlate this objective with the relevant host, service or application discovered during reconnaissance.';
        if(/smb|share|clientfiles/.test(h+desc)) lead='Investigate the file-sharing service associated with the file server identified during reconnaissance.';
        else if(/rdp|owa|email|roundcube/.test(h+desc)) lead='Investigate the exposed remote-access or web-mail service identified in the technology footprint.';
        else if(/career|upload|returns|zip|web shell/.test(h+desc)) lead='Investigate the relevant public web application and its upload workflow.';
        else if(/cve|vpn/.test(h+desc)) lead='Investigate the exposed remote-access service and verify the relevant vulnerability evidence.';
        else if(/api|swagger|secret|github|ci|registry|jenkins/.test(h+desc)) lead='Investigate the public development or API footprint for exposed credentials, secrets or service access.';
        else if(/s3|aws|grafana|snmp/.test(h+desc)) lead='Investigate the exposed cloud or monitoring service identified in the public technology footprint.';
        else if(/ot|pacs|medical|cctv|citrix|scada|crane|opc|satellite|edi/.test(h+desc)) lead='Correlate the objective with the specialized operational technology or legacy service identified during reconnaissance.';
        else if(/sqli|sql/.test(h+desc)) lead='Investigate the relevant public-facing application for the database-access lead found during reconnaissance.';
        return `<article class="site-card"><h3>${esc(f.description||'Scenario objective')}</h3><p>Objective lead available.</p><small>Lead: ${esc(lead)}</small></article>`;
      }).join('')}</div>`)
    ];
    const hostPages=hosts.map((h,i)=>{
      const services=(h.services||[]).map(x=>`<article class="site-card"><b>${esc(String(x.port))}/${esc(x.protocol||'tcp')}</b><p>${esc(x.service||'unknown')} · ${esc(x.product||'Unknown product')} ${esc(x.version||'')}</p></article>`).join('');
      const vulns=(h.vulnerabilities||[]).map(v=>`<article class="site-card"><b>${esc(v.name||v.id||'Scenario finding')}</b><p>${esc(v.description||'Fictional scenario finding')}</p><small>Scenario reference only · exploit family: ${esc(v.exploit||'none')}</small></article>`).join('');
      const hostTitle=`${h.hostname||h.ip} · Service Profile`;
      const hostBody=`<h1>${esc(h.hostname||h.ip)}</h1><div class="site-grid"><article class="site-card"><b>Address</b><p>${esc(h.ip||'not listed')}</p></article><article class="site-card"><b>Platform</b><p>${esc(h.os||'Unknown')}</p></article></div><h2>Services</h2><div class="site-grid">${services||'<p>No public services listed.</p>'}</div><h2>Scenario findings</h2><div class="site-grid">${vulns||'<p>No catalogued findings.</p>'}</div>`;
      return {...pageShell(pickModel(s.name+'|host|'+(h.hostname||h.ip)),hostTitle,'VERIFIED SCENARIO SOURCE · HOST',hostBody),
        url:`https://${h.hostname||h.ip}/`,title:hostTitle,type:'ACTUAL',siteStatus:'VERIFIED SCENARIO SOURCE · HOST',
        category:'tech',tags:['actual','scenario','host','technology'],host:h};
    });
    const servicePages=[];
    hosts.forEach((h)=>{
      (h.services||[]).filter(x=>/^(http|https)$/i.test(String(x.service||''))).forEach(x=>{
        const protocol=String(x.service).toLowerCase();
        const serviceUrl=`${protocol}://${h.hostname||h.ip}:${x.port}`;
        const isCctv=/cctv\.brixdental\.co\.za|203\.0\.113\.83/.test(`${h.hostname||''} ${h.ip||''}`) && Number(x.port)===8080;
        const body=`<h1>${esc(h.hostname||h.ip)} web service</h1><p>${esc(x.product||x.service||'HTTP service')} ${esc(x.version||'')}</p>${isCctv?`<div class="site-card"><b>Hikvision CCTV Login</b><p>Simulated administrative console.</p><label>Username <input data-cctv-user value="admin"></label><label>Password <input data-cctv-pass type="password" value="12345"></label><button class="btn tiny" data-cctv-login>Sign in</button><div data-cctv-result class="micro"></div></div>`:`<div class="site-card"><b>Service available</b><p>This fictional HTTP service is reachable through the local simulator.</p></div>`}`;
        servicePages.push({...pageShell(pickModel(s.name+'|service|'+serviceUrl),`${h.hostname||h.ip}:${x.port} · Service`,'VERIFIED SCENARIO SERVICE',body),url:serviceUrl,title:`${h.hostname||h.ip}:${x.port} · Service`,type:'ACTUAL',siteStatus:'VERIFIED SCENARIO SERVICE',category:'service',tags:['actual','scenario','service','http'],host:h,service:x});
      });
    });
        const peoplePages=users.map((u,i)=>{
      const person=users[i];
      const personUrl=`https://${d}/people/${slug(person.username||person.name)}`;
      return {...pageShell(pickModel(s.name+'|person|'+person.username),`${person.name} · Public Profile`, 'VERIFIED SCENARIO SOURCE · PERSON',`<h1>${esc(person.name)}</h1><p><b>Role:</b> ${esc(person.role||'Staff')}</p><p><b>Username:</b> ${esc(person.username||'')}</p><p><b>Email:</b> ${esc(person.email||'Not listed')}</p>${person.phone?`<p><b>Phone:</b> ${esc(person.phone)}</p>`:''}<div class="site-card"><b>Public OSINT clue</b><p>${esc(person.clue||'No public clue catalogued.')}</p></div>`),url:personUrl,title:`${person.name} · Public Profile`,type:'ACTUAL',siteStatus:'VERIFIED SCENARIO SOURCE · PERSON',category:'directory',tags:['actual','scenario','person','directory'],person};
    });
    const base=pages.map((p,i)=>({...p,url:`https://${d}/${['','about','people','technology','careers','status','archive','exposure'][i]}`,title:p.html.match(/<strong>(.*?)<\/strong>/)?.[1]||`${s.name} page`,type:'ACTUAL',siteStatus:'VERIFIED SCENARIO SOURCE',category:i===3?'tech':i===2?'directory':i===7?'intel':'actual',tags:['actual','scenario',p.layout]}));
    return base.concat(peoplePages,hostPages,servicePages);
  }

  function dummyPages(s,q,state){
    const query=String(q||'').trim()||'Guest'; const pages=[];
    for(let i=0;i<4;i++){
      const person=fakePerson(query,i,s.id||1); const model=models[hash(query+'|page|'+i)%models.length]; const d=`${slug(person.name)}-${hash(person.username)%997}.example`;
      const misleading=i%2===1; const body=misleading?`<h1>${esc(person.name)}</h1><p>${esc(person.bio)}</p><div class="site-card"><b>Affiliation</b><p>${i%3===0?esc(s.name):'No verified affiliation'}</p></div><div class="site-card"><b>Contact</b><p>${esc(person.email)}</p></div><small>Some information on this synthetic page is intentionally misleading or stale.</small>`:`<h1>${esc(person.name)}</h1><p>${esc(person.bio)}</p><div class="site-grid"><article class="site-card"><b>Role</b><p>${esc(person.role)}</p></article><article class="site-card"><b>Contact</b><p>${esc(person.email)}</p></article></div><p>Public footprint generated for simulation testing.</p>`;
      const shell=pageShell(model,person.name,`SYNTHETIC DUMMY · ${misleading?'MISLEADING SAMPLE':'UNVERIFIED SAMPLE'}`,body);
      pages.push({...shell,url:`https://${d}/${model.layout}/${slug(person.username)}`,title:person.name,type:'DUMMY',siteStatus:misleading?'SYNTHETIC DUMMY · MISLEADING SAMPLE':'SYNTHETIC DUMMY · UNVERIFIED SAMPLE',tags:['dummy','synthetic',model.layout],category:'dummy',profile:person,misleading});
      if(state){state.world ||= {}; state.world.generatedProfiles ||= {}; state.world.generatedProfiles[person.id]=person;}
    }
    return pages;
  }
  function pages(s,state){
    const actual=actualPages(s);
    const dummies=dummyPages(s,'',state);
    return actual.concat(dummies.slice(0,4));
  }
  function search(s,q,state){
    const query=String(q||'').trim().toLowerCase(); const actual=actualPages(s); if(!query) return actual.slice(0,12);
    const matched=actual.filter(p=>`${p.title} ${p.url} ${p.type} ${p.siteStatus} ${p.html}`.toLowerCase().includes(query));
    const dummies=dummyPages(s,q,state);
    return matched.concat(dummies).slice(0,20);
  }
  function fetch(s,url,state){
    const raw=String(url||'').trim();
    const normalized=raw.replace(/\/$/,'');
    const all=actualPages(s).concat(dummyPages(s,'lookup',state));
    return all.find(p=>String(p.url||'').replace(/\/$/,'')===normalized)||null;
  }
  function whois(s,host){const d=domainFor(s); return `WHOIS (SIMULATED)\nDomain: ${host||d}\nRegistrar: Example Registry Lab\nRegistrant: ${s.name}\nStatus: FICTIONAL / LOCAL\nNo real WHOIS query was made.`}
  function dns(s,host){const h=(s.network?.hosts||[]).find(x=>x.hostname===host||x.ip===host); return h?`DNS (SIMULATED)\nA ${h.hostname} ${h.ip}\nTXT "pb-scenario-${s.id||1}"\nNo real DNS query was made.`:`DNS (SIMULATED)\n${host}: NXDOMAIN in scenario dataset`}
  function headers(s,host){return `HTTP HEADERS (SIMULATED)\nHost: ${host}\nServer: ${s.name||'target'}-edge\nContent-Type: text/html\nX-Protocol-Breach: fictional-local\nNo real HTTP request was made.`}
  return {pages,search,fetch,whois,dns,headers,domain:domainFor,esc,models};
})();

/* ===== terminal.js ===== */
// terminal.js — local-only Unix-like terminal simulator. Commands never touch the real OS/network.
window.PB_TOOL_CATALOG = {
  nmap:['Reconnaissance & OSINT','nmap [options] <target>','Network/service discovery in the fictional scenario.'], whois:['Reconnaissance & OSINT','whois <domain>','Query simulated registration/ownership data.'], dig:['Reconnaissance & OSINT','dig [type] <domain>','Query the simulated DNS dataset.'], host:['Reconnaissance & OSINT','host <domain>','Resolve a fictional hostname.'], theharvester:['Reconnaissance & OSINT','theHarvester [options] <domain>','Aggregate fictional public emails and hosts.'], 'recon-ng':['Reconnaissance & OSINT','recon-ng [module] [options]','Run simulated modular reconnaissance.'], whatweb:['Reconnaissance & OSINT','whatweb [options] <url>','Identify simulated web technologies.'], gobuster:['Reconnaissance & OSINT','gobuster <mode> [options] <url>','Enumerate fictional paths/services.'], dirb:['Reconnaissance & OSINT','dirb <url> [wordlist]','Enumerate simulated web directories.'], curl:['Reconnaissance & OSINT','curl [options] <url>','Fetch a simulated local web resource.'], wget:['Reconnaissance & OSINT','wget [options] <url>','Retrieve a simulated local web resource.'],
  masscan:['Scanning & Enumeration','masscan [options] <target>','Fast simulated port discovery.'], nikto:['Scanning & Enumeration','nikto [options] -h <host>','Audit a simulated web service.'], enum4linux:['Scanning & Enumeration','enum4linux [options] <host>','Enumerate simulated Windows/SMB information.'], smbclient:['Scanning & Enumeration','smbclient [options] //<host>/<share>','Access a fictional SMB share.'], rpcclient:['Scanning & Enumeration','rpcclient [options] <host>','Query simulated RPC endpoints.'], snmpwalk:['Scanning & Enumeration','snmpwalk [options] <host>','Walk the simulated SNMP dataset.'], onesixtyone:['Scanning & Enumeration','onesixtyone [options] <host>','Probe simulated SNMP community strings.'], dnsrecon:['Scanning & Enumeration','dnsrecon [options] -d <domain>','Enumerate simulated DNS records.'],
  burpsuite:['Web Application Testing','burpsuite [options]','Open the simulated web testing workbench.'], sqlmap:['Web Application Testing','sqlmap [options] -u <url>','Test a fictional application for SQL injection evidence.'], wfuzz:['Web Application Testing','wfuzz [options] <target>','Run simulated web fuzzing.'], commix:['Web Application Testing','commix [options] --url <url>','Test a fictional endpoint for command-injection evidence.'], xsser:['Web Application Testing','xsser [options] -u <url>','Test a fictional endpoint for XSS evidence.'], wpscan:['Web Application Testing','wpscan [options] --url <url>','Audit a fictional WordPress installation.'], zaproxy:['Web Application Testing','zaproxy [options] <url>','Run a simulated web security scan.'],
  hydra:['Password Attacks & Cracking','hydra [options] <target>','Run a fictional credential-audit simulation.'], john:['Password Attacks & Cracking','john [options] <file>','Audit simulated password hashes.'], hashcat:['Password Attacks & Cracking','hashcat [options] <hashfile> <wordlist>','Run simulated hash-audit work.'], crunch:['Password Attacks & Cracking','crunch <min> <max> [charset]','Generate a simulated candidate wordlist.'], cewl:['Password Attacks & Cracking','cewl [options] <url>','Build a simulated wordlist from local scenario content.'], 'hash-identifier':['Password Attacks & Cracking','hash-identifier <hash>','Identify a simulated hash format.'],
  wireshark:['Network Attacks & MITM','wireshark [capture]','Open the separate simulated packet-analysis tool.'], tcpdump:['Network Attacks & MITM','tcpdump [options]','Inspect simulated packet captures.'], ettercap:['Network Attacks & MITM','ettercap [options]','Run a simulated traffic-analysis/MITM exercise.'], bettercap:['Network Attacks & MITM','bettercap [options]','Run a simulated network-analysis exercise.'], responder:['Network Attacks & MITM','responder [options]','Run a simulated credential-capture exercise.'], arpspoof:['Network Attacks & MITM','arpspoof [options] -t <host> <gateway>','Simulate ARP-spoofing analysis without real traffic.'], macchanger:['Network Attacks & MITM','macchanger [options] <interface>','Change a simulated interface identity.'],
  msfconsole:['Exploitation & Post-Exploitation','msfconsole [options]','Open the simulated exploitation console.'], searchsploit:['Exploitation & Post-Exploitation','searchsploit [options] <term>','Search the fictional exploit catalogue.'], netcat:['Exploitation & Post-Exploitation','netcat [options] <host> <port>','Open a simulated network utility session.'], ncat:['Exploitation & Post-Exploitation','ncat [options] <host> <port>','Open a simulated network utility session.'], socat:['Exploitation & Post-Exploitation','socat [options] <address> <address>','Create a simulated data relay.'], mimikatz:['Exploitation & Post-Exploitation','mimikatz [module]','Run a fictional credential-analysis simulation.'], 'powershell-empire':['Exploitation & Post-Exploitation','powershell-empire [options]','Open a simulated post-exploitation training console.'], weevely:['Exploitation & Post-Exploitation','weevely [options] <url> <password>','Simulate a fictional web-agent exercise.'],
  ssh:['System & File Utilities','ssh [options] <user>@<host>','Open a simulated remote shell session.'], scp:['System & File Utilities','scp [options] <source> <dest>','Copy files within the simulated filesystem.'], rsync:['System & File Utilities','rsync [options] <source> <dest>','Synchronize simulated files.'], grep:['System & File Utilities','grep [options] <pattern> <file>','Search simulated file contents.'], awk:['System & File Utilities','awk [options] <program> <file>','Process simulated text data.'], sed:['System & File Utilities','sed [options] <expression> <file>','Transform simulated text data.'], sort:['System & File Utilities','sort [options] <file>','Sort simulated text.'], uniq:['System & File Utilities','uniq [options] <file>','Filter repeated simulated lines.'], find:['System & File Utilities','find <path> [options]','Search the simulated filesystem.'], locate:['System & File Utilities','locate <pattern>','Search the simulated file index.'], which:['System & File Utilities','which <command>','Locate a simulated executable.'], ps:['System & File Utilities','ps [options]','List simulated processes.'], top:['System & File Utilities','top [options]','Display simulated process activity.'], htop:['System & File Utilities','htop [options]','Display the simulated interactive process view.'], kill:['System & File Utilities','kill [signal] <PID>','Signal a simulated process.'], lsof:['System & File Utilities','lsof [options]','List simulated open files/sockets.'], ss:['System & File Utilities','ss [options]','Display simulated socket state.'], netstat:['System & File Utilities','netstat [options]','Display simulated network statistics.'], strings:['System & File Utilities','strings [options] <file>','Extract printable strings from simulated files.'], binwalk:['System & File Utilities','binwalk [options] <file>','Inspect simulated binary/file signatures.'], dd:['System & File Utilities','dd [options]','Copy/transform data in the simulated filesystem.'], tar:['System & File Utilities','tar [options] <archive> [files]','Archive simulated files.'], gzip:['System & File Utilities','gzip [options] <file>','Compress simulated files.'], zip:['System & File Utilities','zip [options] <archive> <files>','Create a simulated ZIP archive.'], unzip:['System & File Utilities','unzip [options] <archive>','Extract a simulated ZIP archive.'],
  mmls:['Forensics & Reverse Engineering','mmls [options] <image>','List simulated disk partitions.'], fls:['Forensics & Reverse Engineering','fls [options] <image>','List simulated filesystem entries.'], icat:['Forensics & Reverse Engineering','icat [options] <image> <inode>','Read a simulated forensic file by inode.'], foremost:['Forensics & Reverse Engineering','foremost [options] <image>','Recover simulated files by signature.'], scalpel:['Forensics & Reverse Engineering','scalpel [options] <image>','Recover simulated files from an image.'], volatility:['Forensics & Reverse Engineering','volatility [options] <image>','Analyze a simulated memory image.'], gdb:['Forensics & Reverse Engineering','gdb [options] <file>','Open the simulated debugger.'], radare2:['Forensics & Reverse Engineering','radare2 [options] <file>','Open the simulated reverse-engineering console.'], ghidra:['Forensics & Reverse Engineering','ghidra [options] <file>','Open the simulated reverse-engineering workbench.'], apktool:['Forensics & Reverse Engineering','apktool [options] <apk>','Inspect/decode a simulated Android package.'], strace:['Forensics & Reverse Engineering','strace [options] <command>','Trace a simulated process.'], ltrace:['Forensics & Reverse Engineering','ltrace [options] <command>','Trace simulated library calls.'],
  faraday:['Reporting & Collaboration','faraday [options]','Open the simulated collaborative assessment workspace.'], dradis:['Reporting & Collaboration','dradis [options]','Open the simulated reporting workspace.'], cutycapt:['Reporting & Collaboration','cutycapt [options] --url <url>','Capture a simulated local web page.'], pipal:['Reporting & Collaboration','pipal [options] <password-file>','Generate simulated password-analysis statistics.']
};

window.Terminal = (function () {
  function resolvePath(cwd,target){let parts;if(!target)return cwd;if(target.startsWith('/'))parts=target.split('/').filter(Boolean);else parts=(cwd+'/'+target).split('/').filter(Boolean);const stack=[];parts.forEach(p=>{if(p==='.'||!p)return;if(p==='..')stack.pop();else stack.push(p)});return '/'+stack.join('/')}
  function listDirectory(s,p){return (s.filesystem||{})[p]||null}
  function getFileContent(s,p){const f=s.fileContents||{};return Object.prototype.hasOwnProperty.call(f,p)?f[p]:null}
  function flags(s,text){if(!text||!s.flags)return[];return s.flags.filter(f=>text.includes(f.id)).map(f=>f.id)}
  function host(s,ip){return (s.network?.hosts||[]).find(h=>h.ip===ip||h.hostname===ip)||null}
  function svc(s,ip,port){const h=host(s,ip);return h?(h.services||[]).find(x=>String(x.port)===String(port)):null}
  function ips(s){return (s.network?.hosts||[]).map(h=>h.ip)}
  function makeSession(st,s){
    const simSpeed=()=> (typeof World!=='undefined'&&World.simulatedSpeed)?World.simulatedSpeed(s):68;
    const simLatency=()=> (typeof World!=='undefined'&&World.latencyMs)?World.latencyMs(s):42;
    const session={currentPath:st.currentPath||'/home/kali',env:Object.assign({USER:'analyst',HOME:'/home/kali',SHELL:'/bin/bash',TERM:'xterm-256color'},s.env||{})};
    const staticOut={
      help:(a=[])=>{if(a[0]){const c=String(a[0]).toLowerCase();const docs={nmap:'nmap [target] [-sV] [-O] [-sC] — fictional network scan. Example: nmap 203.0.113.66',dns:'dns <hostname|IP> — fictional DNS lookup. Example: dns mail.example',dig:'dig <hostname|IP> — fictional DNS lookup. Example: dig mail.example',browser:'browser <query|URL> — fictional Browser/OSINT lookup. Example: browser employee',websearch:'websearch <query> — search fictional generated pages. Example: websearch Administrator',curl:'curl <URL> — fetch a fictional generated page. Example: curl https://target.example/',wifi:'wifi-status — show simulated connection state. Example: wifi-status',hydra:'hydra <target> — fictional credential audit. Example: hydra rdp://203.0.113.66',xfreerdp:'xfreerdp /v:<host> /u:<user> /p:<password> — fictional RDP client. Example: xfreerdp /v:203.0.113.66 /u:Administrator /p:Maple2020!',msfconsole:'msfconsole <module> — fictional exploitation console. Example: msfconsole eternalblue',wpscan:'wpscan --url <URL> — fictional WordPress assessment. Example: wpscan --url https://target.example/',sqlmap:'sqlmap -u <URL> — fictional SQLi assessment. Example: sqlmap -u https://target.example/login?id=1',enum4linux:'enum4linux <target> — fictional SMB enumeration. Example: enum4linux 203.0.113.67',smbclient:'smbclient //host/share — fictional SMB share access. Example: smbclient //203.0.113.67/ClientFiles$',careers:'careers <action> — fictional careers portal workflow. Example: careers inspect or careers upload payload.exe',smbmap:'smbmap -H <host> — fictional SMB permission mapping. Example: smbmap -H 203.0.113.67'};if(docs[c]) return docs[c]; const meta=window.PB_TOOL_CATALOG?.[c]; return meta?`help: ${c}\n  ${meta[1]}\n  ${meta[2]}`:`${c}: no extended help available yet. Use help for the command catalogue.`;}return `Core: ls cd cat pwd clear echo whoami hostname id uname date env history man which type file find grep head tail less strings wc sort uniq cut tr tee touch mkdir rm cp mv stat sha256sum\nSystem: ps top df du free uptime lsof mount jobs kill\nNetwork (SIMULATED): ip ifconfig route arp ss netstat ping traceroute tracepath dig dns nslookup host whois curl wget nc telnet nmap netcat\nWeb/OSINT (SIMULATED): browser websearch webopen headers dnslook whoislook robots sitemap crtsh theharvester subfinder amass recon company people technology\nSecurity training tools (SIMULATED): nikto gobuster dirb ffuf feroxbuster sqlmap wpscan enum4linux smbclient smbmap hydra medusa john hashcat responder msfconsole searchsploit\nUtility: jq base64 xxd sleep export set unset alias help man\nExtended training catalogue: ${Object.keys(window.PB_TOOL_CATALOG||{}).sort().join(' ')}\nTip: run help <command> for examples. Network tools require a simulated Wi-Fi connection.`;},
      pwd:()=>session.currentPath, whoami:()=>session.env.USER, hostname:()=>s.env?.HOSTNAME||'pb-workstation', id:()=>`uid=1000(${session.env.USER}) gid=1000(${session.env.USER}) groups=1000(${session.env.USER}),27(sudo)`, uname:()=>`Linux protocol-breach 6.6.0-pb #1 SMP PREEMPT x86_64 GNU/Linux`, date:()=>new Date().toISOString(), env:()=>Object.entries(session.env).map(([k,v])=>`${k}=${v}`).join('\n'), clear:()=> '__CLEAR__', echo:a=>a.join(' '), history:()=> (st.commandHistory||[]).map((x,i)=>`${String(i+1).padStart(4)}  ${x}`).join('\n')||'No commands in history.',
      ls:a=>{const p=a[0]?resolvePath(session.currentPath,a[0]):session.currentPath;const x=listDirectory(s,p);return x===null?`ls: cannot access '${a[0]||p}': No such directory`:x.join('  ')||'(empty)'},
      cd:a=>{const p=resolvePath(session.currentPath,a[0]||'/home/kali');if(listDirectory(s,p)===null)return`cd: ${a[0]||p}: No such directory`;session.currentPath=p;st.currentPath=p;return null},
      cat:a=>{if(!a.length)return'cat: missing file operand';const p=resolvePath(session.currentPath,a[0]);const x=getFileContent(s,p);return x===null?`cat: ${a[0]}: No such file`:x},
      head:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);return x===null?`head: ${p}: No such file`:x.split('\n').slice(0,Number((a.find(x=>/^-[0-9]+$/.test(x))||'-10').slice(1))).join('\n')},
      tail:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);return x===null?`tail: ${p}: No such file`:x.split('\n').slice(-10).join('\n')},
      wc:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);return x===null?`wc: ${p}: No such file`:`${x.split('\n').length} ${x.split(/\s+/).filter(Boolean).length} ${x.length} ${p}`},
      file:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);return x===null?`file: ${p}: No such file`:`${p}: ${p.endsWith('.log')?'ASCII text log':p.endsWith('.json')?'JSON data':'ASCII text'}`},
      stat:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');return getFileContent(s,p)===null?`stat: cannot stat '${p}'`:`File: ${p}\nSize: ${getFileContent(s,p).length}\nMode: 0644\nOwner: analyst\nType: regular file`},
      find:a=>{const q=a.find(x=>x.includes('*'))||a.find(x=>x.includes('.'))||'';const all=Object.keys(s.fileContents||{});return all.filter(p=>!q||p.includes(q.replace(/\*/g,''))).slice(0,100).join('\n')||'No matches.'},
      grep:a=>{const pattern=a.find(x=>!x.startsWith('-'))||'';const file=a.at(-1);const p=resolvePath(session.currentPath,file||'');const x=getFileContent(s,p);return x===null?`grep: ${p}: No such file`:x.split('\n').filter(l=>l.toLowerCase().includes(pattern.toLowerCase())).join('\n')||'No matches.'},
      strings:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);return x===null?`strings: ${p}: No such file`:x.split(/\s+/).filter(v=>v.length>=4).slice(0,100).join('\n')},
      sort:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);return x===null?`sort: ${p}: No such file`:x.split('\n').sort().join('\n')},
      uniq:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);return x===null?`uniq: ${p}: No such file`:[...new Set(x.split('\n'))].join('\n')},
      df:()=>`Filesystem      Size  Used Avail Use% Mounted on\npb-root          40G   12G   28G  30% /\npb-evidence      20G  4.1G   16G  21% /evidence`,
      du:()=>{const seed=Array.from(session.currentPath).reduce((n,ch)=>((n*31+ch.charCodeAt(0))>>>0),s.id||1);return `${80+(seed%221)}K\t${session.currentPath}`;},
      free:()=>`              total        used        free\nMem:        16384000     4820000    11564000\nSwap:        2097152      128000     1969152`,
      uptime:()=>` ${Math.floor((Date.now()/1000)%100000)} sec, 1 user, load average: 0.21, 0.18, 0.16`,
      ps:()=>`PID TTY          TIME CMD\n  1 ?        00:00:01 init\n 42 pts/0    00:00:00 bash\n 71 ?        00:00:02 pb-agent\n 88 ?        00:00:01 browser-sim\n103 ?        00:00:00 evidence-indexer`,
      top:()=>`PB-SIM TOP\nPID USER   CPU MEM COMMAND\n71 analyst 1.2  3.1 pb-agent\n88 analyst 0.6  2.4 browser-sim\n103 analyst 0.2  1.1 evidence-indexer`,
      which:a=>a[0]?`/usr/bin/${a[0]}`:'', type:a=>a[0]?`${a[0]} is /usr/bin/${a[0]}`:'', man:a=>`MAN (SIMULATED) — ${a[0]||'command'}\nUse help for available commands. Security/network commands operate only on fictional scenario data.`,
      ip:()=>{const n=window.PBNetworkState||{};return `ip (SIMULATED)\n1: lo 127.0.0.1\n2: eth0 ${n.connected&&n.ip?n.ip:`10.10.${s.id||1}.10`}/24\n3: tun0 10.66.${s.id||1}.2/24 (cover relay)`;},
      ifconfig:()=>{const n=window.PBNetworkState||{};return `eth0: flags=4163<UP,BROADCAST,RUNNING> inet ${n.connected&&n.ip?n.ip:`10.10.${s.id||1}.10`} netmask 255.255.255.0\ntun0: inet 10.66.${s.id||1}.2`;},
      route:()=>`Destination     Gateway         Device\n10.10.${s.id||1}.0/24  0.0.0.0         eth0\n0.0.0.0           10.10.${s.id||1}.1    tun0`,
      arp:()=> (s.network?.hosts||[]).slice(0,20).map((h,i)=>`10.10.${s.id||1}.${10+i}  02:PB:${String(i).padStart(2,'0')}:AA:10:01  ${h.hostname||h.ip}`).join('\n'),
      ss:()=>`Netid State Local Address:Port Peer Address:Port Process\ntcp LISTEN 10.10.${s.id||1}.10:4444 0.0.0.0:* pb-agent\ntcp ESTAB  10.10.${s.id||1}.10:443  10.10.${s.id||1}.21:51231 browser-sim`,
      netstat:()=>staticOut.ss(),
      ping:a=>{const ms=simLatency();return `PING ${a[0]||'target'} (SIMULATED)\n64 bytes: icmp_seq=1 ttl=57 time=${Math.max(1,ms-1)} ms\n64 bytes: icmp_seq=2 ttl=57 time=${ms} ms\n--- 2 packets transmitted, 2 received, 0% packet loss\nthroughput: ${simSpeed()} Mbps`;},
      traceroute:a=>`traceroute to ${a[0]||'target'} (SIMULATED)\n 1  10.10.${s.id||1}.1  1.2 ms\n 2  edge-gw.example  8.5 ms\n 3  ${a[0]||'target'}  17.8 ms`,
      tracepath:a=>` ${a[0]||'target'}  (SIMULATED)\n 1: 10.10.${s.id||1}.1  pmtu 1500\n 2: edge-gw.example\n 3: ${a[0]||'target'}`,
      dnslook:a=>WebWorld.dns(s,a[0]), dig:a=>WebWorld.dns(s,a[0]), dns:a=>WebWorld.dns(s,a[0]), nslookup:a=>WebWorld.dns(s,a[0]), host:a=>WebWorld.dns(s,a[0]), whoislook:a=>WebWorld.whois(s,a[0]), whois:a=>WebWorld.whois(s,a[0]), headers:a=>WebWorld.headers(s,a[0]),
      curl:a=>{const u=a.find(x=>x.startsWith('http'))||`https://${WebWorld.domain(s)}/`;const p=WebWorld.fetch(s,u);return p?`HTTP/1.1 200 OK\nServer: pb-web-sim\nContent-Type: text/html\nX-PB-Sim-Speed: ${simSpeed()} Mbps\nX-PB-Sim-Latency: ${simLatency()} ms\n\n${p.title}\n${p.body}`:`curl: (simulated) 404 Not Found ${u}`},
      wget:a=>`-- SIMULATED --\nSaving fictional response for ${a[0]||'URL'}\nNo real network request performed.`,
      browser:a=>{const r=WebWorld.search(s,a.join(' '));return r.map(x=>`${x.title}\n${x.url}\n[${x.type}] ${x.body}`).join('\n\n')},
      websearch:a=>WebWorld.search(s,a.join(' ')).map(x=>`${x.title} — ${x.url}`).join('\n'),
      webopen:a=>{const p=WebWorld.fetch(s,a[0]);return p?`${p.title}\n${p.url}\n\n${p.body}`:`webopen: no simulated page for ${a[0]||''}`},
      robots:()=>`User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /internal/\n# Fictional robots.txt`,
      sitemap:()=>WebWorld.pages(s).map(x=>x.url).join('\n'),
      crtsh:()=>WebWorld.pages(s).filter(x=>x.type==='TECH'||x.type==='PUBLIC').map(x=>`${WebWorld.domain(s)} ${x.url}`).join('\n'),
      company:()=>`${s.name}\nIndustry: ${s.industry||'unknown'}\nDifficulty: ${s.difficulty||'unknown'}\nEmployees: ${s.employees||'n/a'}\nHosts: ${(s.network?.hosts||[]).length}`,
      people:()=> (s.users||[]).slice(0,30).map(u=>`${u.name||u.username} | ${u.username||''} | ${u.role||'Staff'} | ${u.email||''}`).join('\n'),
      technology:()=> (s.network?.hosts||[]).map(h=>`${h.hostname||h.ip} | ${h.os||'unknown'} | ${(h.services||[]).map(x=>x.port+'/'+x.service).join(', ')}`).join('\n'),
      recon:()=>`RECON SUMMARY (SIMULATED)\nHosts: ${(s.network?.hosts||[]).length}\nPublic web pages: ${WebWorld.pages(s).length}\nUsers indexed: ${(s.users||[]).length}\nUse browser/websearch/dig for deeper correlation.`,
      theharvester:a=>`theHarvester (SIMULATED)\nEmail/host discovery modeled from public scenario data.\n${(s.users||[]).slice(0,10).map(u=>u.email||`${u.username||'user'}@target.invalid`).join('\n')}\nNo external sources contacted.`,
      subfinder:a=>`subfinder (SIMULATED)\nSubdomains discovered from the local scenario index:\n${WebWorld.pages(s).slice(0,8).map(x=>x.url.split('/')[2]||x.url).join('\n')}\nNo DNS enumeration performed.`,
      amass:a=>`amass (SIMULATED)\nAsset graph built from fictional scenario data.\nHosts: ${(s.network?.hosts||[]).length}\nDomains/pages: ${WebWorld.pages(s).length}\nNo real Internet enumeration performed.`,
      nmap:a=>{const target=a.find(x=>/^\d+\.\d+\.\d+\.\d+$/.test(x))||a[0];const h=host(s,target);return h?`Nmap scan report (SIMULATED)\nHost: ${h.hostname||h.ip}\n${(h.services||[]).map(v=>`${v.port}/tcp open ${v.service} ${v.version||''}`).join('\n')}\nNo real packets were sent.`:`Nmap: host ${target||'target'} not in scenario dataset.`},
      netcat:a=>`nc (SIMULATED)\nConnection to ${a[0]||'target'} ${a[1]||''} succeeded in the training sandbox. No real socket was opened.`,
      nc:a=>staticOut.netcat(a),
      telnet:a=>`Trying ${a[0]||'target'}...\nConnected (SIMULATED). Escape character is '^]'.`,
      nikto:a=>`Nikto (SIMULATED) against ${a[0]||'target'}\n- Server headers reviewed\n- 1 informational legacy endpoint\n- 0 confirmed vulnerabilities\nNo real request performed.`,
      gobuster:a=>`Gobuster (SIMULATED)\n${['/admin','/api','/status','/docs','/uploads'].map(x=>`${x} [Status: ${x==='/admin'?403:200}]`).join('\n')}`,
      dirb:a=>`DIRB (SIMULATED)\n${['/index.html','/login','/api','/backup','/robots.txt'].map(x=>`${x} CODE:200`).join('\n')}`,
      ffuf:a=>`ffuf (SIMULATED)\n${['admin','api','status','portal','legacy'].map(x=>`${x} 200`).join('\n')}`,
      feroxbuster:a=>`feroxbuster (SIMULATED)\n${['/admin','/assets','/api/v1','/health','/old'].map(x=>`${x} 200`).join('\n')}`,
      sqlmap:a=>`sqlmap (SIMULATED)\nTarget: ${a.at(-1)||'scenario endpoint'}\nResult: parameter appears interesting; no exploit executed.\nTraining-only output.`,
      wpscan:a=>`WPScan (SIMULATED)\nTarget: ${a.at(-1)||'scenario site'}\nCMS fingerprint: simulated CMS 6.x\nNo real request performed.`,
      enum4linux:()=>`enum4linux (SIMULATED)\nDomain/workgroup: PB-${s.id||1}\nHosts: ${(s.network?.hosts||[]).length}\nNo real SMB queries performed.`,
      smbclient:a=>`smbclient (SIMULATED)\nSharename  Type  Comment\nPUBLIC     Disk  Fictional shared documents\nARCHIVE    Disk  Fictional historical material`,
      smbmap:()=>`smbmap (SIMULATED)\nPUBLIC READ\nARCHIVE READ\nADMIN ACCESS DENIED`,
      hydra:()=>`hydra (SIMULATED)\nLogin attempt sequence modeled locally. No credentials were sent.\nResult: training target throttled after 5 attempts.`,
      medusa:()=>`medusa (SIMULATED)\nAuthentication test modeled locally. No credentials were transmitted.`,
      john:()=>`John the Ripper (SIMULATED)\nHash candidate analysis modeled locally. No cracking performed against real hashes.`,
      hashcat:()=>`Hashcat (SIMULATED)\nWorkload modeled locally. Use scenario clues to select a candidate; no real credential cracking.`,
      responder:()=>`Responder (SIMULATED)\nListener state: training-only. No network listener was opened.`,
      msfconsole:()=>`Metasploit Console (SIMULATED)\nmsf6 > use scenario/module\nmsf6 > show options\nThis console is a non-operational training facade.`,
      searchsploit:a=>`SearchSploit (SIMULATED)\n${a.join(' ')||'query'}\n0 real exploit databases were contacted. Scenario knowledge base only.`,
      exploit:()=>`exploit (SIMULATED)\nAction staged in the training model. No payload was executed and no real target was contacted.`,
      less:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);return x===null?`less: ${p}: No such file`:x},
      cut:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);if(x===null)return`cut: ${p}: No such file`;return x.split('\n').map(l=>l.split(/\s+/).slice(0,2).join('\t')).join('\n')},
      tr:a=>a.length>=2?`tr (SIMULATED): ${a[0]} → ${a[1]}`:'tr: missing operand',
      tee:a=>{const name=a.find(x=>!x.startsWith('-'))||'output.txt';const p=resolvePath(session.currentPath,name);return `tee (SIMULATED): captured terminal output to ${p}`},
      touch:a=>a.length?`touch (SIMULATED): created ${a.join(', ')}`:'touch: missing file operand',
      mkdir:a=>a.length?`mkdir (SIMULATED): created ${a.join(', ')}`:'mkdir: missing operand',
      rm:a=>a.length?`rm (SIMULATED): removed ${a.join(', ')}`:'rm: missing operand',
      cp:a=>a.length>=2?`cp (SIMULATED): ${a[0]} → ${a[1]}`:'cp: missing file operand',
      mv:a=>a.length>=2?`mv (SIMULATED): ${a[0]} → ${a[1]}`:'mv: missing file operand',
      sha256sum:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);if(x===null)return`sha256sum: ${p}: No such file`;let h=2166136261;for(let i=0;i<x.length;i++){h^=x.charCodeAt(i);h=Math.imul(h,16777619)}return `${(h>>>0).toString(16).padStart(8,'0').repeat(8)}  ${p}`},
      lsof:()=>`COMMAND PID USER FD TYPE DEVICE NAME\npb-agent 71 analyst 12u IPv4 SIM tcp *:4444 (LISTEN)\nbrowser-sim 88 analyst 9u IPv4 SIM tcp *:443 (ESTABLISHED)`,
      mount:()=>`/dev/pb-root on / type ext4 (ro,simulated)\npb-evidence on /evidence type ext4 (rw,simulated)`,
      jobs:()=>`[1]+ Running    pb-evidence-indexer (SIMULATED)`,
      kill:a=>`kill (SIMULATED): signal ${a[0]||'TERM'} sent to PID ${a[1]||'71'}; no real process affected.`,
      export:a=>{const m=String(a[0]||'').match(/^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/);if(m)session.env[m[1]]=m[2];return null},
      set:()=>Object.entries(session.env).map(([k,v])=>`${k}=${v}`).join('\n'),
      unset:a=>{(a||[]).forEach(k=>delete session.env[k]);return null},
      alias:a=>a.length?`alias ${a[0]}='${a.slice(1).join(' ')}'`:'alias ll="ls -la"',
      jq:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);if(x===null)return`jq: ${p}: No such file`;try{return JSON.stringify(JSON.parse(x),null,2)}catch(e){return`jq: parse error in ${p}`}},
      base64:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);if(x===null)return`base64: ${p}: No such file`;return btoa(unescape(encodeURIComponent(x)))},
      xxd:a=>{const p=resolvePath(session.currentPath,a.at(-1)||'');const x=getFileContent(s,p);if(x===null)return`xxd: ${p}: No such file`;return Array.from(x).slice(0,64).map((c,i)=>`${i.toString(16).padStart(8,'0')}: ${c.charCodeAt(0).toString(16).padStart(2,'0')}`).join('\n')},
      sleep:a=>`sleep (SIMULATED) ${a[0]||'1'}s — command returns immediately in the browser simulator.`
    };
    function extendedTool(cmd,args){
      const meta=window.PB_TOOL_CATALOG?.[cmd]; if(!meta) return undefined;
      if(args.includes('--help') || args.includes('-h')) return `${meta[1]}\n\n${meta[2]}\nSIMULATION: all input is local and fictional; supported option syntax is accepted by the simulator parser.`;
      const hosts=(s.network?.hosts||[]);
      const target=args.find(a=>!a.startsWith('-') && !/^\//.test(a)) || hosts[0]?.ip || '203.0.113.1';
      const host=hosts.find(h=>h.ip===target || h.hostname===target || (h.domains||[]).includes(target)) || hosts[0];
      const services=(host?.services||[]).map(v=>`${v.port}/${v.protocol||'tcp'} ${v.service||v.name||'service'}`).join(', ') || 'no matching service data';
      const domains=hosts.flatMap(h=>h.domains||[]).slice(0,8);
      const users=(s.users||[]).slice(0,8).map(u=>u.username||u.email||u.name).filter(Boolean);
      const files=Object.keys(s.fileContents||{}).slice(0,8);
      let body='';
      switch(meta[0]){
        case 'Reconnaissance & OSINT': body=`[SIMULATED ${cmd}]\nTarget: ${target}\nHosts: ${hosts.length}\nKnown domains: ${domains.join(', ')||'none'}\nRelevant services: ${services}\nEvidence source: active scenario dataset.`; break;
        case 'Scanning & Enumeration': body=`[SIMULATED ${cmd}]\nTarget: ${target}\nHost: ${host?.hostname||host?.ip||target}\nServices: ${services}\nEnumeration records: ${users.length?users.join(', '):'none'}\nNo real packets or services were contacted.`; break;
        case 'Web Application Testing': body=`[SIMULATED ${cmd}]\nTarget: ${target}\nWeb services in scenario: ${hosts.flatMap(h=>(h.services||[]).filter(v=>String(v.port)==='80'||String(v.port)==='443'||String(v.protocol||'').toLowerCase()==='http').map(v=>String(v.port)+'/'+String(v.protocol||'http')).slice(0,10).join(', ')||'none')}\nResult: scenario-aware test completed; consult verified Browser/OSINT evidence for objective-grade findings.`; break;
        case 'Password Attacks & Cracking': body=`[SIMULATED ${cmd}]\nCandidate input: ${args.filter(a=>!a.startsWith('-')).join(' ')||'(none)'}\nKnown fictional accounts: ${users.join(', ')||'none'}\nResult: credential-audit simulation completed. No real credentials were attacked.`; break;
        case 'Network Attacks & MITM': body=`[SIMULATED ${cmd}]\nInterface/target: ${target}\nCapture state: fictional training traffic only\nResult: analysis completed without touching a real network interface.`; break;
        case 'Exploitation & Post-Exploitation': body=`[SIMULATED ${cmd}]\nTarget: ${target}\nScenario services: ${services}\nResult: training simulation completed. Objective evidence is awarded only by the scenario's canonical evidence handlers.`; break;
        case 'System & File Utilities': { const f=args.find(a=>!a.startsWith('-')); body=`[SIMULATED ${cmd}]\nPath/argument: ${f||s.currentPath||'/home/kali'}\nAvailable scenario files: ${files.join(', ')||'none'}\nResult: utility operation completed in the fictional filesystem.`; break; }
        case 'Forensics & Reverse Engineering': body=`[SIMULATED ${cmd}]\nInput: ${target}\nArtifacts available: ${files.join(', ')||'none'}\nResult: forensic/reverse-engineering operation completed against scenario-contained data.`; break;
        case 'Reporting & Collaboration': body=`[SIMULATED ${cmd}]\nWorkspace: ${s.name||'active scenario'}\nResult: reporting/collaboration action completed locally.`; break;
      }
      return body+`\nOptions received: ${args.length?args.join(' '):'(default)'}`;
    }
    function scenarioCmd(cmd,args){if(!s.commands||!s.commands[cmd])return undefined;const h=s.commands[cmd];const fn=typeof h==='function'?h:(h.handler||null);if(!fn)return undefined;try{return fn(args,s,{currentPath:session.currentPath,flagsFound:st.flagsFound,findFlagInText:t=>flags(s,t),resolvePath:t=>resolvePath(session.currentPath,t),listDirectory:p=>listDirectory(s,p),getFileContent:p=>getFileContent(s,p),printLine:()=>{},scenario:s,env:session.env,getHostByIP:i=>host(s,i),getServiceByIPPort:(i,p)=>svc(s,i,p),getAllIPs:()=>ips(s)})}catch(e){return`Error executing ${cmd}: ${e.message}`}}
    const WIFI_REQUIRED_COMMANDS=new Set(['ping','traceroute','tracepath','dig','dns','nslookup','host','whois','whoislook','headers','curl','wget','nc','netcat','telnet','nmap','browser','websearch','webopen','robots','sitemap','crtsh','theharvester','subfinder','amass','recon','company','people','technology','shodan','searchsploit','gobuster','dirb','ffuf','feroxbuster','nikto','wpscan','enum4linux','smbclient','smbmap','hydra','medusa','responder','msfconsole','sqlmap','exploit']);
    function wifiState(){
      // The active mission state is the single source of truth. PBNetworkState is only a UI bridge.
      const worldState=window.App?.scnState?.world || st?.world || {};
      const connected=Boolean(worldState.wifiSsid && worldState.wifiIp);
      if(connected){
        window.PBNetworkState={connected:true,ssid:String(worldState.wifiSsid),ip:String(worldState.wifiIp),speed:Number(worldState.wifiSpeed)||0,security:String(worldState.wifiSecurity||''),detectionReduction:Number(worldState.wifiDetectionReduction)||0,connectedAt:Number(worldState.wifiConnectedAt)||Date.now()};
      } else {
        window.PBNetworkState={connected:false,ssid:'',ip:'',speed:0,security:'',detectionReduction:0};
      }
      return {connected,ssid:connected?String(worldState.wifiSsid):'',ip:connected?String(worldState.wifiIp):'',speed:connected?(Number(worldState.wifiSpeed)||0):0,latency:connected&&window.World?.latencyMs?window.World.latencyMs(window.App?.scnState||s):'—'};
    }
    function execute(input){const trimmed=(input||'').trim();if(!trimmed)return{output:null,cleared:false,flagsFound:[],cmdName:null};st.commandHistory.push(trimmed);if(st.commandHistory.length>300)st.commandHistory.shift();const parts=trimmed.split(/\s+/),cmd=parts[0].toLowerCase(),args=parts.slice(1);let output;const net=wifiState();if(cmd==='wifi-status'||cmd==='wifi'){output=net.connected?`Wi-Fi (SIMULATED): CONNECTED\nSSID: ${net.ssid}\nIP: ${net.ip}\nSpeed: ${net.speed} Mbps\nLatency: ${net.latency} ms`:`Wi-Fi (SIMULATED): DISCONNECTED\nConnect using the Wi-Fi Scanner.`;}else if(WIFI_REQUIRED_COMMANDS.has(cmd) && !net.connected){output=`${cmd}: no simulated network connection. Connect to Wi-Fi first using the Wi-Fi Scanner.`;}else { const scenarioOutput=scenarioCmd(cmd,args); output=scenarioOutput!==undefined?scenarioOutput:(staticOut[cmd]?staticOut[cmd](args):extendedTool(cmd,args)); }
      // Canonicalize successful RDP access across scenarios: objective/evidence state must not depend on a handler remembering to print a flag.
      if(cmd==='xfreerdp' && typeof output==='string' && /(?:login successful|access to legacy|rdp session established)/i.test(output)){
        const gameState=window.App?.scnState;
        const accessFlag=(s.flags||[]).find(f=>/(rdp|owa|initial.?access|zero.?trust)/i.test(`${f.id} ${f.description}`));
        if(accessFlag && !output.includes(accessFlag.id)) output += `\n[+] Flag: ${accessFlag.id} (RDP access)`;
        if(gameState){ gameState.world ||= {}; const rdpTarget=(args.find(x=>/^\d+\.\d+\.\d+\.\d+$/.test(x))||args.find(x=>x.startsWith('/v:'))?.slice(3)||'203.0.113.66'); const rdpUser=args.find(x=>x.startsWith('/u:'))?.slice(3)||''; gameState.world.rdpSession={active:true,target:rdpTarget,username:rdpUser,startedAt:Clock.now()}; gameState.log.unshift({ts:Clock.now(),type:'access',text:`RDP session established on ${rdpTarget}${rdpUser?` as ${rdpUser}`:''}.`}); }
      }
      if(output===undefined){const known=Object.keys(staticOut).concat(Object.keys(s.commands||{}),['wifi-status','wifi']);const dist=(a,b)=>{const d=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){let prev=d[0];d[0]=i;for(let j=1;j<=b.length;j++){const cur=d[j];d[j]=Math.min(d[j]+1,d[j-1]+1,prev+(a[i-1]===b[j-1]?0:1));prev=cur;}}return d[b.length];};const candidates=[...new Set(known)].filter(x=>x.length>2).map(x=>[dist(cmd,x),x]).sort((a,b)=>a[0]-b[0]);const suggestion=candidates[0]&&candidates[0][0]<=2?`\nDid you mean: ${candidates[0][1]}?`:'';output=`bash: ${cmd}: command not found${suggestion}\nType \`help\` for available commands.`;}if(output==='__CLEAR__')return{output:null,cleared:true,flagsFound:[],cmdName:cmd};const found=flags(s,String(output));found.forEach(f=>{if(!st.flagsFound.includes(f))st.flagsFound.push(f)});return{output:output===null?null:String(output),cleared:false,flagsFound:found,cmdName:cmd}}
    return{execute,session}
  }
  return{makeSession,resolvePath,listDirectory,getFileContent,findFlagInText:flags,getHostByIP:host,getServiceByIPPort:svc,getAllIPs:ips};
})();

/* ===== scenario.js ===== */
// scenario.js — synchronous, function-preserving embedded scenario loader
// No dynamic script loading. Master scenario data is never mutated.
window.ScenarioLoader = (function () {
  function clone(value, seen) {
    if (value === null || typeof value !== "object") return value;
    if (typeof value === "function") return value;
    seen ||= new WeakMap();
    if (seen.has(value)) return seen.get(value);
    if (Array.isArray(value)) {
      const out = []; seen.set(value, out);
      value.forEach((v, i) => out[i] = clone(v, seen));
      return out;
    }
    const out = {}; seen.set(value, out);
    Object.keys(value).forEach(k => out[k] = clone(value[k], seen));
    return out;
  }
  function normalize(company, source) {
    if (!source || typeof source !== "object") throw new Error(`Scenario ${company?.id || "?"} is unavailable.`);
    const scenario = clone(source);
    const required = ["network", "users", "filesystem", "fileContents", "commands"];
    required.forEach(k => { if (scenario[k] == null) throw new Error(`Scenario ${company.id} is missing ${k}.`); });
    scenario.id = Number(company.id);
    scenario.name = company.name;
    scenario.industry = company.industry;
    scenario.employees = company.employees;
    scenario.difficulty = company.difficulty;
    scenario.tagline = company.tagline;
    scenario.users = Array.isArray(scenario.users) ? scenario.users : [];
    scenario.network.hosts = Array.isArray(scenario.network.hosts) ? scenario.network.hosts : [];
    scenario.fileContents = scenario.fileContents || {};
    scenario.commands = scenario.commands || {};
    return scenario;
  }
  function load(company, cb) {
    try {
      const id = Number(company && company.id);
      const source = window.SCENARIO_LIBRARY && window.SCENARIO_LIBRARY[id];
      if (!source) throw new Error(`Scenario ${id || "?"} is not bundled or registered.`);
      cb(null, normalize(company, source));
    } catch (e) {
      cb(new Error(`Scenario ${company && company.id ? company.id : "?"} failed to initialize: ${e.message}`));
    }
  }
  function get(id) {
    const company = (window.COMPANIES || []).find(c => Number(c.id) === Number(id));
    if (!company) throw new Error(`Unknown scenario ${id}.`);
    const source = window.SCENARIO_LIBRARY?.[company.id];
    return normalize(company, source);
  }
  return { load, get };
})();

/* ===== mission-time.js ===== */
// mission-time.js — difficulty-scaled time pressure and score ceilings.
window.MissionTime = (function () {
  const RULES = window.MISSION_TIME_RULES || {};
  const CAPS = Array.isArray(RULES.scoreCaps) ? RULES.scoreCaps : [80,70,55,40,20];
  const FACTORS = Array.isArray(RULES.scoreThresholdFactors) ? RULES.scoreThresholdFactors : [0.15,0.175,0.20,0.225,0.25];
  const SCALE = RULES.difficultyScale || {};
  const TIMEOUT_FACTOR = Number(RULES.timeoutFactor) || 0.30;
  const safeNum=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
  function objectiveDifficulty(o){
    const n=safeNum(o?.objectiveDifficulty,NaN);
    if(Number.isFinite(n)) return Math.max(1,Math.min(10,n));
    const n2=safeNum(o?.difficulty,NaN);
    if(Number.isFinite(n2)) return Math.max(1,Math.min(10,n2));
    const map={"Very Easy":1,Easy:3,Moderate:5,Hard:7,"Very Hard":9,Extreme:10};
    return map[o?.difficulty] || 5;
  }
  function objectiveTime(o){
    const d=objectiveDifficulty(o), scale=SCALE[d] || SCALE[5] || {min:8,max:20};
    const min=Number(scale.min), max=Number(scale.max);
    const slack=(min/3)*(0.5/d);
    const total=(min+(max+slack))/2+slack;
    return {difficulty:d,min,max,slack,time:total};
  }
  function objectivePlan(s,scenario){
    const m=window.Mission?.ensure ? window.Mission.ensure(s,scenario) : (s?.mission||{});
    const objectives=Object.values(m.objectives||{});
    const rows=objectives.map(o=>({id:o.id,description:o.description,...objectiveTime(o)}));
    const total=rows.reduce((a,r)=>a+r.time,0);
    const thresholds=FACTORS.map(f=>total*f);
    return {objectives:rows,total,thresholds,timeout:total*TIMEOUT_FACTOR};
  }
  function ensurePlan(s,scenario){
    const plan=objectivePlan(s,scenario);
    s.timePlan={objectiveTimes:plan.objectives,totalMinutes:plan.total,thresholds:plan.thresholds,timeoutMinutes:plan.timeout};
    return plan;
  }
  function isActive(){
    return !!(document.body.classList.contains('scenario-mode') && document.visibilityState!=='hidden' && navigator.onLine!==false);
  }
  function pause(s){
    if(!s || !s.activeTimeSince) return;
    s.activeElapsedMs=safeNum(s.activeElapsedMs,0)+Math.max(0,Clock.now()-Number(s.activeTimeSince));
    s.activeTimeSince=null;
  }
  function resume(s){
    if(!s || s.completed || s.timedOut || !isActive()) return;
    if(!s.activeTimeSince) s.activeTimeSince=Clock.now();
  }
  function elapsedMs(s){
    if(!s) return 0;
    const base=safeNum(s.activeElapsedMs,0);
    const live=s.activeTimeSince && isActive() ? Math.max(0,Clock.now()-Number(s.activeTimeSince)) : 0;
    return base+live;
  }
  function minutes(s){ return elapsedMs(s)/60000; }
  function apply(s,company){
    if(!s || !company) return {stage:0,cap:100,elapsed:0,gameOver:false};
    const plan=ensurePlan(s,window.App?.scenario);
    if(s.completed || s.timedOut) return {stage:Number(s.timeStage)||0,cap:Number(s.timeScoreCap)||100,elapsed:minutes(s),gameOver:!!s.timedOut,thresholds:plan.thresholds,timeout:plan.timeout};
    const mins=minutes(s);
    let stage=0;
    while(stage<FACTORS.length && mins>=plan.thresholds[stage]) stage++;
    if(mins>=plan.timeout){
      pause(s); s.timeStage=5; s.timeScoreCap=20; s.timedOut=true; s.score=Math.min(Number(s.score)||0,20);
      s.mission ||= {objectives:{},evidence:[],milestones:[],completedAt:null,outcome:'IN_PROGRESS'};
      s.mission.outcome='TIMEOUT'; s.mission.completedAt=Clock.now();
      s.log ||= []; s.log.unshift({ts:Clock.now(),type:'system',text:`Mission time limit exceeded for ${company.name}. The operation has been terminated.`});
      return {stage:5,cap:20,elapsed:mins,gameOver:true,thresholds:plan.thresholds,timeout:plan.timeout};
    }
    const cap=stage>0?CAPS[stage-1]:100;
    if(stage>Number(s.timeStage||0)){
      s.timeStage=stage; s.timeScoreCap=cap;
      const before=Math.round(Number(s.score)||0); s.score=Math.min(Number(s.score)||0,cap);
      s.timePenaltyHistory ||= [];
      s.timePenaltyHistory.push({stage,at:Clock.now(),elapsedMinutes:Math.round(mins*10)/10,cap,scoreBefore:before,scoreAfter:Math.round(s.score),scoreReduction:Math.max(0,before-Math.round(s.score))});
      s.log ||= []; s.log.unshift({ts:Clock.now(),type:'system',text:`Time threshold ${stage} reached: maximum score reduced to ${cap}.`});
    } else { s.timeScoreCap=cap; if(Number(s.score)>cap) s.score=cap; }
    return {stage,cap,elapsed:mins,gameOver:false,nextThreshold:Number(plan.thresholds[stage]||plan.timeout),thresholds:plan.thresholds,timeout:plan.timeout,plan};
  }
  function snapshot(s){ return {score:Number(s?.score)||0,reputation:Number(s?.reputation)||0,credits:Number(s?.credits)||0,heat:Number(s?.heat)||0,assessments:Number(s?.assessmentEarnings)||0,assessmentCount:Number(s?.assessmentHistoryCount)||0,cashSpent:Number(s?.actionStats?.creditsSpent)||0,cashEarned:Number(s?.actionStats?.creditsEarned)||0}; }
  function durationLabel(ms){ const total=Math.max(0,Math.floor(ms/1000)), h=Math.floor(total/3600), m=Math.floor((total%3600)/60), sec=total%60; return h?`${h}h ${String(m).padStart(2,'0')}m ${String(sec).padStart(2,'0')}s`:`${m}m ${String(sec).padStart(2,'0')}s`; }
  return {objectiveDifficulty,objectiveTime,objectivePlan,ensurePlan,isActive,pause,resume,elapsedMs,minutes,apply,snapshot,durationLabel,CAPS,FACTORS};
})();

/* ===== mission.js ===== */
// mission.js — objective/evidence/consequence layer. Everything is fictional and scenario-contained.
window.Mission = (function () {
  const REP_BY_INDEX = [1,1,2,2,3,4];
  function ensure(s, scenario){
    s.mission ||= { objectives:{}, evidence:[], milestones:[], completedAt:null, outcome:"IN_PROGRESS" };
    (scenario.flags||[]).forEach((f,i)=>{
      if(!s.mission.objectives[f.id]) {
        const d = Number.isFinite(Number(f.objectiveDifficulty)) ? Math.max(1,Math.min(10,Number(f.objectiveDifficulty))) : inferDifficulty(i, scenario);
        s.mission.objectives[f.id] = { id:f.id, description:f.description, difficulty:f.difficulty||difficultyName(d<=5?d:Math.ceil(d/2)), objectiveDifficulty:d, status:"LOCKED", completedAt:null, repAwarded:0 };
      } else if(!s.mission.objectives[f.id].objectiveDifficulty) {
        s.mission.objectives[f.id].objectiveDifficulty = inferDifficulty(i,scenario);
      }
    });
    return s.mission;
  }
  function inferDifficulty(i, scenario){
    const base = {Weak:2,Medium:4,Hard:6,Brutal:8,"Extremely Brutal":9}[scenario.difficulty] || 4;
    return Math.min(10, Math.max(1, base + i));
  }
  function difficultyName(n){ return n<=2?"Very Easy":n<=4?"Easy":n<=6?"Moderate":n<=8?"Hard":n===9?"Very Hard":"Extreme"; }
  function sync(s, scenario){
    const m=ensure(s,scenario), flags=s.flagsFound||[];
    Object.values(m.objectives).forEach((o,i)=>{
      if(flags.includes(o.id) && o.status!=="COMPLETE"){
        o.status="COMPLETE"; o.completedAt=Clock.now();
        const rep=REP_BY_INDEX[Math.min(5,o.difficulty)]||1;
        o.repAwarded=rep;
      } else if(o.status!=="COMPLETE") {
        const previous=Object.values(m.objectives).find(x=>x.id!==o.id && x.status==="COMPLETE");
        o.status = previous ? "AVAILABLE" : (i===0 ? "AVAILABLE" : "LOCKED");
      }
    });
    return m;
  }
  function recordFlag(s, scenario, flagId){
    const m=ensure(s,scenario); const o=m.objectives[flagId];
    if(!o || o.status==="COMPLETE") return {new:false,rep:0};
    o.status="COMPLETE"; o.completedAt=Clock.now();
    const rep=REP_BY_INDEX[Math.min(5,o.difficulty)]||1;
    o.repAwarded=rep;
    s.mission.evidence.push({ts:Clock.now(),kind:"OBJECTIVE",id:flagId,text:o.description});
    s.mission.milestones.unshift({ts:Clock.now(),text:`Objective complete: ${o.description}`});
    return {new:true,rep};
  }
  function completeObjective(s, scenario, matcher){
    const m=ensure(s,scenario);
    let id = typeof matcher === "string" && m.objectives[matcher] ? matcher : null;
    if(!id){
      const needle=String(matcher||'').toLowerCase();
      const found=Object.values(m.objectives).find(o=>String(o.description||'').toLowerCase()===needle);
      id=found?.id || null;
    }
    if(!id) return {new:false,rep:0,id:null};
    const r=recordFlag(s,scenario,id);
    if(!Array.isArray(s.flagsFound)) s.flagsFound=[];
    if(!s.flagsFound.includes(id)) s.flagsFound.push(id);
    sync(s,scenario);
    return {...r,id};
  }
  function onFlags(s,player,scenario,flags){
    let rep=0;
    (flags||[]).forEach(id=>{ const r=recordFlag(s,scenario,id); if(r.new) rep+=r.rep; });
    if(rep){ s.reputation=State.clamp(s.reputation+rep,0,20); s.log.unshift({ts:Clock.now(),type:"objective",text:`Objective reward: Reputation +${rep}.`}); }
    return rep;
  }
  function progress(s,scenario){
    const m=sync(s,scenario), arr=Object.values(m.objectives); const done=arr.filter(o=>o.status==="COMPLETE").length;
    return {done,total:arr.length,pct:arr.length?Math.round(done/arr.length*100):100,next:arr.find(o=>o.status==="AVAILABLE")||null,objectives:arr};
  }
  function outcome(s,scenario){
    const p=progress(s,scenario); if(p.done===p.total) return "COMPLETE"; if(s.score<=0) return "COMPROMISED"; if(s.responseLevel>=5) return "CRITICAL"; return "PARTIAL";
  }
  return {ensure,sync,recordFlag,completeObjective,onFlags,progress,outcome,difficultyName};
})();

/* ===== social.js ===== */
// social.js — fictional Instagram-like social world. All data is local and synthetic.
window.SocialWorld = (function(){
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const levels={Weak:1,Medium:2,Hard:3,Brutal:4,'Extremely Brutal':5};
  const first=['Alex','Maria','James','Sarah','Michael','Emma','Daniel','Sophia','David','Olivia','Liam','Mia','Noah','Charlotte','Ethan','Amelia','Logan','Ava','Oliver','Isabella','Ryan','Hannah','Adam','Grace','Lucas','Zoe'];
  const last=['Chen','Patel','Smith','Garcia','Kim','Brown','Jones','Taylor','Wilson','Davies','Park','Lee','Kumar','Singh','Zhang','Nguyen','Silva','Santos','Meier','Weber','Miller','Clark','Walker','Young'];
  const interests=['football','travel','coffee','photography','gaming','music','cycling','food','technology','weekend football','F1','rally','motorsport','fitness','books'];
  const clubs=['Northbridge FC','Riverside United','Harbor City Athletic','Metro Rovers','Eastgate Town','Kingsport FC','Westhaven Rovers'];
  const tags=['football','motorsport','lifestyle','news'];
  const TOTAL_PROFILES=300;
  const generated=new Map();
  function level(s){return levels[s?.difficulty]||2;}
  function seedName(i){return first[i%first.length]+' '+last[(i*7)%last.length];}
  function category(i){const n=i%20; return n<7?'football':n<12?'motorsport':n<18?'lifestyle':'news';}
  function postCountFor(i){return i<100?0:i<150?1:i<280?2:5;}
  function makeProfile(i){const name=seedName(i), handle='@'+name.toLowerCase().replace(/[^a-z]+/g,'')+(i+1); const cat=category(i); const count=postCountFor(i); return {id:'fake-'+(i+1),name,handle,role:['Engineer','Analyst','Designer','Operations','Marketing','Finance'][i%6],bio:['Weekend football and coffee.','Cars, circuits and travel.','Just trying to enjoy the week.','Following the news and local life.'][i%4],interests:[interests[i%interests.length],interests[(i+5)%interests.length]],club:clubs[i%clubs.length],category:cat,postCount:count,private:count===0,scenario:null,isScenario:false,avatar:`assets/social/generated/post-${String(i%60).padStart(3,'0')}.svg`};}
  function getProfile(i){if(i<0||i>=TOTAL_PROFILES)return null;if(!generated.has(i))generated.set(i,makeProfile(i));return generated.get(i);}
  function generateRange(offset,count){const out=[];const end=Math.min(TOTAL_PROFILES,offset+count);for(let i=Math.max(0,offset);i<end;i++)out.push(getProfile(i));return out;}
  function ensure(){return generateRange(0,10);}
  function scenarioPeople(s){return (s?.users||[]).slice(0,8).map((u,i)=>({id:'scenario-'+(u.username||i),name:u.name||u.realName||u.username||`Employee ${i+1}`,handle:'@'+String(u.username||u.name||`employee${i+1}`).toLowerCase().replace(/[^a-z0-9]+/g,''),role:u.role||'Staff',email:u.email||'',phone:u.phone||'',bio:'Fictional employee profile tied to the active scenario.',interests:[interests[i%interests.length],interests[(i+3)%interests.length]],club:clubs[(i+(s.id||1))%clubs.length],category:i%4===0?'football':i%4===1?'motorsport':'lifestyle',postCount:i%3===0?2:1,private:false,scenario:s.id,isScenario:true,clue:u.osint||'No public clue catalogued.',avatar:`assets/social/generated/post-${String((i*9+(s.id||1))%60).padStart(3,'0')}.svg` }));}
  function search(s,q){
    const qq=String(q||'').trim().toLowerCase();
    const sp=scenarioPeople(s);
    const shared=Object.values((s.world&&s.world.generatedProfiles)||{}).map(p=>({ ...p, isScenario:false, private:false, postCount:1, category:'lifestyle', interests:p.interests||['general life'], club:p.club||'Community', avatar:p.avatar||'assets/social/generated/post-001.svg' }));
    if(!qq) return sp.slice(0,4).concat(shared.slice(0,4)).concat(generateRange(0,10)).slice(0,14);
    const exact=sp.concat(shared).filter(p=>JSON.stringify(p).toLowerCase().includes(qq));
    const seed=Math.abs([...qq].reduce((a,ch)=>a+ch.charCodeAt(0),0))%TOTAL_PROFILES;
    const generatedSearch=[];
    for(let j=0;j<4;j++){
      const p=makeProfile((seed+j)%TOTAL_PROFILES);
      p.id=`search-${seed}-${j}`;
      p.name=`${String(q).trim()} ${['Walker','Patel','Chen','Miller'][j]}`;
      p.handle='@'+p.name.toLowerCase().replace(/[^a-z0-9]+/g,'')+(j+1);
      p.bio=`Fictional search result related to "${String(q).trim()}".`;
      generatedSearch.push(p);
      if(s.world){ s.world.generatedProfiles ||= {}; s.world.generatedProfiles[p.id]=p; }
    }
    return exact.concat(generatedSearch).slice(0,4);
  }

  function feed(s,offset=0,count=10){
    const sp=scenarioPeople(s);
    const fake=generateRange(offset,Math.max(0,count));
    const pool=sp.concat(fake);
    return pool.slice(0,count).map((p,idx)=>postFor(p,(offset+idx)%Math.max(1,p.postCount||1)));
  }

  function postFor(p,n){if(p.private) return {id:p.id+'-private',author:p,private:true,tag:'private',image:p.avatar,text:'This account is private. Only profile details are visible.',likes:0,comments:0}; const cat=p.category, texts={football:['Match day.','Training after work.','Big result tonight.'],motorsport:['Track day was unreal.','Race weekend.','Cars and coffee.'],lifestyle:['Good weekend.','Small wins this week.','Coffee and a quiet morning.'],news:['Interesting update today.','Local briefing.','Worth reading this morning.']}; return {id:p.id+'-post-'+n,author:p,private:false,tag:cat,image:p.avatar,text:texts[cat][n%3],likes:10+(n*7+(p.id.length*3))%140,comments:1+(n*3)%24,reveal:p.isScenario?2+(n%3):1};}
  function getData(s){s.social ||= {friends:{},messages:{},viewed:[],alerts:0,postsOpened:0,messagesSent:0,relationshipXP:0,feedOffset:0}; return s.social;}
  function friendship(d,id){return Math.min(100,d.friends[id]?.score||0);}
  function openPost(s,post){const d=getData(s);if(!d.viewed.includes(post.id)){d.viewed.push(post.id);d.postsOpened++;}return {post,unlocked:!post.author.isScenario || post.reveal<=level(s)};}
  function optionReply(s,person,option,scenario){const d=getData(s), score=friendship(d,person.id), l=level(scenario||s); let xp=0,alert=false,text='';
    switch(option){
      case 'greeting': xp=3;text=`Hey! Nice to hear from you. How is your week going?`;break;
      case 'friends': xp=8;text=`Sure, we can chat. I’m usually around ${person.club} circles and weekend ${person.interests[0]}.`;break;
      case 'info': xp=score>=25?7:2;text=score>=25?`I can share a little: I work in the ${person.role} group. ${person.isScenario&&person.clue?person.clue:'Nothing especially sensitive.'}`:`We just met — maybe keep it general for now.`;alert=l>=4&&score<25;break;
      case 'identity': xp=score>=20?5:1;text=score>=20?`I’m ${person.name}. My public profile says ${person.role}.`:`I prefer not to give work details to new contacts.`;break;
      case 'interests': xp=9;text=`I’m into ${person.interests.join(' and ')}. ${person.club} is my usual team.`;break;
      case 'location': xp=score>=45?5:1;text=score>=45?`I’m usually around the general ${person.isScenario?'operations':'city'} area.`:`That’s a bit personal for a new contact.`;alert=l>=5&&score<45;break;
      default: text='No response.';
    }
    if(person.isScenario && l>=4 && option==='info' && score<50) alert=true;
    if(alert){d.alerts++; if(window.Heat) Heat.applyAlert(s,window.App?.company||{difficulty:s.difficulty,industry:'Technology',employees:1000},Math.max(1,l*1.2),`${person.name} flagged a social question`);}
    d.friends[person.id] ||= {score:0,stage:'new'}; d.friends[person.id].score=Math.max(0,Math.min(100,d.friends[person.id].score+xp)); const ns=d.friends[person.id].score; d.friends[person.id].stage=ns>=70?'friend':ns>=40?'familiar':ns>=20?'contact':'new'; d.relationshipXP+=Math.max(0,xp); d.messages[person.id] ||= []; d.messages[person.id].push({from:'you',text:option}); d.messages[person.id].push({from:'person',text,ts:Date.now()}); d.messagesSent++;
    const newClues=[]; if(ns>=20)newClues.push(`${person.name} has become a familiar contact.`); if(ns>=45)newClues.push(`Social cross-link: ${person.name} associates with ${person.club}.`); if(ns>=70)newClues.push(`Friendship unlock: ${person.name} volunteers an additional scenario-relevant detail.`); return {text,alert,xp,score:ns,newClues};
  }
  function unlockedInfo(s,person){const score=friendship(getData(s),person.id),d=level(s),out=[]; if(score>=20)out.push(`Interest: ${person.interests[0]}`); if(score>=40)out.push(`Club: ${person.club}`); if(score>=60&&d>=2)out.push(`Social circle overlaps with the ${person.role} group.`); if(score>=75&&d>=3&&person.clue)out.push(`Scenario clue: ${person.clue}`); return out;}
  function posts(s){ return feed(s,0,10); }
  function people(s){return scenarioPeople(s);}
  function resolveProfile(s,id){
    const key=String(id||'');
    const all=ensure().concat(scenarioPeople(s)).concat(Object.values((s.world&&s.world.generatedProfiles)||{}));
    let p=all.find(x=>x.id===key);
    if(p) return p;
    // Accept post IDs as well as profile IDs so every search/feed card is openable.
    p=all.find(x=>key.startsWith(String(x.id)+'-post-') || key===String(x.id)+'-private');
    return p||null;
  }
  function send(s,person,text,scenario){ const q=String(text||'').toLowerCase(); let o='greeting'; if(/friend|meet|football|club|team/.test(q)) o='friends'; else if(/who|name|identity/.test(q)) o='identity'; else if(/where|location|office/.test(q)) o='location'; else if(/info|work|role|detail|password|credential|secret|admin|bypass|exploit/.test(q)) o='info'; else if(/interest|like|hobby/.test(q)) o='interests'; const r=optionReply(s,person,o,scenario); return {reply:r.text,alert:r.alert,xp:r.xp,score:r.score,newClues:r.newClues}; }
  return {ensure,search,feed,posts,people,resolveProfile,send,postFor,scenarioPeople,getData,friendship,openPost,optionReply,unlockedInfo,esc,getProfile,generateRange,totalProfiles:()=>TOTAL_PROFILES,generatedCount:()=>generated.size};
})();

/* ===== app.js ===== */
// app.js — screens, rendering, and event wiring
(function () {
  const App = {
    player: null,
    company: null,
    scnState: null,
    scenario: null,
    term: null,
    activeTab: "systems",
    difficultyFilter: "All",
    onlyAssessable: false,
    tickTimer: null,
    saveTimer: null,
    clockTimer: null,
    unloadHandler: null,
    lastTickAt: 0,
    desktopReady: false,
    desktopFileTarget: null,
    careersSelectedFile: null
  };
  window.App = App;

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };

  // ===== Startup / First-launch introduction =====
  const INTRO_DONE_KEY = "protocolBreach.introCompleted.v1";
  const AGREEMENT_KEY = "protocolBreach.educationalAgreement.v1";
  let introIndex = 0;
  let introLockedAgreement = false;

  function showStartupChoice() {
    const overlay = $("#startup-choice-overlay");
    if (!overlay) return;
    overlay.classList.remove("hidden");
    $("#startup-first-time")?.focus();
  }

  function setIntroSlide(index) {
    const slides = $$(".intro-slide");
    if (!slides.length) return;
    introIndex = Math.max(0, Math.min(index, slides.length - 1));
    const track = $("#intro-track");
    if (track) track.style.transform = `translateX(-${introIndex * 100}%)`;
    slides.forEach((s,i) => s.classList.toggle("active", i === introIndex));
    const dots = $("#intro-dots");
    if (dots) dots.innerHTML = slides.map((_,i)=>`<button class="intro-dot${i===introIndex?' active':''}" data-intro-dot="${i}" aria-label="Go to introduction page ${i+1}"></button>`).join("");
    $$("[data-intro-dot]", dots || document).forEach(b=>b.onclick=()=>setIntroSlide(+b.dataset.introDot));
    const prev = $("#intro-prev"), next = $("#intro-next"), agree = $("#educational-agree");
    if (prev) prev.disabled = introIndex === 0;
    const isAgreement = introIndex === slides.length - 2;
    if (next) {
      next.disabled = isAgreement && !(agree && agree.checked);
      next.textContent = introIndex === slides.length - 1 ? "Enter Simulator →" : "Next →";
    }
  }

  function openIntro(startAt=0, lockedAgreement=false) {
    const startup = $("#startup-choice-overlay"), overlay=$("#intro-overlay");
    startup?.classList.add("hidden");
    overlay?.classList.remove("hidden");
    introLockedAgreement = !!lockedAgreement;
    setIntroSlide(startAt);
    const agree=$("#educational-agree");
    if (agree) agree.checked = false;
    setIntroSlide(introIndex);
  }

  function finishIntro() {
    const agree=$("#educational-agree");
    if (!agree || !agree.checked) { setIntroSlide(introIndex); return; }
    try { localStorage.setItem(INTRO_DONE_KEY,"1"); localStorage.setItem(AGREEMENT_KEY,"1"); } catch(e) {}
    $("#intro-overlay")?.classList.add("hidden");
    introLockedAgreement=false;
    toast("Welcome to Protocol Breach. Operations Center ready.","success");
  }

  function initStartupIntro() {
    const first=$("#startup-first-time"), played=$("#startup-played"), skip=$("#intro-skip"), next=$("#intro-next"), prev=$("#intro-prev"), agree=$("#educational-agree");
    first?.addEventListener("click",()=>openIntro(0,false));
    played?.addEventListener("click",()=>openIntro(10,true));
    skip?.addEventListener("click",()=>openIntro(10,true));
    prev?.addEventListener("click",()=>setIntroSlide(introIndex-1));
    next?.addEventListener("click",()=>{
      const last=$$(".intro-slide").length-1, agreement=last-1;
      if (introIndex===agreement && !(agree?.checked)) { setIntroSlide(introIndex); return; }
      if (introIndex>=last) { finishIntro(); return; }
      setIntroSlide(introIndex+1);
    });
    agree?.addEventListener("change",()=>setIntroSlide(introIndex));
    const row=$(".intro-agreement");
    row?.addEventListener("click",e=>{ if(e.target===agree)return; agree.checked=!agree.checked; agree.dispatchEvent(new Event("change")); });
    document.addEventListener("keydown",e=>{
      if($("#intro-overlay")?.classList.contains("hidden")) return;
      if(e.key==="ArrowRight") { e.preventDefault(); next?.click(); }
      else if(e.key==="ArrowLeft") { e.preventDefault(); prev?.click(); }
      else if(e.key==="Escape") { e.preventDefault(); skip?.click(); }
    });
    let sx=0;
    $("#intro-track")?.addEventListener("pointerdown",e=>{sx=e.clientX;});
    $("#intro-track")?.addEventListener("pointerup",e=>{const dx=e.clientX-sx;if(Math.abs(dx)>50){if(dx<0)next?.click();else prev?.click();}});
    let completed=false, agreed=false;
    try { completed=localStorage.getItem(INTRO_DONE_KEY)==="1"; agreed=localStorage.getItem(AGREEMENT_KEY)==="1"; } catch(e) {}
    if (completed && agreed) return;
    showStartupChoice();
  }

  function boot() {
    if (!Array.isArray(window.COMPANIES) || !window.COMPANIES.length) {
      toast("Scenario catalog failed to initialize. Reload the application.", "error");
      return;
    }
    if (!window.SCENARIO_LIBRARY || Object.keys(window.SCENARIO_LIBRARY).length < window.COMPANIES.length) {
      toast("Scenario database failed to initialize. Reload the application.", "error");
      return;
    }
    window.PBNetworkState={connected:false,ssid:'',ip:'',speed:0,security:'',detectionReduction:0};
    App.player = State.load();
    if (!App.player.profile) App.player.profile = State.freshPlayer().profile;
    if (!App.player.settings) App.player.settings = State.freshPlayer().settings;
    document.body.classList.toggle('pb-large-text', App.player.settings.largeText === true);
    document.body.classList.toggle('pb-reduced-motion', App.player.settings.reducedMotion === true);
    document.body.classList.toggle('pb-compact', App.player.settings.compactUI !== false);
    unlockAchievements();
    try { sessionStorage.removeItem('PB_RESET_IN_PROGRESS'); } catch(e) {}
    App.unloadHandler = () => { if (!resetInProgress && sessionStorage.getItem('PB_RESET_IN_PROGRESS')!=='1' && App.player) State.save(App.player); };
    window.addEventListener("beforeunload", App.unloadHandler);
    App.saveTimer = setInterval(() => { if (!resetInProgress && App.player) State.save(App.player); }, 8000);
    App.clockTimer = setInterval(() => { const c=$("#taskbar-clock"); if(c) c.textContent=new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",hour12:false}); }, 15000);
    renderTopbar();
    showBoard();
    saveSoon();
    initStartupIntro();
  }

  function saveSoon() { if (!resetInProgress && App.player) State.save(App.player); }

  function toast(message, kind = "") {
    const region = $("#toast-region");
    if (!region) return;
    const node = el("div", `toast ${kind}`, message);
    region.appendChild(node);
    setTimeout(() => node.remove(), 3200);
  }

  function updateMissionCount() {
    const node = $("#mission-count");
    if (!node) return;
    const total = COMPANIES.length;
    const active = Object.values(App.player.scenarios).filter(s => s && !s.completed).length;
    node.textContent = `${active} active · ${total} scenarios`;
  }

  // ───────────────────────── Top bar ─────────────────────────
  function renderTopbar() {
    const set = (selector, value) => { const n = $(selector); if (n) n.textContent = value; };
    const dim = (selector, on) => { const n = $(selector); if (n?.parentElement) n.parentElement.classList.toggle("dimmed", on); };
    const active = Object.values(App.player.scenarios).filter(s => s && !s.completed).length;
    set("#stat-rep .value", `${App.scnState ? App.scnState.reputation : 10} / 20`);
    set("#stat-credits .value", `$${(App.scnState ? App.scnState.credits : 100).toFixed(2)}`);
    set("#stat-active .value", active);
    if (App.scnState) {
      set("#stat-score .value", `${Math.round(App.scnState.score)}`);
      set("#stat-heat .value", `${Math.round(App.scnState.heat)}`);
      dim("#stat-score .value", false); dim("#stat-heat .value", false);
    } else {
      set("#stat-score .value", "—"); set("#stat-heat .value", "—");
      dim("#stat-score .value", true); dim("#stat-heat .value", true);
    }
    renderDesktopStatus();
  }

  function renderObjectiveDock() {
    const dock = $("#objective-dock"), list = $("#objective-dock-list"), meta = $("#objective-dock-meta");
    if (!dock || !App.scnState || !App.scenario) { if (dock) dock.classList.remove("visible"); return; }
    const p = Mission.progress(App.scnState, App.scenario);
    dock.classList.add("visible");
    const reopen=$("#objective-dock-open"); if(reopen) reopen.classList.toggle("hidden", !dock.classList.contains("collapsed"));
    meta.textContent = `${p.done}/${p.total} COMPLETE · ${p.pct}%`;
    const next = p.next;
    const existingGuide = dock.querySelector(".mission-guidance");
    if (existingGuide) existingGuide.remove();
    if (next && App.player?.settings?.guidance !== false) {
      const guide = el("div", "mission-guidance", `<div class="guidance-kicker">NEXT OBJECTIVE</div><strong>${escapeHtml(next.description)}</strong><span>${escapeHtml(Mission.difficultyName(next.difficulty))} · Use the simulator tools to gather evidence.</span><button type="button" class="btn tiny" data-guidance-open>Open Terminal</button>`);
      dock.insertBefore(guide, list);
      $("[data-guidance-open]", guide).onclick = () => openDesktopWindow("terminal");
    }
    list.innerHTML = p.objectives.map((o, i) => {
      const done = o.status === "COMPLETE", available = o.status === "AVAILABLE";
      const icon = done ? "✓" : (available ? "›" : "·");
      const state = done ? "COMPLETE" : (available ? "ACTIVE" : "LOCKED");
      return `<div class="dock-objective ${done ? "done" : ""}">
        <span class="dock-check">${icon}</span>
        <span class="dock-text">${escapeHtml(o.description)}<span class="dock-sub">${state} · ${Mission.difficultyName(o.difficulty)}</span></span>
      </div>`;
    }).join("");
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>\"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
  }

  function openOperatorProfile() {
    const p = App.player || State.freshPlayer(), profile = p.profile || {};
    const completed = Object.values(p.scenarios||{}).filter(s=>s?.completed).length;
    const achievements = profile.achievements || [];
    const labels = {"first-operation":"FIRST OPERATION","three-operations":"THREE OPERATIONS","full-catalog":"FULL CATALOG","ghost-operator":"GHOST OPERATOR","century":"CENTURY"};
    const modal = el("div", "modal-backdrop");
    modal.innerHTML = `<div class="modal profile-modal"><div class="report-kicker">OPERATOR DOSSIER</div><h2>Operator Profile</h2><div class="profile-hero"><div class="profile-rank">${completed>=10?'MASTER':completed>=5?'SPECIALIST':completed>=1?'FIELD OPERATIVE':'RECRUIT'}</div><div><span>MISSIONS</span><strong>${completed}/${COMPANIES.length}</strong></div><div><span>BEST SCORE</span><strong>${Number(profile.bestScore)||0}</strong></div></div><div class="profile-grid"><div><b>Successful operations</b><span>${Number(profile.successfulMissions)||0}</span></div><div><b>Objectives completed</b><span>${Number(profile.objectivesCompleted)||0}</span></div><div><b>Best discipline</b><span>${Number(profile.stealthBest)||0}%</span></div><div><b>Average heat</b><span>${completed ? Math.round((Number(profile.totalHeat)||0)/completed) : 0}</span></div></div><h3>Achievements</h3><div class="achievement-list">${Object.keys(labels).map(id=>`<span class="achievement ${achievements.includes(id)?'unlocked':''}">${achievements.includes(id)?'✓':'○'} ${labels[id]}</span>`).join('')}</div><div class="profile-settings"><label><input type="checkbox" id="profile-guidance" ${p.settings?.guidance!==false?'checked':''}> Mission guidance</label><label><input type="checkbox" id="profile-compact" ${p.settings?.compactUI!==false?'checked':''}> Compact interface</label><label><input type="checkbox" id="profile-large" ${p.settings?.largeText?'checked':''}> Larger UI text</label><label><input type="checkbox" id="profile-motion" ${p.settings?.reducedMotion?'checked':''}> Reduce motion</label></div><div class="actions"><button class="btn primary" id="profile-close">Close</button></div></div>`;
    document.body.appendChild(modal);
    $("#profile-close",modal).onclick=()=>modal.remove();
    $("#profile-guidance",modal).onchange=e=>{p.settings.guidance=e.target.checked;saveSoon();renderObjectiveDock();};
    $("#profile-compact",modal).onchange=e=>{p.settings.compactUI=e.target.checked;document.body.classList.toggle('pb-compact',e.target.checked);saveSoon();};
    $("#profile-large",modal).onchange=e=>{p.settings.largeText=e.target.checked;document.body.classList.toggle('pb-large-text',e.target.checked);saveSoon();};
    $("#profile-motion",modal).onchange=e=>{p.settings.reducedMotion=e.target.checked;document.body.classList.toggle('pb-reduced-motion',e.target.checked);saveSoon();};
  }

  // ───────────────────────── Board screen ─────────────────────────
  function showBoard() {
    document.body.classList.remove("scenario-mode");
    stopTick();
    App.company = null; App.scnState = null; App.scenario = null;
    $("#view-board").classList.remove("hidden");
    $("#view-scenario").classList.add("hidden");
    renderTopbar();
    renderOpsSummary();
    renderFilters();
    renderBoardGrid();
    updateMissionCount();
  }

  function renderOpsSummary() {
    const wrap = $("#ops-summary"); wrap.innerHTML = "";
    const entries = Object.values(App.player.scenarios);
    if (!entries.length) {
      wrap.innerHTML = `<div class="empty-note">No active operations yet — select a target below to begin.</div>`;
      return;
    }
    const grid = el("div", "ops-grid");
    entries.sort((a, b) => b.lastTimestamp - a.lastTimestamp).slice(0, 4).forEach(s => {
      const c = COMPANIES.find(x => x.id === s.id);
      if (!c) return;
      const card = el("div", "ops-stat");
      card.innerHTML = `
        <div class="k">${c.name}</div>
        <div class="v" style="font-size:14px;">${Heat.levelName(s.responseLevel)}</div>
        <div class="bar-track"><div class="bar-fill" style="width:${s.score}%;background:var(--cyan)"></div></div>
        <div style="font-size:10px;color:var(--text-dim);margin-top:4px;">Score ${Math.round(s.score)} · Heat ${Math.round(s.heat)} ${s.completed ? " · ✅ filed" : ""}</div>
      `;
      card.style.cursor = "pointer";
      card.onclick = () => openScenario(c.id);
      grid.appendChild(card);
    });
    wrap.appendChild(grid);
  }

  function renderFilters() {
    const wrap = $("#filters"); wrap.innerHTML = "";
    ["All", ...DIFFICULTY_ORDER].forEach(d => {
      const b = el("button", "filter-btn" + (App.difficultyFilter === d ? " active" : ""), d);
      b.onclick = () => { App.difficultyFilter = d; renderFilters(); renderBoardGrid(); };
      wrap.appendChild(b);
    });
    const assessBtn = el("button", "filter-btn" + (App.onlyAssessable ? " active" : ""), "Assessments Available");
    assessBtn.onclick = () => { App.onlyAssessable = !App.onlyAssessable; renderFilters(); renderBoardGrid(); };
    wrap.appendChild(assessBtn);
  }

  function renderBoardGrid() {
    const grid = $("#board-grid"); grid.innerHTML = "";
    let list = COMPANIES.slice();
    if (App.difficultyFilter !== "All") list = list.filter(c => c.difficulty === App.difficultyFilter);
    if (App.onlyAssessable) {
      list = list.filter(c => {
        const s = App.player.scenarios[c.id];
        return s && s.assessmentEarnings < s.assessmentCap;
      });
    }
    list.forEach(c => grid.appendChild(renderCard(c)));
    updateMissionCount();
  }

  function renderCard(c) {
    const diffClass = "diff-" + c.difficulty.toLowerCase().replace(/\s+/g, "-");
    const card = el("div", `task-card ${diffClass}`);
    const s = App.player.scenarios[c.id];
    let progressTag = "";
    if (s) {
      progressTag = `<div class="progress-tag">${s.completed ? "✅ Mission filed" : (s.timedOut ? "❌ Mission failed · Time limit" : `In progress · Score ${Math.round(s.score)}`)}</div>`;
    }
    card.innerHTML = `
      <div class="ribbon"></div>
      <div class="card-head">
        <h3>${c.id}. ${c.name}</h3>
        <span class="badge">${c.difficulty}</span>
      </div>
      <div class="industry">${c.industry}</div>
      <div class="tagline">${c.tagline}</div>
      <div class="meta-row"><span>👥 ${c.employees.toLocaleString()} employees</span><span>×${DIFFICULTY_MULT[c.difficulty].toFixed(2)} heat</span></div>
      ${progressTag}
    `;
    card.onclick = () => openScenario(c.id);
    return card;
  }

  // ───────────────────────── Scenario screen ─────────────────────────
  function renderMissionBriefing(company, scenario, continueFn) {
    const existing = document.querySelector('.mission-briefing-backdrop');
    existing?.remove();
    const objectives = (scenario.flags||[]).map((f,i)=>`<li><b>${escapeHtml(f.description||'Objective '+(i+1))}</b><span>${i===0?'Initial objective':'Unlocks after the prior objective is completed.'}</span></li>`).join('');
    const learning = {
      1:{skills:['OSINT','Network enumeration','SMB/RDP evidence correlation','Web application analysis'],use:'Used by authorized security assessors, threat researchers and defenders to understand exposed services and prioritize remediation.',purpose:'Learn how separate public, network and application clues can be correlated into an evidence chain while managing detection and resources.'},
      2:{skills:['OSINT','Service enumeration','Authentication analysis','Healthcare-system awareness'],use:'Used in authorized security assessments and defensive asset management for clinics and healthcare environments.',purpose:'Learn how specialized services, default-credential clues and application evidence can be validated without contacting real systems.'},
      3:{skills:['API reconnaissance','Web application analysis','Credential/API-key handling','Database exposure analysis','Evidence correlation'],use:'Used by application-security teams to identify exposed endpoints, authentication weaknesses and unintended data exposure during authorized testing.',purpose:'Learn how an exposed application credential can create a chain of risks across web and internal systems.'},
      4:{skills:['OSINT','CI/CD security','Secret exposure analysis','Web and cloud enumeration'],use:'Used by application, cloud and DevSecOps teams to identify leaked secrets and reduce supply-chain exposure.',purpose:'Learn how development infrastructure clues can reveal security dependencies and how evidence should be validated before action.'},
      5:{skills:['OSINT','Identity analysis','Network enumeration','Risk assessment','Operational planning'],use:'Used by red/blue teams and security leadership to assess high-value financial environments under stronger defensive pressure.',purpose:'Learn to balance evidence quality, detection risk, resources and mission objectives.'},
      6:{skills:['Healthcare OSINT','Legacy-system analysis','Network enumeration','Forensic thinking'],use:'Used by healthcare security teams to assess legacy systems and protect sensitive clinical environments.',purpose:'Learn to correlate specialized technology, identity and application evidence in a high-impact environment.'},
      7:{skills:['OT/IT reconnaissance','Network mapping','Vendor-risk analysis','Protocol awareness'],use:'Used by industrial security and OT defenders to understand how enterprise and operational systems intersect.',purpose:'Learn to distinguish IT evidence from operational-technology evidence and manage higher consequence environments.'},
      8:{skills:['Infrastructure OSINT','SNMP analysis','Web-service assessment','Network segmentation awareness'],use:'Used by energy and infrastructure security teams to identify exposed management interfaces and improve segmentation.',purpose:'Learn how seemingly small public exposures can reveal larger infrastructure relationships.'},
      9:{skills:['Cloud OSINT','Repository analysis','Identity/IAM reasoning','Data-exposure assessment'],use:'Used by cloud-security and application-security teams to assess public storage, source repositories and excessive permissions.',purpose:'Learn to connect public code and storage evidence to cloud identity and data-access risk.'},
      10:{skills:['Advanced OSINT','Enterprise enumeration','OT awareness','Risk prioritization','Evidence correlation'],use:'Used by mature security teams for authorized assessments of complex global environments.',purpose:'Learn disciplined evidence correlation and resource management under the simulator’s highest pressure level.'}
    }[Number(company.id)] || {skills:['Reconnaissance','OSINT','Evidence correlation','Risk assessment'],use:'Used in authorized cybersecurity assessment and defensive security work.',purpose:'Learn to gather, validate and correlate fictional evidence while managing mission resources.'};
    const modal = el('div','modal-backdrop mission-briefing-backdrop');
    modal.innerHTML = `<div class="modal mission-briefing"><div class="report-kicker">MISSION BRIEFING</div><h2>${escapeHtml(company.name)}</h2><p class="brief-difficulty">${escapeHtml(company.difficulty)} · ${escapeHtml(company.industry)}</p><p>${escapeHtml(scenario.description||company.tagline||'Scenario operation')}</p><div class="brief-grid"><div><b>SKILLS NEEDED</b><ul>${learning.skills.map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul><b>REAL-WORLD USE</b><p>${escapeHtml(learning.use)}</p><b>EDUCATIONAL PURPOSE</b><p>${escapeHtml(learning.purpose)}</p></div><div><b>OBJECTIVE CHAIN</b><ol>${objectives}</ol><b>OPERATING METHOD</b><ul><li>Start with quiet evidence gathering.</li><li>Correlate hosts, services, people and application clues.</li><li>Use the simulator tools to produce objective evidence.</li><li>No real systems or networks are contacted.</li></ul></div></div><div class="actions"><button class="btn" id="mission-brief-cancel">Back</button><button class="btn primary" id="mission-brief-start">Start Mission →</button></div></div>`;
    document.body.appendChild(modal);
    $('#mission-brief-cancel',modal).onclick=()=>{modal.remove();closeScenario();};
    $('#mission-brief-start',modal).onclick=()=>{modal.remove();continueFn();};
  }

  function enterScenarioSimulation(catchup) {
    $('#scn-loading').classList.add('hidden');
    $('#scn-content').classList.remove('hidden');
    renderScenarioHeader();
    MissionTime.ensurePlan(App.scnState,App.scenario);
    MissionTime.resume(App.scnState);
    MissionTime.apply(App.scnState,App.company);
    initTerminalUI(catchup);
    renderStatusStrip();
    renderPanelTabs();
    renderActivePanel();
    renderObjectiveDock();
    initDesktopUI();
    startTick();
    saveSoon();
  }

  function openScenario(id) {
    const company = COMPANIES.find(c => c.id === id);
    if (!company) return;
    const existingState = App.player.scenarios[id];
    const isNewMission = !existingState;
    document.body.classList.add('scenario-mode');
    $('#view-board').classList.add('hidden');
    $('#view-scenario').classList.remove('hidden');
    $('#scn-loading').classList.remove('hidden');
    $('#scn-content').classList.add('hidden');
    ScenarioLoader.load(company, (err, scenario) => {
      if (err) { toast(err.message, 'error'); showBoard(); return; }
      App.company = company;
      App.scenario = scenario;
      App.scnState = State.ensureScenario(App.player, company);
      Mission.ensure(App.scnState, scenario);
      syncPBNetworkState(App.scnState);
      const catchup = Recovery.catchUp(App.scnState, company);
      App.term = Terminal.makeSession(App.scnState, scenario);
      App.activeTab = 'systems';
      if (!isNewMission && (App.scnState.completed || App.scnState.timedOut)) {
        App.player.activeScenarioId = company.id;
        setTimeout(() => fileMissionReport(), 0);
        return;
      }
      if (isNewMission) {
        renderMissionBriefing(company, scenario, () => {
          const now=Clock.now();
          App.scnState.firstStartedAt=now;
          App.scnState.startedAt=now;
          App.scnState.activeElapsedMs=0;
          App.scnState.activeTimeSince=now;
          App.scnState.timePlan=null;
          App.scnState.timeStage=0;
          App.scnState.timeScoreCap=100;
          App.scnState.timePenaltyHistory=[];
          App.scnState.timedOut=false;
          App.scnState.mission.startSnapshot=MissionTime.snapshot(App.scnState);
          App.scnState.mission.startSnapshotAt=now;
          App.player.activeScenarioId = company.id;
          enterScenarioSimulation(catchup);
        });
        return;
      }
      App.player.activeScenarioId = company.id;
      MissionTime.resume(App.scnState);
      enterScenarioSimulation(catchup);
    });
  }
  function closeScenario() {
    if(App.scnState) MissionTime.pause(App.scnState);
    App.player.activeScenarioId = null;
    State.save(App.player);
    window.PBNetworkState={connected:false,ssid:'',ip:'',speed:0,security:'',detectionReduction:0};
    showBoard();
  }

  function renderScenarioHeader() {
    $("#scn-title").textContent = `${App.company.id}. ${App.company.name}`;
    $("#scn-sub").textContent = `${App.company.industry} · ${App.company.employees.toLocaleString()} employees · ${App.company.difficulty}`;
  }

  function renderStatusStrip() {
    const s = App.scnState;
    const legacyStrip = $("#status-strip");
    if (legacyStrip) legacyStrip.innerHTML = `
      <div class="status-item score"><div class="k">Score</div><div class="v">${Math.round(s.score)}/100</div></div>
      <div class="status-item rep"><div class="k">Reputation</div><div class="v">${App.scnState ? App.scnState.reputation : 10}/20</div></div>
      <div class="status-item credits"><div class="k">Credits</div><div class="v">$${(App.scnState ? App.scnState.credits : 100).toFixed(2)}</div></div>
      <div class="status-item heat"><div class="k">Heat</div><div class="v">${Math.round(s.heat)}/100</div></div>
      <div class="status-item response"><div class="k">Target</div><div class="v">${Heat.levelName(s.responseLevel)}</div></div>
      ${s.world?.rdpSession?.active ? `<div class="status-item session"><div class="k">Session</div><div class="v">RDP ACTIVE</div><div class="micro">${World.clean(s.world.rdpSession.target)}</div></div>` : ""}
      <div class="status-item awareness"><div class="k">Awareness</div><div class="v">${Math.round(s.awareness)}/100</div></div>
      <div class="status-item recovery"><div class="k">Recovery</div><div class="v">÷${Recovery.divisorForTier(s.recoveryTier)}</div><div class="micro">${s.recoveryPaused ? "SETTLING" : (s.recoveryHalfRate ? "50% RATE" : "ACTIVE")}</div></div>
    `;
    renderTopbar();
    renderDesktopStatus();
    renderObjectiveDock();
  }

  function renderDesktopStatus() {
    const s = App.scnState;
    if (!s || !App.company) return;
    const set = (id, value) => { const n = $(id); if (n) n.textContent = value; };
    set("#desktop-target", `${App.company.name} · ${App.company.difficulty}`);
    set("#desktop-score", `${Math.round(s.score)}`);
    set("#desktop-heat", `${Math.round(s.heat)}`);
    set("#desktop-rep", `${App.scnState ? App.scnState.reputation : 10}/20`);
    set("#desktop-credits", `$${(App.scnState ? App.scnState.credits : 100).toFixed(2)}`);
    set("#desktop-response", Heat.levelName(s.responseLevel).toUpperCase());
    set("#desktop-recovery", `÷${Recovery.divisorForTier(s.recoveryTier)}`);
  }

  // ── Terminal ──
  function initTerminalUI(catchup) {
    const body = $("#term-body");
    body.innerHTML = "";
    printSys(`⏣ Protocol Breach — Adaptive Operations Simulator`);
    printSys(`🔒 Target: ${App.scenario.name || App.company.name}`);
    if (App.scenario.welcomeMessage) printSys(App.scenario.welcomeMessage);
    printSys(`📌 Type 'help' for available commands. Quiet recon costs nothing; exploitation raises Heat.`);
    if (catchup && catchup.realMinutes > 1) {
      printSys(`⏱ Welcome back — offline time is not counted toward the mission timer. Recovery continued while you were away.`);
    }
    printPrompt();

    const input = $("#term-input");
    input.onkeydown = (e) => {
      if (e.key === "Enter") {
        const val = input.value;
        input.value = "";
        runCommand(val);
      }
    };
    input.focus();
  }

  function promptStr() {
    return `${App.scnState.currentPath}$ `;
  }
  function printPrompt() { $("#term-prompt").textContent = promptStr(); }

  function printLine(text, cls) {
    const body = $("#term-body");
    const line = el("div", "line " + (cls || "out"));
    line.textContent = text;
    body.appendChild(line);
    body.scrollTop = body.scrollHeight;
  }
  function printSys(text) { printLine(text, "sys"); }

  function runCommand(raw) {
    const trimmed = (raw || "").trim();
    if (!trimmed) return;
    printLine(`${promptStr()}${trimmed}`, "cmd");

    const result = App.term.execute(trimmed);
    if (result.cleared) {
      $("#term-body").innerHTML = "";
      printSys(`Target: ${App.scenario.name || App.company.name}`);
      printPrompt();
      return;
    }

    if (result.output) {
      const isFlag = result.flagsFound.length > 0;
      printLine(result.output, isFlag ? "success" : "out");
      if (isFlag) {
        printLine(`[+] Flag(s) captured: ${result.flagsFound.join(", ")}`, "success");
        const rep = Mission.onFlags(App.scnState, App.player, App.scenario, result.flagsFound);
        if (rep) printSys(`[objective] Reputation +${rep} for completed objective(s).`);
      }
    }

    // apply game-mechanical consequence for this command
    if (result.cmdName) {
      const consequence = Heat.applyAction(App.scnState, App.company, result.cmdName);
      if (consequence.noise === 0) Heat.markQuietAction(App.scnState);
      if (consequence.noise > 0) {
        printSys(`[system] Noise ${consequence.noise}/10 · Heat ${consequence.heatDelta >= 0 ? "+" : ""}${consequence.heatDelta} · Score ${consequence.scoreDelta}`);
        if (App.scnState.responseLevel >= 4) printSys(`[warning] Target posture: ${Heat.levelName(App.scnState.responseLevel)} — further noisy actions are increasingly expensive.`);
      }
    }

    renderStatusStrip();
    renderDesktopStatus();
    if (App.activeTab) renderActivePanel();
    renderObjectiveDock();
    printPrompt();
    saveSoon();
    toast(result.flagsFound && result.flagsFound.length ? "Objective evidence captured." : "Action processed.", result.flagsFound && result.flagsFound.length ? "success" : "");

    if (App.scnState.score <= 0) {
      handleBurnout();
    }
  }

  function handleBurnout() {
    printSys(`⚠ Score has bottomed out. Operational discipline compromised — back off and let recovery run before continuing.`);
  }

  // ── Side panel tabs ──
  const TABS = [
    { id: "systems", label: "Systems" },
    { id: "objectives", label: "Objectives" },
    { id: "world", label: "Browser / OSINT" },
    { id: "network", label: "Network / Wi-Fi" },
    { id: "files", label: "Explorer" },
    { id: "identity", label: "Identity Cover" },
    { id: "protection", label: "Protection" },
    { id: "intel", label: "Intel" },
    { id: "redteam", label: "Red Team" },
    { id: "assessments", label: "Assessments" },
    { id: "log", label: "Activity" },
    { id: "comms", label: "ComsApp / Mail / Phone" },
    { id: "social", label: "Social Media" },
    { id: "location", label: "Location Intel" },
    { id: "taskmanager", label: "Task Manager" }
  ];

  function renderPanelTabs() {
    const wrap = $("#panel-tabs");
    if (!wrap) return;
    wrap.innerHTML = "";
    wrap.classList.add("hidden");
    wrap.setAttribute("aria-hidden", "true");
  }

  function renderActivePanel() {
    const body = $("#panel-body");
    const titleMap = {systems:"SYSTEMS", objectives:"OBJECTIVES", world:"BROWSER / OSINT", network:"NETWORK / WI-FI", files:"FILE EXPLORER", identity:"IDENTITY COVER", protection:"PROTECTION", intel:"INTELLIGENCE", redteam:"RED TEAM", assessments:"ASSESSMENTS", log:"ACTIVITY LOG", comms:"COMSAPP / MAIL / PHONE", social:"SOCIAL MEDIA", location:"LOCATION INTEL", wireshark:"WIRESHARK ANALYZER"};
    const title = $("#tool-window-title");
    if (title) title.textContent = `PROTOCOL BREACH — ${titleMap[App.activeTab] || "TOOLS"}`;
    body.innerHTML = "";
    const lightTabs = ["world","files","comms","social","location","network","taskmanager"];
    const toolBody = body.closest(".tool-window-body");
    toolBody?.classList.toggle("light-app", lightTabs.includes(App.activeTab));
    if (App.activeTab === "objectives") return renderObjectivesPanel(body);
    if (App.activeTab === "systems") return renderSystemsPanel(body);
    if (App.activeTab === "world") return renderWorldPanel(body);
    if (App.activeTab === "network") return renderNetworkPanel(body);
    if (App.activeTab === "wireshark") return renderWiresharkPanel(body);
    if (App.activeTab === "files") return renderFilesPanel(body);
    if (App.activeTab === "identity") return renderIdentityPanel(body);
    if (App.activeTab === "protection") return renderProtectionPanel(body);
    if (App.activeTab === "intel") return renderIntelPanel(body);
    if (App.activeTab === "redteam") return renderRedTeamPanel(body);
    if (App.activeTab === "assessments") return renderAssessmentsPanel(body);
    if (App.activeTab === "log") return renderLogPanel(body);
    if (App.activeTab === "comms") return renderCommsPanel(body);
    if (App.activeTab === "location") return renderLocationPanel(body);
    if (App.activeTab === "social") return renderSocialPanel(body);
    if (App.activeTab === "taskmanager") return renderTaskManagerPanel(body);
  }


  function renderCommsPanel(body) {
    const s=App.scnState, sc=App.scenario;
    if(!requireWifi(s,body,'COMSAPP / MAIL / PHONE')) return; s.comms ||= {mailRead:0,messagesSent:0,calls:0,callMinutes:0,contacts:{},threads:{},alerts:0,directory:[],emails:[]}; s.comms.directory ||= []; s.comms.emails ||= [];
    const contacts=CommsWorld.contacts(sc), mails=CommsWorld.mail(sc), chats=CommsWorld.whatsapp(sc);
    body.innerHTML=`<div class="comms-shell light-product"><div class="product-header"><div><div class="product-name">ComsApp</div><div class="product-sub">Fictional communications suite · ${contacts.length} live contacts</div></div><div class="product-tabs"><button class="app-tab active" data-channel="mail">Mail</button><button class="app-tab" data-channel="chat">ComsApp</button><button class="app-tab" data-channel="phone">Phone</button><button class="app-tab" data-channel="people">Phone OSINT</button></div></div><div id="comms-content"></div></div>`;
    const out=$("#comms-content",body);
    function mailView(){
      const added=s.comms.emails||[];
      out.innerHTML=`<div class="mail-inbox"><div class="mail-toolbar"><b>Inbox</b><span>${mails.length} fictional messages</span><button class="btn tiny" id="mail-compose">+ Add Email</button></div>${mails.map((m,i)=>`<button class="mail-item" data-mail="${i}"><span class="mail-avatar">${CommsWorld.esc((m.name||'?')[0])}</span><span class="mail-main"><b>${CommsWorld.esc(m.name)}</b><strong>${CommsWorld.esc(m.subject)}</strong><small>${CommsWorld.esc(m.body).slice(0,100)}…</small></span>${m.alert?'<em>SENSITIVE</em>':''}</button>`).join('')}${added.length?`<div class="list-heading" style="margin-top:12px">ADDED EXTERNAL EMAILS</div>${added.map((m,i)=>`<button class="mail-item external-mail" data-extmail="${i}"><span class="mail-avatar">@</span><span class="mail-main"><b>${CommsWorld.esc(m.name)}</b><strong>${CommsWorld.esc(m.email)}</strong><small>External fictional contact · response behavior is scenario-independent</small></span></button>`).join('')}`:''}</div>`;
      $("#mail-compose",out)?.addEventListener('click',()=>{out.innerHTML=`<div class="mail-message"><button class="app-link" id="mail-back">← Inbox</button><h2>Add fictional email</h2><div class="search-row"><input id="email-name" placeholder="Name / label"/><input id="email-value" placeholder="person@example.invalid"/><button class="btn small" id="email-add">Add</button></div></div>`;$("#mail-back",out).onclick=mailView;$("#email-add",out).onclick=()=>{const item=CommsWorld.addExternal(s,'email',$("#email-value",out).value,$("#email-name",out).value);if(!item){toast('Enter an email address first.','error');return;}toast('Fictional email added.','success');mailView();saveSoon();};});
      $$('[data-mail]',out).forEach(b=>b.onclick=()=>{const m=mails[+b.dataset.mail];s.comms.mailRead++;s.lastActionType='intel';s.lastQuietActionAt=Clock.now();if(m.alert&&s.responseLevel>=2){s.comms.alerts++;Heat.applyAlert(s,App.company,1,`Mail sensitivity from ${m.from}`);}const mc=contacts.find(c=>c.email&&c.email.toLowerCase()===String(m.from||'').toLowerCase())||contacts.find(c=>c.name===m.name);
        const topics=(mc?.interests||[]).slice(0,5);
        out.innerHTML=`<div class="mail-message"><button class="app-link" id="mail-back">← Inbox</button><h2>${CommsWorld.esc(m.subject)}</h2><div class="mail-from">${CommsWorld.esc(m.name)} · ${CommsWorld.esc(m.from)}</div><p>${CommsWorld.esc(m.body)}</p>${mc?`<div class="topic-strip"><b>Topics from OSINT</b><div class="response-options topic-options">${topics.map((t,i)=>`<button class="response-option" data-email-topic="${CommsWorld.esc(t)}"><kbd>${i+1}</kbd>Reply about ${CommsWorld.esc(t)}</button>`).join('')}</div><div id="mail-topic-response" class="result-box">Choose a topic to draft a fictional reply.</div></div>`:''}</div>`;
        $("#mail-back",out).onclick=mailView;
        $$('[data-email-topic]',out).forEach(b=>b.onclick=()=>{const topic=b.dataset.emailTopic; s.comms.threads[`email:${mc.id}`] ||= []; s.comms.threads[`email:${mc.id}`].push({from:'you',text:`Reply about ${topic}`}); s.comms.threads[`email:${mc.id}`].push({from:'contact',text:`I’m happy to talk about ${topic}. It’s a normal topic I enjoy outside work.`}); s.comms.messagesSent++; $("#mail-topic-response",out).textContent=`Draft sent in the fictional simulation: ${topic}.`; s.lastActionType='intel'; s.lastQuietActionAt=Clock.now(); saveSoon();});
        saveSoon();});
      $$('[data-extmail]',out).forEach(b=>b.onclick=()=>{const m=added[+b.dataset.extmail];out.innerHTML=`<div class="mail-message"><button class="app-link" id="mail-back">← Inbox</button><h2>Message ${CommsWorld.esc(m.name)}</h2><div class="mail-from">${CommsWorld.esc(m.email)}</div><p>Choose how to contact this fictional address.</p><div class="response-options"><button class="response-option" data-mailopt="greeting"><kbd>1</kbd>Greeting</button><button class="response-option" data-mailopt="info"><kbd>2</kbd>Ask information</button><button class="response-option" data-mailopt="identity"><kbd>3</kbd>Ask identity</button></div><div id="mail-response" class="result-box"></div></div>`;$("#mail-back",out).onclick=mailView;$$('[data-mailopt]',out).forEach(x=>x.onclick=()=>{const r=CommsWorld.externalResponse(sc,m,'email')||{text:'No response.'};$("#mail-response",out).textContent=r.text;if(r.alert){s.comms.alerts++;Heat.applyAlert(s,App.company,1,'External email flagged a question');toast('External email produced a fictional alert.','error');}else{s.lastActionType='intel';s.lastQuietActionAt=Clock.now();}saveSoon();});});
    }

    function options(c,channel){
      const base=[['1','Greeting','greeting'],['2','Make friends','friends'],['3','Ask info','info'],['4','Ask identity','identity'],['5','Ask role','role'],['6','Ask location','location'],['7','Ask interests','interests']];
      const topics=(c.interests||[]).slice(0,3).map((t,i)=>[i===2?'0':String(8+i),`Talk about ${t}`,`topic:${t}`]);
      const opts=base.concat(topics).slice(0,11);
      return `<div class="response-options"><div class="options-title">Choose a response · topics discovered from intel can be discussed</div>${opts.map(x=>`<button class="response-option" data-opt="${CommsWorld.esc(x[2])}" data-key="${x[0]}"><kbd>${x[0]}</kbd>${CommsWorld.esc(x[1])}</button>`).join('')}</div>`;
    }
    function chatThread(c,channel='comsapp'){const key=(channel==='phone'?'call:':'wa:')+c.id;s.comms.threads[key] ||= [];const history=[...(c.messages||[]),...s.comms.threads[key]];out.innerHTML=`<div class="chat-app"><div class="chat-head"><button class="app-link" id="chat-back">‹</button><div class="chat-avatar">${ComsAppInitial(c.name)}</div><div><b>${CommsWorld.esc(c.name)}</b><small>${CommsWorld.esc(c.role)} · ${channel==='phone'?'Typed call':'ComsApp'}</small></div><span class="chat-status">● simulated</span></div><div id="chat-log" class="chat-log light-chat">${history.map(m=>`<div class="chat-bubble ${m.from==='you'?'you':'them'}">${CommsWorld.esc(m.text)}</div>`).join('')}</div>${options(c,channel)}</div>`;$$('[data-opt]',out).forEach(b=>b.onclick=()=>sendOption(c,b.dataset.opt,channel));document.onkeydown=handleKeys;}
    function handleKeys(e){if(!document.querySelector('.chat-app'))return;const k=e.key;if(k>='1'&&k<='8'){const b=$(`[data-key="${k}"]`,out);if(b)b.click();}}
    function sendOption(c,opt,channel){const key=(channel==='phone'?'call:':'wa:')+c.id;s.comms.threads[key] ||= [];let r;if(String(opt).startsWith('topic:')){const topic=String(opt).slice(6); if(c.interests?.map(x=>String(x).toLowerCase()).includes(topic.toLowerCase())) r={text:`I’m happy to talk about ${topic}. It’s a normal interest of mine outside work.`,xp:6,alert:false}; else r={text:`I don’t have much to say about ${topic}.`,xp:1,alert:false};}else if(c.isEmployee!==false){r=CommsWorld.optionReply(sc,c,opt,channel);}else{r=CommsWorld.externalResponse(sc,c,channel);if(!r)r={text:'No response.'};}const labels={greeting:'Greeting',friends:'Make friends',info:'Ask info',identity:'Ask identity',role:'Ask role',location:'Ask location',interests:'Ask interests',goodbye:'Goodbye'}; const label=String(opt).startsWith('topic:')?`Talk about ${String(opt).slice(6)}`:(labels[opt]||opt);s.comms.threads[key].push({from:'you',text:label});s.comms.threads[key].push({from:'contact',text:r.text});s.comms.messagesSent++;if(channel==='phone')s.comms.calls++;if(r.alert){s.comms.alerts++;Heat.applyAlert(s,App.company,1,`External contact flagged a ${channel} question`);}else{s.lastActionType='intel';s.lastQuietActionAt=Clock.now();}chatThread(c,channel);renderStatusStrip();saveSoon();if(r.alert)toast('The fictional contact flagged the question. Target awareness increased.','error');}
    function showAddContact(back){out.innerHTML=`<div class="mail-message"><button class="app-link" id="contact-back">← Contacts</button><h2>Add fictional contact</h2><div class="search-row"><input id="contact-name" placeholder="Name / label"/><input id="contact-phone" placeholder="Phone number"/><button class="btn small" id="contact-add">Add</button></div></div>`;$("#contact-back",out).onclick=back;$("#contact-add",out).onclick=()=>{const name=$("#contact-name",out).value.trim(),value=$("#contact-phone",out).value.trim();const item=CommsWorld.addExternal(s,'phone',value,name);if(!item){toast('Enter a phone number first.','error');return;}s.log.unshift({ts:Clock.now(),type:'intel',text:`Added fictional contact: ${value}.`});toast('Fictional contact added.','success');saveSoon();back();};}
    function mergedContacts(){const directory=ComsWorld.directory(s);const chatById=new Map(chats.map(c=>[c.id,c]));return directory.map(c=>{const chat=chatById.get(c.id);return chat?{...c,messages:chat.messages,guarded:chat.guarded}:c;});}
    function chatView(){const all=mergedContacts();out.innerHTML=`<div class="contact-list"><div class="list-heading">ComsApp · Contacts <span>${all.length}</span><button class="btn tiny" id="coms-add-contact">+ Add Contact</button></div>${all.map((c,i)=>`<button class="contact-item" data-chat="${i}"><span class="chat-avatar">${ComsAppInitial(c.name)}</span><span><b>${ComsWorld.esc(c.name)}</b><small>${ComsWorld.esc(c.role)}${c.interests?.length?` · ${ComsWorld.esc(c.interests.slice(0,2).join(' · '))}`:''}</small></span><i>${c.isEmployee===false?'external':(c.guarded?'guarded':'online')}</i></button>`).join('')}</div>`;$$('[data-chat]',out).forEach(b=>b.onclick=()=>chatThread(all[+b.dataset.chat]));$("#coms-add-contact",out)?.addEventListener('click',()=>showAddContact(chatView));}
    function phoneView(){const all=mergedContacts();const phoneAll=all.filter(c=>c.phone);out.innerHTML=`<div class="contact-list"><div class="list-heading">Phone · typed conversations <span>microphone disabled</span><button class="btn tiny" id="phone-add-contact">+ Add Contact</button></div>${phoneAll.map((c,i)=>`<button class="contact-item" data-call="${i}"><span class="chat-avatar">☎</span><span><b>${ComsWorld.esc(c.name)}</b><small>${ComsWorld.esc(c.phone)} · ${ComsWorld.esc(c.role)}${c.interests?.length?` · ${ComsWorld.esc(c.interests.slice(0,2).join(' · '))}`:''}</small></span><i>${c.isEmployee===false?'external':'call'}</i></button>`).join('')}</div>`;$$('[data-call]',out).forEach(b=>b.onclick=()=>chatThread(phoneAll[+b.dataset.call],'phone'));$("#phone-add-contact",out)?.addEventListener('click',()=>showAddContact(phoneView));}
    function peopleView(){
      out.innerHTML=`<div class="phone-osint"><div class="list-heading">PHONE OSINT · SEARCH A NUMBER</div><div class="search-row"><input id="phone-osint-input" inputmode="tel" placeholder="Enter a fictional phone number…"/><button class="btn small" id="phone-osint-search">Search</button></div><div id="phone-osint-results" class="osint-results"></div><div class="list-heading" style="margin-top:14px">KNOWN / ADDED CONTACTS</div>${CommsWorld.directory(s).map(c=>`<div class="osint-contact"><div><b>${CommsWorld.esc(c.name)}</b><small>${CommsWorld.esc(c.role)} · ${c.isEmployee?'scenario employee':'external'}</small></div><p><b>Email:</b> ${CommsWorld.esc(c.email||'—')}<br><b>Phone:</b> ${CommsWorld.esc(c.phone||'—')}<br><b>Public clue:</b> ${CommsWorld.esc(c.clue)}</p><span>Trust ${c.trust}/100</span></div>`).join('')}<div class="list-heading" style="margin-top:14px">ADD CONTACT / EMAIL</div><div class="search-row"><input id="add-name" placeholder="Name / label"/><input id="add-value" placeholder="Phone or email"/><select id="add-kind"><option value="phone">Phone</option><option value="email">Email</option></select><button class="btn small" id="add-contact">Add</button></div></div>`;
      const run=()=>{const q=$("#phone-osint-input",out)?.value||'';const rows=CommsWorld.phoneLookup(s,q);$("#phone-osint-results",out).innerHTML=rows.map(r=>`<div class="web-card location-card"><div class="wr-head"><b>${CommsWorld.esc(r.name)}</b><span>${CommsWorld.esc(r.source)}</span></div><div class="wr-url">${CommsWorld.esc(r.phone)} · ${CommsWorld.esc(r.email||'no email')}</div><div class="wr-text">${CommsWorld.esc(r.role)}<br>${CommsWorld.esc(r.clue)}<br>Confidence ${r.confidence}%</div></div>`).join('')||'<div class="empty-note">No fictional records found.</div>';s.comms.phoneLookups=(s.comms.phoneLookups||0)+1;s.lastActionType='intel';s.lastQuietActionAt=Clock.now();saveSoon();};
      $("#phone-osint-search",out).onclick=run; $("#phone-osint-input",out).onkeydown=e=>{if(e.key==='Enter')run();};
      $("#add-contact",out).onclick=()=>{const name=$("#add-name",out).value.trim(),value=$("#add-value",out).value.trim(),kind=$("#add-kind",out).value;const item=CommsWorld.addExternal(s,kind,value,name);if(!item){toast('Enter a phone number or email first.','error');return;}s.log.unshift({ts:Clock.now(),type:'intel',text:`Added fictional ${kind}: ${value}.`});toast(`${kind==='phone'?'Contact':'Email'} added to local directory.`,'success');peopleView();saveSoon();};
    }
    $$('[data-channel]',body).forEach(b=>b.onclick=()=>{$$('[data-channel]',body).forEach(x=>x.classList.remove('active'));b.classList.add('active');({mail:mailView,chat:chatView,phone:phoneView,people:peopleView}[b.dataset.channel])();});
    mailView();
  }
  function ComsAppInitial(name){return String(name||'?').split(/\s+/).map(x=>x[0]).join('').slice(0,2).toUpperCase();}

  function renderSocialPanel(body){
    const s=App.scnState;
    if(!requireWifi(s,body,'SOCIAL MEDIA')) return;
    const data=SocialWorld.getData(s); let mode='home', offset=data.feedOffset||0;
    body.innerHTML=`<div class="social-app-shell light-product"><div class="social-header"><div class="social-brand">PhotoSphere <small>fictional social network</small></div><div class="social-nav"><button class="social-nav-btn active" data-social-mode="home">Home</button><button class="social-nav-btn" data-social-mode="search">Search</button></div><div class="social-relationship">Rapport XP ${data.relationshipXP}</div></div><div id="social-content"></div></div>`;
    const out=$("#social-content",body);
    function renderHome(){const posts=SocialWorld.feed(App.scenario,offset,10);out.innerHTML=`<div class="social-feed">${posts.map(p=>p.private?`<article class="ig-card private"><div class="ig-profile"><img src="${p.author.avatar}"/><div><b>${SocialWorld.esc(p.author.name)}</b><small>${SocialWorld.esc(p.author.handle)}</small></div></div><div class="private-box">🔒 Private account<br><small>${SocialWorld.esc(p.author.bio)}</small></div></article>`:`<article class="ig-card"><div class="ig-profile"><img src="${p.author.avatar}"/><div><b>${SocialWorld.esc(p.author.name)}</b><small>${SocialWorld.esc(p.author.handle)} · ${SocialWorld.esc(p.tag)}</small></div></div><img class="ig-photo" src="${p.image}"/><div class="ig-actions">♡ ${p.likes} &nbsp; · &nbsp; comments ${p.comments}</div><p>${SocialWorld.esc(p.text)}</p><button class="ig-link" data-post="${SocialWorld.esc(p.id)}">Open profile/post</button></article>`).join('')}<button class="load-more" id="social-more">Load 10 more</button></div>`;$("#social-more",out).onclick=()=>{offset+=10;data.feedOffset=offset;renderHome();saveSoon();};$$('[data-post]',out).forEach(b=>b.onclick=()=>openProfile(b.dataset.post));}
    function renderSearch(){out.innerHTML=`<div class="social-search"><div class="search-row"><input id="social-search-input" placeholder="Search name, handle, role or interest…"/><button id="social-search-btn">Search</button></div><div id="social-results"></div></div>`;const input=$("#social-search-input",out),results=$("#social-results",out);function go(){const rows=SocialWorld.search(App.scenario,input.value);results.innerHTML=rows.map(p=>`<button class="profile-result" data-profile="${SocialWorld.esc(p.id)}"><img src="${p.avatar}"/><span><b>${SocialWorld.esc(p.name)}</b><small>${SocialWorld.esc(p.handle)} · ${SocialWorld.esc(p.role)}</small><em>${p.private?'Private':p.postCount+' posts'} · ${SocialWorld.esc(p.interests.join(' · '))}</em></span></button>`).join('')||'<div class="empty-note">No fictional profiles found.</div>';$$('[data-profile]',results).forEach(b=>b.onclick=()=>openProfile(b.dataset.profile));}$("#social-search-btn",out).onclick=go;input.onkeydown=e=>{if(e.key==='Enter')go();};input.focus();}
    function openProfile(id){const p=SocialWorld.resolveProfile(s,id);if(!p){toast('Profile could not be opened.','error');return;}const post=p.private?null:SocialWorld.postFor(p,0);const info=SocialWorld.unlockedInfo(s,p);out.innerHTML=`<div class="profile-page"><button class="app-link" id="social-back">← Back</button><div class="profile-head"><img src="${p.avatar}"/><div><h2>${SocialWorld.esc(p.name)}</h2><span>${SocialWorld.esc(p.handle)} · ${SocialWorld.esc(p.role)}</span><p>${SocialWorld.esc(p.bio)}</p><small>${SocialWorld.esc(p.interests.join(' · '))} · ${SocialWorld.esc(p.club)}</small></div></div>${p.private?`<div class="private-box big">🔒 Private account<br><small>Only public profile details are available.</small></div>`:`<div class="profile-posts"><img src="${post.image}"/><p>${SocialWorld.esc(post.text)}</p></div>`}${info.length?`<div class="unlocked-info">${info.map(SocialWorld.esc).join('<br>')}</div>`:''}${p.isScenario?`<button class="primary-app-btn" id="profile-chat">Chat with employee</button>`:''}</div>`;$("#social-back",out).onclick=()=>mode==='search'?renderSearch():renderHome();$("#profile-chat",out)?.addEventListener('click',()=>socialChat(p));}
    function socialChat(person){const data=SocialWorld.getData(s),key=person.id;data.messages[key] ||= [];const history=data.messages[key];out.innerHTML=`<div class="social-chat"><div class="chat-head"><button class="app-link" id="social-back">‹</button><div class="chat-avatar">${ComsAppInitial(person.name)}</div><div><b>${SocialWorld.esc(person.name)}</b><small>${SocialWorld.esc(person.handle)} · ${SocialWorld.esc(person.role)}</small></div><span>Rapport ${SocialWorld.friendship(data,person.id)}/100</span></div><div class="chat-log light-chat">${history.map(m=>`<div class="chat-bubble ${m.from==='you'?'you':'them'}">${SocialWorld.esc(m.text)}</div>`).join('')}</div><div class="response-options"><div class="options-title">Choose a response · press 1–6</div>${[['1','Greeting','greeting'],['2','Make friends','friends'],['3','Ask info','info'],['4','Ask identity','identity'],['5','Ask interests','interests'],['6','Ask location','location']].map(x=>`<button class="response-option" data-opt="${x[2]}" data-key="${x[0]}"><kbd>${x[0]}</kbd>${x[1]}</button>`).join('')}</div></div>`;$$('[data-opt]',out).forEach(b=>b.onclick=()=>{const r=SocialWorld.optionReply(s,person,b.dataset.opt,App.scenario);if(r.newClues)r.newClues.forEach(x=>s.log.unshift({ts:Clock.now(),type:'intel',text:x}));renderStatusStrip();saveSoon();if(r.alert)toast('The fictional contact flagged the question.','error');socialChat(person);});document.onkeydown=e=>{if(e.key>='1'&&e.key<='6')$(`[data-key="${e.key}"]`,out)?.click();};$("#social-back",out).onclick=()=>mode==='search'?renderSearch():renderHome();}
    $$('[data-social-mode]',body).forEach(b=>b.onclick=()=>{$$('[data-social-mode]',body).forEach(x=>x.classList.remove('active'));b.classList.add('active');mode=b.dataset.socialMode;mode==='search'?renderSearch():renderHome();});
    renderHome();
  }

  function renderTaskManagerPanel(body){
    const s=App.scnState; s.performance ||= {cpu:18,gpu:12,ram:42,rom:31,network:68}; const speed=World.simulatedSpeed?World.simulatedSpeed(s):68;
    const cpu=Math.min(100,s.performance.cpu+Math.round(s.heat*.18)), gpu=Math.min(100,s.performance.gpu+Math.round(s.world.browserSearches*.5)), ram=Math.min(100,s.performance.ram+Math.round(s.world.filesViewed*.7)), rom=Math.min(100,s.performance.rom+Math.round(s.world.filesViewed*.3));
    body.innerHTML=`<div class="task-manager light-product"><div class="tm-header"><div><b>Task Manager</b><small>Fictional workstation telemetry</small></div><span class="tm-state">SIMULATED</span></div><div class="tm-grid"><div class="tm-card"><span>CPU</span><b>${cpu}%</b><div><i style="width:${cpu}%"></i></div><small>Protocol Core · 3.6 GHz</small></div><div class="tm-card"><span>GPU</span><b>${gpu}%</b><div><i style="width:${gpu}%"></i></div><small>PB Render Unit · 8 GB</small></div><div class="tm-card"><span>RAM</span><b>${ram}%</b><div><i style="width:${ram}%"></i></div><small>16 GB virtual memory</small></div><div class="tm-card"><span>ROM</span><b>${rom}%</b><div><i style="width:${rom}%"></i></div><small>512 GB simulated storage</small></div><div class="tm-card wide"><span>NETWORK THROUGHPUT</span><b>${speed} Mbps</b><div><i style="width:${Math.min(100,speed)}%"></i></div><small>Changes with Wi-Fi quality and protection latency</small></div></div><div class="process-list"><b>Processes</b><div>protocol-core.exe <span>${Math.max(1,Math.round(cpu/8))}% CPU</span></div><div>browser.exe <span>${Math.round(gpu/2)}% CPU</span></div><div>osint-indexer.exe <span>${Math.round(ram/4)}% RAM</span></div><div>comsapp.exe <span>1% CPU</span></div><div>wireshark-sim.exe <span>${s.world.networkScanned?Math.round(4+speed/20):0}% CPU</span></div></div></div>`;
  }

  function renderLocationPanel(body) {
    const s=App.scnState, sc=App.scenario;
    if(!requireWifi(s,body,'LOCATION / PHONE OSINT')) return;
    s.location ||= {lookups:0,tracked:[],lastArea:null,confidence:0};
    const rows=CommsWorld.location(sc);
    body.innerHTML=`<div class="tool-title">LOCATION / PHONE OSINT</div>
      <div class="world-note">All coordinates are fictional scenario coordinates. Location clues come from simulated public posts, message metadata, carrier-like records and scenario events. No device or GPS access occurs.</div>
      <div class="location-grid">${rows.map((r,i)=>`<div class="web-card location-card"><div class="wr-head"><b>${CommsWorld.esc(r.name)}</b><span>${CommsWorld.esc(r.type)}</span></div><div class="wr-url">LAT ${r.lat} · LON ${r.lon}</div><div class="wr-text">Source: ${CommsWorld.esc(r.source)}<br>Confidence: ${r.signal}%</div><button class="btn tiny" data-loc="${i}">Correlate</button></div>`).join('')}</div>
      <div class="location-console" id="location-console">No location lead selected.</div>`;
    $$('[data-loc]',body).forEach(b=>b.onclick=()=>{const r=rows[+b.dataset.loc];s.location.lookups++;s.location.lastArea=r.name;s.location.confidence=r.signal;s.location.tracked.push({area:r.name,ts:Clock.now(),confidence:r.signal});s.lastActionType='intel';s.lastQuietActionAt=Clock.now();s.log.unshift({ts:Clock.now(),type:'intel',text:`Correlated fictional location lead: ${r.name} (${r.signal}% confidence).`});$("#location-console",body).textContent=`CORRELATED LEAD\nArea: ${r.name}\nCoordinates: ${r.lat}, ${r.lon}\nSource: ${r.source}\nConfidence: ${r.signal}%\nThis is fictional and local to the scenario.`;saveSoon();});
  }
  function syncPBNetworkState(s){
    const w=s?.world||{};
    const connected=Boolean(w.wifiSsid && w.wifiIp);
    window.PBNetworkState = connected ? {
      connected:true, ssid:w.wifiSsid, ip:w.wifiIp, speed:Number(w.wifiSpeed)||0,
      security:String(w.wifiSecurity||''), detectionReduction:Number(w.wifiDetectionReduction)||0,
      connectedAt:Number(w.wifiConnectedAt)||Date.now()
    } : {connected:false,ssid:'',ip:'',speed:0,security:'',detectionReduction:0};
    return window.PBNetworkState;
  }
  function wifiConnected(s){
    const n=window.PBNetworkState;
    return !!(n?.connected && n.ssid && n.ip && s?.world && s.world.wifiSsid===n.ssid && s.world.wifiIp===n.ip);
  }
  function requireWifi(s, body, label='This tool'){
    if (wifiConnected(s)) return true;
    body.innerHTML=`<div class="tool-title">${label}</div><div class="network-required-card"><div class="network-required-icon">⌁</div><h3>Wi-Fi connection required</h3><p>Connect to one of the six fictional networks before using this tool. Browser, OSINT, network CLI and other online simulator services use the active simulated connection.</p><button class="btn small" id="open-wifi-required">Open Wi-Fi Scanner</button></div>`;
    $("#open-wifi-required",body)?.addEventListener('click',()=>{App.activeTab='network';renderActivePanel();});
    return false;
  }

  function renderWorldPanel(body) {
    const s=App.scnState, scenario=App.scenario;
    if(!requireWifi(s,body,'LOCAL WEB / OSINT WORKBENCH')) return;
    body.innerHTML=`<div class="world-tools">
      <div class="tool-section"><div class="tool-title">LOCAL WEB / OSINT WORKBENCH</div>
        <div class="tool-search"><input id="world-search" placeholder="Search company, host, person, role, technology…"/><button class="btn small" id="world-search-btn">Search</button></div>
        <div class="web-toolbar"><button class="btn tiny" data-webcmd="home">Home</button><button class="btn tiny" data-webcmd="directory">Directory</button><button class="btn tiny" data-webcmd="tech">Technology</button><button class="btn tiny" data-webcmd="archive">Archive</button><button class="btn tiny" data-webcmd="status">Status</button><button class="btn tiny" data-webcmd="intel">Intel</button></div>
        <div id="world-results"></div>
      </div>
      <div class="world-note">All sites are fictional, local, scenario-contained pages. VERIFIED SCENARIO SOURCE pages are generated from the active scenario; SYNTHETIC DUMMY pages are clearly labeled and may contain misleading information. Public searches are quiet: 0 Heat and 0 Score loss. Nothing is fetched from the real Internet.</div>
    </div>`;
    const input=$("#world-search",body), results=$("#world-results",body);
    const pendingCareersReturn=!!App.careersSelectedFile && App.activeTab==='world';
    function pagePreview(r){
      if(r.summary) return String(r.summary);
      const source=String(r.html||r.body||r.text||'');
      if(!source) return 'No preview data available.';
      const holder=document.createElement('div');
      holder.innerHTML=source;
      return String(holder.textContent||holder.innerText||'').replace(/\s+/g,' ').trim().slice(0,360);
    }
    function draw(rows){
      const latency = World.latencyMs(s);
      results.innerHTML=`<div class="browser-latency">SIMULATED CONNECTION · ${latency} ms latency · ${World.simulatedSpeed(s)} Mbps</div><div id="web-result-list">${rows.map((r,i)=>`<div class="world-result web-card"><div class="wr-head"><b>${WebWorld.esc(r.title)}</b><span class="site-badge ${r.type==='ACTUAL'?'site-actual':'site-dummy'}">${WebWorld.esc(r.siteStatus||r.type||'WEB')}</span></div><div class="wr-url">${WebWorld.esc(r.url)}</div><div class="wr-text">${WebWorld.esc(pagePreview(r))}</div><div class="web-actions"><button class="btn tiny" data-open="${i}">Open</button><span class="web-tags">${(r.tags||[]).map(x=>`#${WebWorld.esc(x)}`).join(' ')}</span></div></div>`).join('')}</div>`;
      $$('[data-open]',results).forEach(b=>b.onclick=()=>{
        const r=rows[Number(b.dataset.open)]; const wait=Math.max(40,Math.min(1200,latency)); results.innerHTML=`<div class="loading-page">Loading simulated page… ${latency} ms</div>`;
        setTimeout(()=>{ s.world.browserSearches++; s.world.osintLeads++; s.lastActionType='intel'; s.lastQuietActionAt=Clock.now(); s.log.unshift({ts:Clock.now(),type:'intel',text:`Opened ${r.siteStatus||r.type||'fictional'} web page ${r.url} (quiet).`});
          results.innerHTML=`<div class="web-page"><div class="wr-head"><b>${WebWorld.esc(r.title)}</b><span class="site-badge ${r.type==='ACTUAL'?'site-actual':'site-dummy'}">${WebWorld.esc(r.siteStatus||r.type)}</span></div><div class="wr-url">${WebWorld.esc(r.url)}</div><div class="web-model">Page model: ${WebWorld.esc(r.modelName||'Synthetic')} · ${latency} ms</div><div class="generated-page-frame">${r.html||`<pre>${WebWorld.esc(r.body||r.text||'')}</pre>`}</div><button class="btn small" id="web-back">← Results</button></div>`;
          $("#web-back",results).onclick=()=>draw(rows);
          $$('[data-person-profile]',results).forEach(btn=>btn.onclick=()=>{
            const target=WebWorld.fetch(s,btn.dataset.personProfile);
            if(!target){toast('Profile could not be opened.','error');return;}
            results.innerHTML=`<div class="web-page"><div class="wr-head"><b>${WebWorld.esc(target.title)}</b><span class="site-badge site-actual">VERIFIED SCENARIO SOURCE · PERSON</span></div><div class="wr-url">${WebWorld.esc(target.url)}</div><div class="web-model">Page model: ${WebWorld.esc(target.modelName||'Synthetic')} · ${latency} ms</div><div class="generated-page-frame">${target.html||''}</div><button class="btn small" id="web-back-profile">← Results</button></div>`;
            $("#web-back-profile",results).onclick=()=>draw(rows);
            s.world.browserSearches++; s.world.osintLeads++; s.lastActionType='intel'; s.lastQuietActionAt=Clock.now(); s.log.unshift({ts:Clock.now(),type:'intel',text:`Opened VERIFIED SCENARIO SOURCE person profile ${target.url} (quiet).`}); renderStatusStrip(); saveSoon();
          });
          $$('[data-careers-choose]',results).forEach(btn=>btn.onclick=()=>{
            // Careers picker must use the same canonical virtual filesystem as the Files app.
            // Keep its path normalizer local to this renderer; the Files panel's helper is scoped to that panel.
            const normalizePickerPath = p => { let x=String(p||'/home/kali').replace(/\\/g,'/'); if(!x.startsWith('/')) x='/'+x; return x.length>1?x.replace(/\/$/,''):x; };
            const desktopNames = Array.isArray(scenario.filesystem?.['/home/kali/Desktop'])
              ? scenario.filesystem['/home/kali/Desktop'].filter(name=>typeof name==='string' && !name.includes('/'))
              : [];
            const contents = scenario.fileContents && typeof scenario.fileContents==='object' ? scenario.fileContents : {};
            const desktopFiles = desktopNames
              .map(name=>({path:normalizePickerPath('/home/kali/Desktop/'+name),name:String(name)}))
              .filter(f=>Object.prototype.hasOwnProperty.call(contents,f.path));
            const modal = document.createElement('div');
            modal.className = 'modal-backdrop careers-file-picker';
            modal.innerHTML = `<div class="modal file-picker-card" role="dialog" aria-modal="true" aria-label="Choose file"><div class="file-picker-windowbar"><div><b>Choose File</b><small>Careers application attachment</small></div><button class="btn tiny" data-picker-cancel aria-label="Cancel">Cancel</button></div><div class="file-picker-location"><span>▣</span><b>Desktop</b></div><div class="file-picker-list">${desktopFiles.length ? desktopFiles.map(f=>`<button type="button" class="file-picker-item" data-picker-file="${WebWorld.esc(f.path)}"><span class="kx-file-icon">▤</span><span><b>${WebWorld.esc(f.name)}</b></span></button>`).join('') : `<div class="empty-note">No files on Desktop.</div>`}</div><div class="file-picker-footer"><div class="file-picker-selected"><small>File name</small><span data-picker-path>No file selected</span></div><button class="btn small" data-picker-choose disabled>Choose</button></div></div>`;
            document.body.appendChild(modal);
            let selectedPath='';
            const pathOut=modal.querySelector('[data-picker-path]'), choose=modal.querySelector('[data-picker-choose]');
            modal.querySelectorAll('[data-picker-file]').forEach(item=>item.onclick=()=>{selectedPath=item.dataset.pickerFile;modal.querySelectorAll('[data-picker-file]').forEach(x=>x.classList.remove('selected'));item.classList.add('selected');pathOut.textContent=selectedPath;choose.disabled=false;});
            modal.querySelector('[data-picker-cancel]').onclick=()=>modal.remove();
            choose.onclick=()=>{if(!selectedPath)return;App.careersSelectedFile=selectedPath;const input=$('#careers-file',results);if(input)input.value=selectedPath;modal.remove();toast(`Selected ${selectedPath.split('/').pop()} for the Careers application.`,'success');saveSoon();};
          });
          $$('[data-careers-upload]',results).forEach(btn=>{
            btn.type='button';
            btn.onclick=()=>{
              const input=$('#careers-file',results);
              const selectedPath=String(App.careersSelectedFile||'').trim();
              const filename=selectedPath.replace(/^.*\//,'').trim();
              const contents=scenario.fileContents && typeof scenario.fileContents==='object' ? scenario.fileContents : {};
              const hasFile=!!selectedPath && Object.prototype.hasOwnProperty.call(contents,selectedPath);
              const out=$('[data-careers-result]',results);
              if(input && input.value!==selectedPath) input.value=selectedPath;
              if(!hasFile || !/\.exe$/i.test(filename)){
                if(out) out.textContent='Upload rejected: select a valid .exe attachment from the file chooser.';
                return;
              }

              // A successful upload is a real mission action: record evidence,
              // raise the web-services alert state, and let the target adapt.
              // Careers is an objective action, so completion is keyed to the
              // canonical objective description rather than to UI text or a flag
              // discovery side effect. This makes the transition deterministic.
              let rep=0;
              const result=Mission.completeObjective(s,scenario,'Upload malicious .exe via careers');
              if(result.new){
                rep=result.rep;
                s.reputation=State.clamp(s.reputation+rep,0,20);
                s.log.unshift({ts:Clock.now(),type:'objective',text:`Objective reward: Reputation +${rep}.`});
              }
              const consequence=Heat.applyAction(s,App.company,'careers-upload');
              s.world ||= {};
              s.world.careersUploadAccepted=true;
              s.world.careersCompromisedAt=Clock.now();
              s.world.careersFile=selectedPath;
              s.world.webIncident='MALICIOUS_ATTACHMENT_DETECTED';
              s.log.unshift({ts:Clock.now(),type:'access',text:`Malicious careers attachment ${filename} was accepted by the fictional portal.`});
              s.log.unshift({ts:Clock.now(),type:'escalation',text:'The target web team detected an unexpected executable upload; the careers endpoint is being investigated and monitored.'});
              s.mission.milestones.unshift({ts:Clock.now(),text:'Careers upload detected: web services entered incident response.'});
              if(s.responseLevel>=2) s.log.unshift({ts:Clock.now(),type:'escalation',text:'Web application access is under increased scrutiny following the careers incident.'});

              const missionProgress=Mission.progress(s,scenario);
              if(out) out.innerHTML=`<b>Application submitted.</b><br>Attachment accepted by the fictional portal.<br><span class="micro">The portal has detected unusual executable content and security monitoring has increased.</span>`;
              if(rep) toast(`Objective completed · Reputation +${rep}`,'success');
              if(missionProgress.done===missionProgress.total){
                s.mission.completedAt=s.mission.completedAt||Clock.now();
                s.mission.outcome='COMPLETE';
                s.log.unshift({ts:Clock.now(),type:'objective',text:`Mission complete: ${App.company.name}.`});
                toast('Mission complete · All objectives achieved','success');
              }
              if(consequence.noise>0) toast(`Target response increased · ${Heat.levelName(s.responseLevel)}`,'error');
              renderStatusStrip(); renderDesktopStatus(); renderObjectiveDock(); renderObjectivesPanel?.(); saveSoon();
              if(missionProgress.done===missionProgress.total){
                stopTick();
                setTimeout(()=>{ fileMissionReport(); closeScenario(); },120);
              }
            };
          });
          $$('[data-cctv-login]',results).forEach(btn=>btn.onclick=()=>{
            const user=$('[data-cctv-user]',results)?.value||'', pass=$('[data-cctv-pass]',results)?.value||'', out=$('[data-cctv-result]',results);
            const acct=(scenario.users||[]).find(u=>String(u.username||'').toLowerCase()===String(user).toLowerCase());
            if(!acct || String(acct.password)!==String(pass)){ if(out) out.textContent='Login failed: invalid fictional credentials.'; return; }
            const flag=(s.flags||[]).find(f=>/cctv/i.test(`${f.description||''} ${f.hint||''}`));
            if(flag){ const rep=Mission.onFlags(s,App.player,scenario,[flag.id]); if(out) out.textContent=`Login successful (SIMULATED) · ${flag.id}`; if(rep) toast(`Objective completed · Reputation +${rep}`,'success'); }
            s.lastActionType='browser-login'; s.log.unshift({ts:Clock.now(),type:'access',text:`Simulated CCTV login succeeded on ${r.url} as ${user}.`}); renderStatusStrip(); saveSoon();
          });
          renderStatusStrip(); saveSoon();
        },wait);
      });
    }
    function search(){ const q=input.value.trim(); const latency=World.latencyMs(s); results.innerHTML=`<div class="loading-page">Searching fictional index… ${latency} ms</div>`; setTimeout(()=>{ const rows=WebWorld.search(scenario,q,s); s.world.browserSearches++; s.world.osintLeads+=Math.max(1,Math.floor(rows.length/2)); s.lastActionType='intel'; s.lastQuietActionAt=Clock.now(); s.log.unshift({ts:Clock.now(),type:'intel',text:`Local web/OSINT search: ${q||'home'} (quiet).`}); draw(rows); renderStatusStrip(); saveSoon(); },Math.max(40,Math.min(1200,latency))); }
    $("#world-search-btn",body).onclick=search; input.onkeydown=e=>{if(e.key==='Enter')search();};
    $$('[data-webcmd]',body).forEach(b=>b.onclick=()=>{const all=WebWorld.pages(scenario,s); const type=b.dataset.webcmd; let rows=all; if(type==='directory')rows=all.filter(x=>x.category==='directory'||x.category==='actual'&&x.type==='ACTUAL'&&/people|directory/i.test(x.url)); if(type==='tech')rows=all.filter(x=>x.category==='tech'); if(type==='archive')rows=all.filter(x=>x.category==='archive'); if(type==='status')rows=all.filter(x=>x.category==='status'); if(type==='intel')rows=all.filter(x=>x.category==='intel'); draw(rows);});
    const initialRows=WebWorld.search(scenario,'',s);
    if(pendingCareersReturn){
      const careersUrl=`https://${WebWorld.domain(scenario)}/careers`;
      const career=WebWorld.fetch(s,careersUrl) || initialRows.find(x=>/\/careers$/.test(String(x.url||'')));
      if(career){
        draw([career]);
        setTimeout(()=>{ const open=$('[data-open]',results); if(open) open.click(); },0);
      } else draw(initialRows);
    } else draw(initialRows);
  }

  function renderNetworkPanel(body) {
    const s=App.scnState, rows=World.wifi(App.scenario), active=s.world.wifiSsid||'';
    if (!s.world.networkScanned) { s.world.wifiScans++; s.world.networkScanned=true; s.lastActionType="intel"; s.lastQuietActionAt=Clock.now(); s.log.unshift({ts:Clock.now(),type:"intel",text:"Simulated Wi-Fi scan completed (quiet)."}); }
    const connected=rows.find(r=>r.ssid===active);
    const speed = connected ? World.simulatedSpeed(s) : 0, latency = connected ? World.latencyMs(s) : '—';
    body.innerHTML=`<div class="wifi-windows"><div class="wifi-header"><div><b>Available networks</b><small>Fictional Windows-style network panel</small></div><div class="wifi-header-state">${connected?`Connected · ${World.clean(connected.ssid)}`:'Not connected'}</div></div><div class="wifi-list">${rows.map(r=>{const isActive=active===r.ssid;const label=r.saved?'Saved':(r.security==='Open'?'Public':'Secured');return `<div class="wifi-row ${isActive?'connected':''}"><div class="wifi-icon-large">◔</div><div class="wifi-info"><div class="wifi-name"><b>${World.clean(r.ssid)}</b><span class="wifi-label ${r.saved?'saved':r.security==='Open'?'public':'locked'}">${label}</span></div><div class="wifi-meta">${World.clean(r.security)} · ${r.band} · CH ${r.channel} · ${r.signal} dBm · ${r.speed} Mbps · ${r.ip}</div>${r.saved?`<div class="wifi-password">Password <code>${World.clean(r.password||'')}</code></div>`:''}${r.security==='Open'?`<div class="wifi-password wifi-bonus">Public network · fictional detection reduction −2%</div>`:''}</div><div class="wifi-action"><button class="wifi-connect-btn ${isActive?'connected-btn':''}" data-connect="${World.clean(r.ssid)}">${isActive?'Connected':'Connect'}</button><button class="wifi-capture-link" data-capture="${World.clean(r.ssid)}">Wireshark</button></div></div>`;}).join('')}</div><div class="wifi-footer">${connected?`IP ${World.clean(connected.ip)} · ${speed} Mbps · ${latency} ms latency`:'Connect to a network to enable Browser, OSINT and network CLI.'}</div></div>`;
    $$('[data-connect]',body).forEach(btn=>btn.onclick=()=>{
      const r=rows.find(x=>x.ssid===btn.dataset.connect); if(!r)return;
      if(r.password && !r.saved){ const entered=prompt(`Password for ${r.ssid}`); if(entered!==r.password){toast('Incorrect simulated Wi-Fi password.','error');return;} }
      s.world.wifiSsid=r.ssid; s.world.wifiIp=r.ip; s.world.wifiSpeed=r.speed; s.world.wifiSignal=Math.max(20,Math.min(100,100+r.signal)); s.world.wifiSecurity=r.security; s.world.wifiDetectionReduction=r.security==='Open'?0.02:0; s.world.wifiConnectedAt=Date.now(); syncPBNetworkState(s);
      s.log.unshift({ts:Clock.now(),type:'intel',text:`Connected to fictional Wi-Fi ${r.ssid}; IP ${r.ip}; ${r.speed} Mbps; latency ${World.latencyMs(s)} ms.`}); renderActivePanel(); renderStatusStrip(); saveSoon();
    });
    $$('[data-capture]',body).forEach(b=>b.onclick=()=>{if(!wifiConnected(s)){toast('Connect to a Wi-Fi network before opening a capture.','error');return;} s.world.wiresharkCapture=b.dataset.capture;s.world.wiresharkPackets=20+Math.round(World.simulatedSpeed(s)/2);App.activeTab='wireshark';renderWiresharkPanel($("#wireshark-body"));openDesktopWindow('wireshark');toast(`Wireshark capture opened for ${b.dataset.capture}`,'success');saveSoon();});
    saveSoon();
  }

  function renderWiresharkPanel(body) {
    const s=App.scnState;
    if(!requireWifi(s,body,'WIRESHARK ANALYZER')) return;
    const capture=s.world.wiresharkCapture || null, speed=World.simulatedSpeed(s);
    if(!capture){ body.innerHTML=`<div class="tool-title">WIRESHARK ANALYZER</div><div class="world-note">Separate fictional packet analyzer. Open a capture from Wi-Fi Scanner. No real network interfaces are accessed.</div><div class="empty-note">No capture selected.</div>`; return; }
    const packets=Math.max(12, s.world.wiresharkPackets||20);
    const rows=Array.from({length:Math.min(30,packets)},(_,i)=>({no:i+1,time:`00:00:${String((i*3)%60).padStart(2,'0')}.0${i%9}`,src:`10.20.${(s.id||1)%20}.${10+(i%20)}`,dst:`10.20.${(s.id||1)%20}.${80+(i%12)}`,proto:['DNS','TCP','TLSv1.3','HTTP','UDP'][i%5],len:64+(i*17)%900,info:['Standard query','ACK','Application Data','GET /status','Keepalive'][i%5]}));
    body.innerHTML=`<div class="tool-title">WIRESHARK ANALYZER</div><div class="capture-strip"><b>CAPTURE</b><span>${World.clean(capture)} · ${packets} simulated packets · ${speed} Mbps link</span></div><div class="wireshark-toolbar"><button class="btn tiny" id="ws-refresh">↻ Refresh</button><button class="btn tiny" id="ws-filter-dns">dns</button><button class="btn tiny" id="ws-filter-tcp">tcp</button><button class="btn tiny" id="ws-clear">Clear capture</button></div><div class="packet-table"><div class="packet-row packet-head"><span>No.</span><span>Time</span><span>Source</span><span>Destination</span><span>Protocol</span><span>Length</span><span>Info</span></div>${rows.map(r=>`<div class="packet-row"><span>${r.no}</span><span>${r.time}</span><span>${r.src}</span><span>${r.dst}</span><span>${r.proto}</span><span>${r.len}</span><span>${r.info}</span></div>`).join('')}</div>`;
    $("#ws-refresh",body)?.addEventListener('click',()=>{s.world.wiresharkPackets=Math.min(500,(s.world.wiresharkPackets||20)+5);renderWiresharkPanel($("#wireshark-body"));saveSoon();});
    $("#ws-filter-dns",body)?.addEventListener('click',()=>toast('Display filter: dns · fictional capture only','success'));
    $("#ws-filter-tcp",body)?.addEventListener('click',()=>toast('Display filter: tcp · fictional capture only','success'));
    $("#ws-clear",body)?.addEventListener('click',()=>{s.world.wiresharkCapture=null;s.world.wiresharkPackets=0;renderWiresharkPanel($("#wireshark-body"));saveSoon();});
  }

  function renderFilesPanel(body) {
    const s=App.scnState, catalog=World.filePaths(App.scenario), files=catalog.files;
    s.currentPath = s.currentPath || "/home/kali";
    const normalizePath=p=>{let x=String(p||'/home/kali').replace(/\\/g,'/');if(!x.startsWith('/'))x='/'+x;return x.length>1?x.replace(/\/$/,''):x;};
    let current=normalizePath(s.currentPath);
    const displayPath=p=>p==='/home/kali'?'/home/kali':p;
    function children(path){
      const base=normalizePath(path);
      const out=[];
      const seen=new Set();
      files.forEach(f=>{
        const fp=normalizePath(f.path);
        if(base==='/' && fp.startsWith('/')){
          const part=fp.split('/').filter(Boolean)[0]; const child='/'+part;
          if(!seen.has(child)){seen.add(child);out.push({kind:'dir',path:child,name:part});}
          return;
        }
        const prefix=base==='/'?'/':base+'/';
        if(fp.startsWith(prefix)){
          const rest=fp.slice(prefix.length); if(!rest)return;
          const part=rest.split('/')[0]; const child=prefix+part;
          if(rest.includes('/')) { if(!seen.has(child)){seen.add(child);out.push({kind:'dir',path:child,name:part});} }
          else if(!seen.has(fp)){seen.add(fp);out.push({kind:'file',path:fp,name:part,file:f});}
        }
      });
      // Expose known empty standard folders so Desktop/Documents/Downloads are explorable even when empty.
      ['/home/kali/Desktop','/home/kali/Documents','/home/kali/Downloads','/etc','/var','/tmp','/root','/opt'].forEach(d=>{
        if(d!==base && d.startsWith(base==='/home/kali'?base+'/':base+'/')){
          const rest=d.slice(base.length+1); if(rest && !rest.includes('/')){ if(!seen.has(d)){seen.add(d);out.push({kind:'dir',path:d,name:rest});} }
        }
      });
      return out.sort((a,b)=>(a.kind===b.kind?0:a.kind==='dir'?-1:1)||a.name.localeCompare(b.name));
    }
    function render(){
      const entries=children(current), visibleFiles=files.filter(f=>normalizePath(f.path).startsWith(current==='/'?'/':current+'/'));
      const places=['/home/kali','/home/kali/Desktop','/home/kali/Documents','/home/kali/Downloads','/etc','/var','/tmp','/root','/opt'];
      body.innerHTML=`<div class="kali-explorer"><div class="kx-top"><div class="kx-brand"><span class="kx-mark">◈</span><b>KALI FILE EXPLORER</b></div><div class="kx-path">${World.clean(displayPath(current))}</div><div class="kx-actions"><button class="btn tiny" id="kx-up">↑ Up</button><button class="btn tiny" id="kx-refresh">Refresh</button><button class="btn tiny" id="kx-new">New</button></div></div><div class="kx-layout"><aside class="kx-sidebar"><div class="kx-side-title">PLACES</div>${places.map(p=>`<button class="kx-place ${current===p?'active':''}" data-path="${World.clean(p)}">${p==='/home/kali'?'⌂ Home':p.endsWith('/Desktop')?'▣ Desktop':p.endsWith('/Documents')?'▤ Documents':p.endsWith('/Downloads')?'↓ Downloads':p==='/etc'?'⚙ etc':p==='/var'?'▥ var':p==='/tmp'?'◫ tmp':p==='/root'?'◉ root':'⌁ '+p.split('/').pop()}</button>`).join('')}<div class="kx-side-title">CURRENT</div><div class="kx-current-path">${World.clean(current)}</div><div class="kx-storage"><span>PB ROOT</span><i><em></em></i><small>${visibleFiles.length} file(s) in scope</small></div></aside><main class="kx-main"><div class="kx-toolbar"><input id="kx-path" value="${World.clean(current)}" aria-label="Path" placeholder="/path/to/folder"/><input id="kx-search" placeholder="Search files in this path…"/><span>${entries.length} item(s)</span></div><div class="kx-grid" id="kx-grid">${entries.length?entries.map((f,i)=>f.kind==='dir'?`<button class="kx-file kx-dir" data-dir="${World.clean(f.path)}"><span class="kx-file-icon">📁</span><b>${World.clean(f.name)}</b><small>Folder · ${World.clean(f.path)}</small></button>`:`<button class="kx-file" data-file-path="${World.clean(f.path)}"><span class="kx-file-icon">▤</span><b>${World.clean(f.name)}</b><small>${World.clean(f.path)}</small></button>`).join(''):`<div class="empty-note">This simulated path is empty. Use the terminal to create fictional files or choose another path.</div>`}</div><div class="kx-preview"><div class="kx-preview-head"><b>Preview</b><span id="kx-preview-path">Select a file</span></div><pre id="file-content">Select a fictional scenario file to inspect its contents.</pre></div></main></div></div>`;
      $$('[data-path]',body).forEach(b=>b.onclick=()=>{current=normalizePath(b.dataset.path);s.currentPath=current;render();saveSoon();});
      $('#kx-up',body).onclick=()=>{const parts=current.split('/').filter(Boolean);parts.pop();current=parts.length?'/'+parts.join('/'):'/';if(current==='/')current='/home/kali';s.currentPath=current;render();saveSoon();};
      $('#kx-refresh',body).onclick=render;
      $('#kx-new',body).onclick=()=>toast('New files are created through the simulated terminal and scenario tools.','info');
      function selectFile(path){const f=files.find(x=>normalizePath(x.path)===normalizePath(path));if(!f)return;s.world.filesViewed++;s.lastActionType='intel';s.log.unshift({ts:Clock.now(),type:'intel',text:`Viewed simulated file ${f.path} (quiet).`});$('#file-content',body).textContent=f.content;$('#kx-preview-path',body).textContent=f.path;$$('[data-file-path]',body).forEach(b=>b.classList.toggle('selected',normalizePath(b.dataset.filePath)===normalizePath(path)));if(App.desktopFileTarget==='__careers_upload__'){App.careersSelectedFile=f.path;App.desktopFileTarget=null;toast(`Selected ${f.name} for the Careers application.`,'success');const filesWin=$("#window-tools");if(filesWin) closeDesktopWindow(filesWin);App.activeTab='world';openDesktopWindow('tool','world');}saveSoon();}
      $$('[data-dir]',body).forEach(b=>b.onclick=()=>{current=normalizePath(b.dataset.dir);s.currentPath=current;render();saveSoon();});
      $$('[data-file-path]',body).forEach(b=>b.onclick=()=>selectFile(b.dataset.filePath));
      $('#kx-path',body).onkeydown=e=>{if(e.key!=='Enter')return;const next=normalizePath(e.target.value);if(catalog.dirs.includes(next)){current=next;s.currentPath=current;render();saveSoon();}else{toast(`Path not found in the simulated filesystem: ${next}`,'error');e.target.value=current;}}; $('#kx-search',body).oninput=e=>{const q=e.target.value.toLowerCase();$$('.kx-file',body).forEach(b=>b.classList.toggle('hidden',!b.textContent.toLowerCase().includes(q)));};
      if(App.desktopFileTarget){const target=normalizePath(App.desktopFileTarget);const f=files.find(x=>normalizePath(x.path)===target);App.desktopFileTarget=null;if(f){current=normalizePath(f.path).replace(/\/[^/]*$/,'')||'/home/kali';s.currentPath=current;render();selectFile(f.path);}}
    }
    render();
  }

  function renderIdentityPanel(body) {
    const s=App.scnState, active=s.protection||[];
    const catalog=World.identityCatalog();
    body.innerHTML=`<div class="tool-title">IDENTITY COVER</div><div class="world-note">Layered protection reduces consequences through the shared Protection engine. Costs are charged per activation.</div>`+
      catalog.map(x=>`<div class="shop-item"><div class="row1"><span class="name">${x.name}</span><span class="price">$${x.cost.toFixed(2)}</span></div><div class="blurb">${x.note} ${Math.round(x.reduction*100)}% reduction.</div><button class="btn small" data-id="${x.id}">Engage</button></div>`).join("")+`<div class="tool-title" style="margin-top:12px">ACTIVE LAYERS</div>`+
      (active.length?active.map(x=>`<div class="sys-row"><span>${World.clean(x.name)}</span><span>${Math.round(x.reduction*100)}%</span></div>`).join(""):`<div class="empty-note">No active cover layers.</div>`);
    $$("button[data-id]",body).forEach(b=>b.onclick=()=>{const r=Economy.buyProtection(s,App.player,b.dataset.id);if(!r.ok){toast(r.msg,"error");}else{printSys(`[identity] ${r.msg}`);renderActivePanel();renderStatusStrip();saveSoon();}});
  }

  function arrowFor(prev, cur) {
    if (cur > prev + 0.3) return `<span class="arrow-up">↑</span>`;
    if (cur < prev - 0.3) return `<span class="arrow-down">↓</span>`;
    return `<span class="arrow-flat">→</span>`;
  }

  function renderObjectivesPanel(body) {
    const p=Mission.progress(App.scnState,App.scenario);
    const m=App.scnState.mission;
    let html=`<div class="tool-title">MISSION OBJECTIVES</div><div class="world-note">Objectives are evidence-driven. Completing an objective can increase Reputation; the target may also adapt after milestones.</div>`;
    html+=`<div class="objective-progress"><div><b>${p.done}/${p.total}</b> objectives complete</div><div class="bar-track"><div class="bar-fill" style="width:${p.pct}%"></div></div></div>`;
    p.objectives.forEach(o=>{
      const cls=o.status.toLowerCase();
      html+=`<div class="mission-objective ${cls}"><div><span class="obj-status">${o.status}</span><b>${World.clean(o.description)}</b></div><div class="obj-meta">${Mission.difficultyName(o.difficulty)} · ${o.repAwarded?`+${o.repAwarded} Rep awarded`:o.status==='LOCKED'?'Awaiting prior objective':'Available'}</div></div>`;
    });
    if(m.milestones?.length) html+=`<div class="tool-title" style="margin-top:14px">RECENT MILESTONES</div>`+m.milestones.slice(0,8).map(x=>`<div class="log-entry type-objective">${World.clean(x.text)}</div>`).join('');
    body.innerHTML=html;
  }

  function renderSystemsPanel(body) {
    const s = App.scnState;
    const names = { monitoring: "Monitoring", authentication: "Authentication", webServices: "Web Services", internalSystems: "Internal Systems", logging: "Logging" };
    let html = `<div style="margin-bottom:10px;font-size:11px;color:var(--text-dim);">Response Team: <b style="color:var(--text-bright)">${s.responseTeam}</b></div><div class="recovery-card"><div><b>Recovery posture</b> <span class="recovery-chip">÷${Recovery.divisorForTier(s.recoveryTier)}</span></div><div class="recovery-bar"><span style="width:${Math.min(100, (Recovery.status(s).stageHours / Math.max(0.01, Recovery.status(s).stageHours + Recovery.status(s).leftHours))*100)}%"></span></div><div class="recovery-copy">${s.recoveryPaused ? "Score recovery is settling after noisy activity." : s.recoveryHalfRate ? "Recovery is moving at half rate after recent pressure." : "Quiet time is restoring operational discipline."}</div></div>`;
    Object.keys(names).forEach(k => {
      html += `<div class="sys-row"><span>${names[k]}</span><span>${arrowFor(s.systemsPrev[k], s.systems[k])} ${Math.round(s.systems[k])}</span></div>`;
    });
    html += `<div style="margin-top:14px;font-size:10.5px;color:var(--text-dim);line-height:1.5;">Awareness: <b style="color:var(--text)">${Math.round(s.awareness)}/100</b><br/>Peak Heat this mission: ${Math.round(s.peakHeat)}<br/>Recovery tier: ÷${Recovery.divisorForTier(s.recoveryTier)} ${s.recoveryPaused ? "(paused — recent activity)" : "(active)"}</div>`;
    body.innerHTML = html;
  }

  function renderProtectionPanel(body) {
    const s = App.scnState;
    let html = "";
    const active = s.protection.filter(p => !p.expiresAt || p.expiresAt > Clock.now());
    if (active.length) {
      html += `<div style="margin-bottom:12px;font-size:11px;">Active: ${active.map(p => p.name).join(", ")} — total reduction ${Math.round(Heat.totalProtectionReduction(s) * 100)}%</div>`;
    }
    Economy.PROTECTION_CATALOG.forEach(p => {
      html += `<div class="shop-item">
        <div class="row1"><span class="name">${p.name}</span><span class="price">$${p.cost.toFixed(2)}</span></div>
        <div class="blurb">${p.blurb} · ${Math.round(p.reduction * 100)}% reduction · ${p.durationMin}m</div>
        <button class="btn small" data-prot="${p.id}">Engage</button>
      </div>`;
    });
    body.innerHTML = html;
    $$("[data-prot]", body).forEach(btn => btn.onclick = () => {
      const r = Economy.buyProtection(App.scnState, App.player, btn.dataset.prot);
      if (!r.ok) toast(r.msg,"error"); else { renderStatusStrip(); renderActivePanel(); saveSoon(); }
    });
  }

  function renderIntelPanel(body) {
    const catalog = Economy.intelCatalog(App.scenario);
    let html = "";
    catalog.forEach(p => {
      const owned = App.scnState.intelPurchased.includes(p.id);
      html += `<div class="shop-item">
        <div class="row1"><span class="name">${p.tier}</span><span class="price">${p.cost === 0 ? "Free" : "$" + p.cost.toFixed(2)}</span></div>
        <div class="blurb">${p.blurb}</div>
        ${owned ? `<div class="result-box pass">${p.reveal}</div>` : `<button class="btn small" data-intel="${p.id}">Acquire</button>`}
      </div>`;
    });
    body.innerHTML = html;
    $$("[data-intel]", body).forEach(btn => btn.onclick = () => {
      const r = Economy.buyIntel(App.scnState, App.player, App.scenario, btn.dataset.intel);
      if (!r.ok) toast(r.msg,"error"); else { renderStatusStrip(); renderActivePanel(); saveSoon(); }
    });
  }

  function renderRedTeamPanel(body) {
    const quotes = Economy.redTeamQuote(App.scnState);
    let html = `<div style="font-size:10.5px;color:var(--text-dim);margin-bottom:10px;">Prices rise as Score falls. Uses this mission: ${App.scnState.redTeamUses}${Number(App.scnState.reputation)>=20?` · <b>MAX REPUTATION DISCOUNT: 50%</b>`:""}</div>`;
    quotes.forEach(q => {
      html += `<div class="shop-item">
        <div class="row1"><span class="name">${q.name}</span><span class="price">$${q.price.toFixed(2)}</span></div>
        <button class="btn small" data-rt="${q.id}">Hire</button>
      </div>`;
    });
    body.innerHTML = html;
    $$("[data-rt]", body).forEach(btn => btn.onclick = () => {
      const r = Economy.hireRedTeam(App.scnState, App.player, App.scenario, btn.dataset.rt);
      if (!r.ok) { toast(r.msg,"error"); return; }
      printSys(`[Red Team] ${r.msg}`);
      renderStatusStrip(); renderActivePanel(); saveSoon();
    });
  }

  function renderAssessmentsPanel(body) {
    const tasks = Assessment.ensureSet(App.scenario, App.scnState);
    const s = App.scnState;
    let html = `<div style="font-size:10.5px;color:var(--text-dim);margin-bottom:10px;">${tasks.length} assessments generated · question pools: 100+ Very Easy · 200+ Easy · 200+ Moderate · 100+ Hard · 100+ Very Hard · 100+ Extreme<br>Earned this mission: $${s.assessmentEarnings.toFixed(2)} / $${s.assessmentCap.toFixed(2)} cap · Band: ${Assessment.bandFor(App.scnState ? App.scnState.reputation : 10).label}</div>`;
    tasks.forEach(task => {
      html += `<div class="task-block" data-task="${task.id}"><h4>${task.title}</h4>`;
      task.objectives.forEach(obj => {
        const done = s.objectiveResults[obj.id];
        const available = Assessment.objectiveAvailable(App.scnState ? App.scnState.reputation : 10, obj.difficulty);
        html += `<div class="objective" data-obj="${obj.id}">
          <div class="prompt">${obj.prompt}<span class="diff-tag">${obj.type.toUpperCase()} · ${obj.difficulty}</span></div>`;
        if (done) {
          html += `<div class="result-box ${done.cancelled ? "" : (done.pass ? "pass" : "fail")}">${done.pass ? "PASSED" : "FAILED"} · ${done.reward ? "+$" + done.reward.toFixed(2) + " · " : ""}Reputation ${done.repDelta >= 0 ? "+" : ""}${done.repDelta}</div>`;
        } else if (!available) {
          html += `<div class="locked-tag">🔒 Requires higher Reputation to unlock (${obj.difficulty} tier).</div>`;
        } else {
          const opts = obj.options.slice(0, 4);
          opts.forEach(o => { html += `<button class="opt-btn" data-answer="${encodeURIComponent(o)}">${o}</button>`; });
        }
        html += `</div>`;
      });
      html += `</div>`;
    });
    body.innerHTML = html;

    $$(".task-block", body).forEach(taskEl => {
      const taskId = taskEl.dataset.task;
      $$(".objective", taskEl).forEach(objEl => {
        const objId = objEl.dataset.obj;
        let hintsUsed = 0;
        $$("[data-answer]", objEl).forEach(optBtn => {
          optBtn.onclick = () => {
            const answer = decodeURIComponent(optBtn.dataset.answer);
            const r = Assessment.submit(App.player, App.scnState, App.scenario, taskId, objId, answer, hintsUsed);
            if (!r.ok) { toast(r.msg,"error"); return; }
            $$("[data-answer]", objEl).forEach(b => {
              const bv = decodeURIComponent(b.dataset.answer);
              if (bv === r.correct) b.classList.add("correct");
              if (bv === answer && !r.pass) b.classList.add("wrong");
              b.disabled = true;
            });
            const box = el("div", `result-box ${r.pass ? "pass" : "fail"}`, `${r.pass ? "CORRECT" : "INCORRECT"} · ${r.reward ? "+$" + r.reward.toFixed(2) + " · " : ""}Reputation ${r.repDelta >= 0 ? "+" : ""}${r.repDelta}<br/><br/>${r.explanation}`);
            objEl.appendChild(box);
            renderStatusStrip(); saveSoon();
            if (r.terminates) {
              printSys(`[Assessment] Gate objective failed — remaining objectives in "${taskId}" are cancelled.`);
            }
          };
        });
      });
    });
  }

  function renderLogPanel(body) {
    const log = App.scnState.log;
    if (!log.length) { body.innerHTML = `<div class="empty-note">No activity yet.</div>`; return; }
    let html = "";
    log.slice(0, 60).forEach(l => {
      const t = new Date(l.ts).toLocaleTimeString();
      html += `<div class="log-entry type-${l.type}"><span class="ts">${t}</span>${l.text}</div>`;
    });
    body.innerHTML = html;
  }

  // ── Live tick loop ──
  function startTick() {
    App.lastTickAt = Clock.now();
    stopTick();
    App.tickTimer = setInterval(() => {
      const now = Clock.now();
      const realMinutes = Clock.msToMinutes(now - App.lastTickAt);
      App.lastTickAt = now;
      Recovery.liveTick(App.scnState, App.company, realMinutes);
      const timeResult=MissionTime.apply(App.scnState,App.company);
      const liveProgress=Mission.progress(App.scnState,App.scenario);
      if(liveProgress.done===liveProgress.total && liveProgress.total>0 && !App.scnState.completed && App.scnState.mission?.outcome!=='COMPLETE'){
        App.scnState.mission.outcome='COMPLETE';
        App.scnState.mission.completedAt ||= Clock.now();
        stopTick();
        saveSoon();
        setTimeout(()=>{ fileMissionReport(); closeScenario(); },80);
        return;
      }
      if(timeResult.gameOver){
        stopTick();
        renderStatusStrip(); renderObjectiveDock(); saveSoon();
        setTimeout(()=>{ fileMissionReport(); closeScenario(); },80);
        return;
      }
      const clockNode = $("#scenario-clock");
      if (clockNode) {
        const elapsed = MissionTime.elapsedMs(App.scnState);
        const total = Math.floor(elapsed / 1000);
        clockNode.textContent = new Date(total * 1000).toISOString().slice(11, 19);
      }
      renderStatusStrip();
      renderObjectiveDock();
      if (App.activeTab === "systems") renderActivePanel();
    }, 5000);
  }
  function stopTick() { if (App.tickTimer) { clearInterval(App.tickTimer); App.tickTimer = null; } }

  // ── Mission report ──
  function gradeMission(s, scenario) {
    const p = Mission.progress(s, scenario);
    const discipline = Math.max(0, 100 - Math.round(s.peakHeat));
    const efficiency = Math.max(0, 100 - s.redTeamUses * 8);
    const objective = p.pct;
    const gradeScore = Math.round(objective * 0.55 + discipline * 0.25 + efficiency * 0.20);
    return gradeScore >= 95 ? "S" : gradeScore >= 88 ? "A" : gradeScore >= 78 ? "B" : gradeScore >= 65 ? "C" : gradeScore >= 50 ? "D" : "F";
  }

  function fileMissionReport() {
    const s = App.scnState;
    if (!s || !App.scenario) return;
    const p = Mission.progress(s, App.scenario);
    const flags = App.scenario.flags || [];
    const objectivesPct = flags.length ? Math.round((s.flagsFound.length / flags.length) * 100) : 100;
    const disciplinePct = Math.round(Math.max(0, 100 - s.peakHeat));
    const efficiencyPct = Math.round(Math.max(0, 100 - s.redTeamUses * 8));
    const intelCatalog = Economy.intelCatalog(App.scenario);
    const intelPct = Math.round(Math.min(100, (s.intelPurchased.length / Math.max(1, intelCatalog.length)) * 60 + (s.assessmentEarnings / Math.max(1,s.assessmentCap)) * 40));
    const grade = gradeMission(s, App.scenario);
    const wasComplete = p.done === p.total && p.total > 0;
    const startSnap = s.mission.startSnapshot || {score:100,reputation:10,credits:100,heat:0,assessments:0};
    const elapsedMs = MissionTime.elapsedMs(s);
    const timeInfo = MissionTime.apply(s,App.scenario);
    const delta = {
      score: Math.round((Number(s.score)||0)-(Number(startSnap.score)||0)),
      reputation: Math.round((Number(s.reputation)||0)-(Number(startSnap.reputation)||0)),
      credits: Math.round(((Number(s.credits)||0)-(Number(startSnap.credits)||0))*100)/100,
      heat: Math.round(((Number(s.heat)||0)-(Number(startSnap.heat)||0))*10)/10,
      assessments: Math.round(((Number(s.assessmentEarnings)||0)-(Number(startSnap.assessments)||0))*100)/100,
      cashSpent: Math.round(((Number(s.actionStats?.creditsSpent)||0)-(Number(startSnap.cashSpent)||0))*100)/100,
      cashEarned: Math.round(((Number(s.actionStats?.creditsEarned)||0)-(Number(startSnap.cashEarned)||0))*100)/100
    };
    const assessmentRows=(App.player.assessmentHistory||[]).filter(x=>Number(x.scenarioId)===Number(App.company.id) && Number(x.ts)>=Number(s.mission.startSnapshotAt||0));
    const assessmentPasses=assessmentRows.filter(x=>x.pass).length;
    const assessmentFailures=assessmentRows.filter(x=>!x.pass).length;
    s.mission.attempts = Math.max(0, Number(s.mission.attempts)||0) + 1;
    s.mission.outcome = Mission.outcome(s, App.scenario);
    s.mission.lastReportAt = Clock.now();
    if (wasComplete) {
      s.completed = true;
      s.mission.completedAt = Clock.now();
      s.mission.bestScore = s.mission.bestScore == null ? Math.round(s.score) : Math.max(Number(s.mission.bestScore)||0, Math.round(s.score));
      const rank = {S:6,A:5,B:4,C:3,D:2,F:1}[grade]||1;
      const oldRank = {S:6,A:5,B:4,C:3,D:2,F:1}[s.mission.bestGrade]||0;
      if (rank >= oldRank) s.mission.bestGrade = grade;
      if (!s.mission.profileRecordedAt) {
        App.player.profile.totalMissions = (Number(App.player.profile.totalMissions)||0) + 1;
        App.player.profile.successfulMissions = (Number(App.player.profile.successfulMissions)||0) + 1;
        App.player.profile.totalHeat = (Number(App.player.profile.totalHeat)||0) + Math.round(s.heat);
        App.player.profile.objectivesCompleted = (Number(App.player.profile.objectivesCompleted)||0) + p.done;
        s.mission.profileRecordedAt = Clock.now();
      }
      App.player.profile.bestScore = Math.max(Number(App.player.profile.bestScore)||0, Math.round(s.score));
      App.player.profile.stealthBest = Math.max(Number(App.player.profile.stealthBest)||0, disciplinePct);
      App.player.profile.lastGrade = grade;
      unlockAchievements();
    }
    saveSoon();
    const status = wasComplete ? "MISSION COMPLETE" : (s.timedOut ? "TIME LIMIT REACHED" : "PROGRESS REPORT");
    const outcome = s.mission.outcome;
    const best = s.mission.bestScore == null ? "—" : Math.round(s.mission.bestScore);
    const modal = el("div", "modal-backdrop");
    modal.innerHTML = `
      <div class="modal report-modal">
        <div class="report-kicker">${wasComplete ? "OPERATION CLOSED" : "LIVE OPERATION"}</div>
        <h2>${status}</h2>
        <div class="report-hero"><div><span>OPERATOR GRADE</span><strong>${grade}</strong></div><div><span>OUTCOME</span><strong>${escapeHtml(outcome)}</strong></div><div><span>BEST SCORE</span><strong>${best}</strong></div></div>
        <div class="report-grid">
          <div class="report-section"><h3>Mission performance</h3>
            <div class="report-row"><span class="lbl">Objectives</span><span class="val">${objectivesPct}% · ${p.done}/${p.total}</span></div>
            <div class="report-row"><span class="lbl">Operational Discipline</span><span class="val">${disciplinePct}%</span></div>
            <div class="report-row"><span class="lbl">Resource Efficiency</span><span class="val">${efficiencyPct}%</span></div>
            <div class="report-row"><span class="lbl">Intelligence</span><span class="val">${intelPct}%</span></div>
          </div>
          <div class="report-section"><h3>State & economy</h3>
            <div class="report-row"><span class="lbl">Peak Heat</span><span class="val">${Math.round(s.peakHeat)}</span></div>
            <div class="report-row"><span class="lbl">Final Score</span><span class="val">${Math.round(s.score)}</span></div>
            <div class="report-row"><span class="lbl">Credits</span><span class="val">$${Number(s.credits).toFixed(2)}</span></div>
            <div class="report-row"><span class="lbl">Reputation</span><span class="val">${Math.round(s.reputation)}/20</span></div>
          </div>
          <div class="report-section"><h3>Change from start</h3>
            <div class="report-row"><span class="lbl">Score</span><span class="val">${delta.score>=0?'+':''}${delta.score}</span></div>
            <div class="report-row"><span class="lbl">Heat</span><span class="val">${delta.heat>=0?'+':''}${delta.heat}</span></div>
            <div class="report-row"><span class="lbl">Reputation</span><span class="val">${delta.reputation>=0?'+':''}${delta.reputation}</span></div>
            <div class="report-row"><span class="lbl">Credits net</span><span class="val">${delta.credits>=0?'+$':'-$'}${Math.abs(delta.credits).toFixed(2)}</span></div>
            <div class="report-row"><span class="lbl">Cash deductions</span><span class="val">-$${delta.cashSpent.toFixed(2)}</span></div>
            <div class="report-row"><span class="lbl">Cash increases</span><span class="val">+$${delta.cashEarned.toFixed(2)}</span></div>
            <div class="report-row"><span class="lbl">Assessment earnings</span><span class="val">+$${delta.assessments.toFixed(2)}</span></div>
          </div>
          <div class="report-section"><h3>Time & pressure</h3>
            <div class="report-row"><span class="lbl">Operation time</span><span class="val">${MissionTime.durationLabel(elapsedMs)}</span></div>
            <div class="report-row"><span class="lbl">Time stage</span><span class="val">${timeInfo.stage}/5</span></div>
            <div class="report-row"><span class="lbl">Current score ceiling</span><span class="val">${timeInfo.cap||0}</span></div>
            <div class="report-row"><span class="lbl">Assessment activity</span><span class="val">${assessmentRows.length} submitted · ${assessmentPasses} passed · ${assessmentFailures} failed</span></div>
          </div>
          <div class="report-section"><h3>Operational footprint</h3>
            <div class="report-row"><span class="lbl">Peak Heat</span><span class="val">${Math.round(s.peakHeat)}</span></div>
            <div class="report-row"><span class="lbl">Actions</span><span class="val">${(s.actionStats?.quiet||0)+(s.actionStats?.noisy||0)}</span></div>
            <div class="report-row"><span class="lbl">Noisy actions</span><span class="val">${s.actionStats?.noisy||0}</span></div>
            <div class="report-row"><span class="lbl">Credits spent</span><span class="val">$${Number(s.actionStats?.creditsSpent||0).toFixed(2)}</span></div>
            <div class="report-row"><span class="lbl">Intel packages</span><span class="val">${s.intelPurchased?.length||0}</span></div>
          </div>
        </div>
        <div class="report-next">${wasComplete ? `Operation ${App.company.id} is filed. Replay it to beat your ${best}-point record.` : (s.timedOut ? `The operation exceeded its ${App.company.difficulty} time limit and has been terminated.` : `The report is not filed yet. Complete all ${p.total} objectives to close the operation and establish a personal best.`)}</div>
        <div class="actions"><button class="btn" id="report-close">Close</button>${(!wasComplete && !s.timedOut) ? `<button class="btn primary" id="report-objectives">Open Objectives</button>` : `<button class="btn primary" id="report-board">Back to Board</button>`}</div>
      </div>`;
    document.body.appendChild(modal);
    $("#report-close", modal).onclick = () => modal.remove();
    $("#report-board", modal)?.addEventListener("click", () => { modal.remove(); closeScenario(); });
    $("#report-objectives", modal)?.addEventListener("click", () => { modal.remove(); $("#objective-dock")?.classList.remove("collapsed"); $("#objective-dock-open")?.classList.add("hidden"); });
  }

  function unlockAchievements() {
    const p = App.player, profile = p.profile || (p.profile = {achievements:[]});
    const add = id => { profile.achievements ||= []; if (!profile.achievements.includes(id)) profile.achievements.push(id); };
    const completed = Object.values(p.scenarios||{}).filter(s=>s?.completed);
    if (completed.length >= 1) add("first-operation");
    if (completed.length >= 3) add("three-operations");
    if (completed.length >= 10) add("full-catalog");
    if (Number(profile.stealthBest)>=90) add("ghost-operator");
    if (Number(profile.bestScore)>=100) add("century");
  }



  function openDebugPanel() {
    if (new URLSearchParams(location.search).get("debug") !== "1") return;
    const s=App.scnState, modal=el("div","modal-backdrop");
    const buttons = s ? `<button class="btn tiny" data-debug="heat">Heat +10</button><button class="btn tiny" data-debug="score">Score +10</button><button class="btn tiny" data-debug="credits">Credits +100</button><button class="btn tiny" data-debug="rep">Rep +1</button><button class="btn tiny" data-debug="complete">Complete next objective</button><button class="btn tiny" data-debug="alert">Raise alert</button><button class="btn tiny" data-debug="report">Open report</button><button class="btn tiny" data-debug="resetmission">Reset mission state</button>` : `<div class="empty-note">Open a mission first.</div>`;
    modal.innerHTML=`<div class="modal debug-modal"><div class="report-kicker">DEVELOPER TOOLING</div><h2>Simulator Test Console</h2><p class="world-note">Debug mode is enabled with <code>?debug=1</code>. These controls only mutate the fictional local simulator state.</p><div class="debug-grid">${buttons}</div><div class="actions"><button class="btn primary" id="debug-close">Close</button></div></div>`;
    document.body.appendChild(modal); $("#debug-close",modal).onclick=()=>modal.remove();
    $$('[data-debug]',modal).forEach(b=>b.onclick=()=>{
      const action=b.dataset.debug;
      if(!App.scnState){toast('Open a mission first.','error');return;}
      if(action==='heat'){App.scnState.heat=State.clamp(App.scnState.heat+10,0,100);App.scnState.peakHeat=Math.max(App.scnState.peakHeat,App.scnState.heat);}
      if(action==='score')App.scnState.score=State.clamp(App.scnState.score+10,0,100);
      if(action==='credits')App.scnState.credits+=100;
      if(action==='rep')App.scnState.reputation=State.clamp(App.scnState.reputation+1,0,20);
      if(action==='alert')Heat.applyAlert(App.scnState,App.company,8,'debug test');
      if(action==='complete'){const n=Mission.progress(App.scnState,App.scenario).next;if(n){App.scnState.flagsFound.push(n.id);Mission.onFlags(App.scnState,App.player,App.scenario,[n.id]);}}
      if(action==='resetmission'){const fresh=State.freshScenarioState(App.company);App.player.scenarios[App.company.id]=fresh;App.scnState=fresh;Mission.ensure(App.scnState,App.scenario);}
      if(action==='report'){modal.remove();fileMissionReport();return;}
      renderStatusStrip();renderObjectiveDock();renderActivePanel();saveSoon();toast(`Debug: ${action}`,'info');
    });
  }

  // ───────────────────────── Desktop / Window Manager ─────────────────────────
  const DESKTOP_APPS = [
    {id:"terminal", label:"Terminal", icon:"▣", kind:"terminal"},
    {id:"files", label:"Files", icon:"▰", kind:"tool", tab:"files"},
    {id:"browser", label:"Browser", icon:"◎", kind:"tool", tab:"world"},
    {id:"wireshark", label:"Wireshark", icon:"◉", kind:"wireshark"},
    {id:"identity", label:"Identity", icon:"◈", kind:"tool", tab:"identity"},
    {id:"wifi", label:"Wi-Fi Scan", icon:"▥", kind:"tool", tab:"network"}
  ];

  function openDesktopWindow(kind, tab) {
    const win = kind === "terminal" ? $("#window-terminal") : (kind === "wireshark" ? $("#window-wireshark") : $("#window-tools"));
    if (!win) return;
    if (kind === "tool" && tab) { App.activeTab = tab; renderPanelTabs(); renderActivePanel(); }
    if (kind === "wireshark") { App.activeTab = "wireshark"; renderWiresharkPanel($("#wireshark-body")); }
    win.classList.remove("hidden", "minimized");
    bringToFront(win);
    updateTaskbar();
    if (kind === "terminal") setTimeout(() => $("#term-input")?.focus(), 30);
  }
  function closeDesktopWindow(win) { if (!win) return; win.classList.add("hidden"); updateTaskbar(); }
  function bringToFront(win) {
    $$(".desktop-window").forEach(w => w.classList.remove("focused"));
    win.classList.add("focused");
    App._z = (App._z || 30) + 1; win.style.zIndex = App._z;
  }
  function toggleMaximize(win) {
    win.classList.toggle("maximized");
    bringToFront(win);
  }
  function updateTaskbar() {
    const wrap = $("#taskbar-apps"); if (!wrap) return;
    wrap.innerHTML = "";
    const entries = [
      ["terminal", "Terminal", $("#window-terminal")],
      ["tools", $("#tool-window-title")?.textContent?.replace("PROTOCOL BREACH — ", "") || "Tools", $("#window-tools")],
      ["wireshark", "Wireshark", $("#window-wireshark")]
    ];
    entries.forEach(([id,label,win]) => {
      if (!win || win.classList.contains("hidden")) return;
      const b = el("button", "taskbar-app" + (win.classList.contains("focused") ? " active" : ""), `<img class="tb-image" src="assets/icons/${id === "terminal" ? "terminal" : (id === "wireshark" ? "wireshark" : "files")}.svg" alt="" aria-hidden="true">${escapeHtml(label)}`);
      b.onclick = () => { if (win.classList.contains("focused")) closeDesktopWindow(win); else openDesktopWindow(id === "terminal" ? "terminal" : (id === "wireshark" ? "wireshark" : "tool"), App.activeTab); };
      wrap.appendChild(b);
    });
  }
  function makeDesktopIcons() {
    const wrap = $("#desktop-icons"); if (!wrap) return;
    wrap.innerHTML = "";
    DESKTOP_APPS.forEach(app => {
      const b = el("button", "desktop-icon", `<img class="desktop-icon-image" src="assets/icons/${app.id}.svg" alt="" aria-hidden="true"><span>${escapeHtml(app.label)}</span>`);
      b.title = `${app.label} — double-click to open`;
      b.dataset.app = app.id;
      b.ondblclick = () => openDesktopWindow(app.kind, app.tab);
      b.onclick = () => { $$(".desktop-icon").forEach(x => x.classList.remove("selected")); b.classList.add("selected"); };
      wrap.appendChild(b);
    });
    // Scenario files appear directly on the desktop as shortcuts.
    const files = App.scenario ? World.files(App.scenario).slice(0, 8) : [];
    files.forEach((f, i) => {
      const b = el("button", "desktop-icon file-shortcut", `<span class="desktop-file-image">${i % 2 ? "▤" : "▱"}</span><span>${escapeHtml(f.path.split("/").pop())}</span>`);
      b.title = f.path;
      b.ondblclick = () => { App.desktopFileTarget = f.path; openDesktopWindow("tool", "files"); };
      b.onclick = () => { $$(".desktop-icon").forEach(x => x.classList.remove("selected")); b.classList.add("selected"); };
      wrap.appendChild(b);
    });
  }
  let resetInProgress=false;
  function clearAllLocalData(){
    resetInProgress=true;
    // Hard reset: disable every persistence writer before touching storage.
    try { if(App.tickTimer) clearInterval(App.tickTimer); App.tickTimer=null; } catch(e) {}
    try { if(App.saveTimer) clearInterval(App.saveTimer); App.saveTimer=null; } catch(e) {}
    try { if(App.clockTimer) clearInterval(App.clockTimer); App.clockTimer=null; } catch(e) {}
    try { if(App.unloadHandler) { window.removeEventListener('beforeunload', App.unloadHandler); App.unloadHandler=null; } } catch(e) {}
    // Mark the browser context as reset so any already-queued unload callback cannot restore state.
    try { sessionStorage.setItem('PB_RESET_IN_PROGRESS','1'); } catch(e) {}
    // Remove only Protocol Breach-owned persistence. Do not destroy unrelated data
    // belonging to other applications that happen to share the same origin.
    try { State.wipe(); } catch(e) {}
    try { localStorage.removeItem(INTRO_DONE_KEY); localStorage.removeItem(AGREEMENT_KEY); } catch(e) {}
    try { sessionStorage.removeItem('PB_RESET_IN_PROGRESS'); } catch(e) {}
    window.PBNetworkState={connected:false,ssid:'',ip:'',speed:0,security:'',detectionReduction:0};
    try { App.player=State.freshPlayer(); App.scnState=null; App.scenario=null; App.company=null; } catch(e) {}
  }
  function resetApplication(){
    if(!window.confirm('Reset Protocol Breach? This deletes ALL simulator progress and returns the application to a fresh-install state.')) return;
    clearAllLocalData();
    // Do not save anything during reset. Replace the document rather than relying on a normal reload path.
    window.location.replace(window.location.pathname + '?fresh=1&reset=' + Date.now());
  }

  function shutdownSimulator() {
    try { saveSoon(); State.save(App.player); } catch(e) {}
    try { stopTick(); } catch(e) {}
    $$(".desktop-window").forEach(w => w.classList.add("hidden"));
    if (App.scnState?.world) { App.scnState.world.wifiSsid=''; App.scnState.world.wifiIp=''; App.scnState.world.wifiSpeed=0; App.scnState.world.wifiSignal=0; App.scnState.world.wifiSecurity=''; App.scnState.world.wifiDetectionReduction=0; App.scnState.world.wifiConnectedAt=0; }
    window.PBNetworkState = {connected:false,ssid:'',ip:'',speed:0,security:'',detectionReduction:0,shutdownAt:Date.now()};
    const desktop = $("#desktop");
    if (desktop) {
      const overlay = el("div","shutdown-overlay",`<div class="shutdown-card"><div class="shutdown-logo">PROTOCOL BREACH</div><div class="shutdown-spinner"></div><h2>Shutting down</h2><p>Saving mission state and closing simulated applications…</p></div>`);
      desktop.appendChild(overlay);
      setTimeout(() => { overlay.remove(); showBoard(); toast("Protocol Breach shut down safely. Progress saved.","success"); }, 900);
    } else { showBoard(); }
  }

  function initDesktopUI() {
    if (!$("#desktop")) return;
    makeDesktopIcons();
    const clock = $("#taskbar-clock");
    if (!App.desktopReady) {
      App.desktopReady = true;
      $$(".desktop-window").forEach(win => {
        win.addEventListener("mousedown", () => bringToFront(win));
        $(".win-close", win)?.addEventListener("click", e => { e.stopPropagation(); closeDesktopWindow(win); });
        $(".win-min", win)?.addEventListener("click", e => { e.stopPropagation(); win.classList.add("hidden"); updateTaskbar(); });
        $(".win-max", win)?.addEventListener("click", e => { e.stopPropagation(); toggleMaximize(win); });
        makeDraggable(win);
      });
      $("#taskbar-start")?.addEventListener("click", () => {
        const menu = $("#desktop-file-popover");
        menu.innerHTML = `<div class="start-menu"><div class="start-title">PROTOCOL BREACH <span>APPLICATIONS</span></div><div class="start-section">CORE</div><button data-start="terminal"><img class="start-menu-icon" src="assets/icons/terminal.svg" alt="">Terminal</button><button data-start="files"><img class="start-menu-icon" src="assets/icons/files.svg" alt="">Files</button><button data-start="world"><img class="start-menu-icon" src="assets/icons/browser.svg" alt="">Browser / OSINT</button><button data-start="network"><img class="start-menu-icon" src="assets/icons/wifi.svg" alt="">Wi-Fi Scanner</button><button data-start="wireshark"><img class="start-menu-icon" src="assets/icons/wireshark.svg" alt="">Wireshark Analyzer</button><button data-start="identity"><img class="start-menu-icon" src="assets/icons/identity.svg" alt="">Identity Cover</button><div class="start-section">INTELLIGENCE</div><button data-start="comms"><img class="start-menu-icon" src="assets/icons/phone.svg" alt="">ComsApp / Mail / Phone</button><button data-start="social"><img class="start-menu-icon" src="assets/icons/social.svg" alt="">Social Media</button><button data-start="location"><img class="start-menu-icon" src="assets/icons/location.svg" alt="">Location Intel</button><button data-start="intel">◇ Intelligence</button><div class="start-section">OPERATIONS</div><button data-start="redteam">◆ Red Team</button><button data-start="assessments">✓ Assessments</button><button data-start="objectives">☷ Objectives</button><button data-start="log">≡ Activity Log</button><button data-start="taskmanager">▥ Task Manager</button>${new URLSearchParams(location.search).get("debug")==="1"?'<button data-start="debug">⚙ Test Console</button>':''}<div class="start-section">POWER</div><button data-start="shutdown" class="start-power">⏻ Shutdown</button><div class="start-foot">LOCAL SIMULATION · OFFLINE · FICTIONAL DATA ONLY</div></div>`;
        menu.classList.toggle("hidden");
        $$("[data-start]", menu).forEach(b => b.onclick = () => { menu.classList.add("hidden"); if (b.dataset.start === "shutdown") shutdownSimulator(); else if (b.dataset.start === "terminal") openDesktopWindow("terminal"); else if (b.dataset.start === "wireshark") openDesktopWindow("wireshark"); else if (b.dataset.start === "debug") openDebugPanel(); else openDesktopWindow("tool", b.dataset.start); });
      });
      document.addEventListener("click", e => { if (!e.target.closest("#taskbar-start") && !e.target.closest("#desktop-file-popover")) $("#desktop-file-popover")?.classList.add("hidden"); });
    }
    if (clock) clock.textContent = new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",hour12:false});
    updateTaskbar();
  }
  function makeDraggable(win) {
    const bar = $(".window-titlebar", win); if (!bar) return;
    let drag = null;
    bar.addEventListener("pointerdown", e => {
      if (e.target.closest("button")) return;
      if (win.classList.contains("maximized")) return;
      bringToFront(win); bar.setPointerCapture(e.pointerId);
      const r = win.getBoundingClientRect(); drag = {x:e.clientX,y:e.clientY,left:r.left,top:r.top};
    });
    bar.addEventListener("pointermove", e => {
      if (!drag) return;
      const desktop = $("#desktop").getBoundingClientRect();
      const left = Math.max(8, Math.min(desktop.width-win.offsetWidth-8, drag.left-desktop.left+e.clientX-drag.x));
      const top = Math.max(48, Math.min(desktop.height-win.offsetHeight-60, drag.top-desktop.top+e.clientY-drag.y));
      win.style.left = left + "px"; win.style.top = top + "px"; win.style.right = "auto"; win.style.bottom = "auto";
    });
    bar.addEventListener("pointerup", () => { drag = null; });
  }

  window.addEventListener("error", e => {
    console.error("[Protocol Breach]", e.error || e.message);
    if (window.App?.player) try { State.save(window.App.player); } catch (_) {}
    toast("A simulator error was contained. Your last saved state was preserved.", "error");
  });
  window.addEventListener("unhandledrejection", e => {
    console.error("[Protocol Breach promise]", e.reason);
    if (window.App?.player) try { State.save(window.App.player); } catch (_) {}
  });

  document.addEventListener('visibilitychange',()=>{ if(App.scnState){ if(document.visibilityState==='hidden') MissionTime.pause(App.scnState); else MissionTime.resume(App.scnState); saveSoon(); }});
  window.addEventListener('offline',()=>{ if(App.scnState) MissionTime.pause(App.scnState); saveSoon(); });
  window.addEventListener('online',()=>{ if(App.scnState && document.visibilityState!=='hidden') MissionTime.resume(App.scnState); });
  window.addEventListener('beforeunload',()=>{ if(App.scnState) MissionTime.pause(App.scnState); try{State.save(App.player);}catch(_){}});

  document.addEventListener("DOMContentLoaded", () => {
    const bindClick = (selector, handler) => { const node = $(selector); if (node) node.onclick = handler; };
    bindClick("#brand-home", () => { State.save(App.player); showBoard(); toast("Operations center ready.", "success"); });
    bindClick("#back-btn", closeScenario);
    bindClick("#file-report-btn", fileMissionReport);
    bindClick("#term-send", () => { const i = $("#term-input"); if (!i) return; const v = i.value; i.value = ""; runCommand(v); });
    bindClick("#save-btn", () => { saveSoon(); toast("Progress saved locally.", "success"); });
    bindClick("#help-btn", () => $("#shortcut-modal")?.classList.remove("hidden"));
    bindClick("#rules-open-btn", () => $("#rules-modal")?.classList.remove("hidden"));
    bindClick("#rules-close", () => $("#rules-modal")?.classList.add("hidden"));
    $$('[data-rules-tab]').forEach(tab=>tab.onclick=()=>{
      const key=tab.dataset.rulesTab;
      $$('[data-rules-tab]').forEach(x=>x.classList.toggle('active',x===tab));
      $$('[data-rules-pane]').forEach(p=>p.classList.toggle('hidden',p.dataset.rulesPane!==key));
    });
    bindClick("#profile-btn", openOperatorProfile);
    bindClick("#shortcut-close", () => $("#shortcut-modal")?.classList.add("hidden"));
    bindClick("#shortcut-modal", e => { if (e.target.id === "shortcut-modal") e.currentTarget.classList.add("hidden"); });
    bindClick("#reset-filter", () => { App.difficultyFilter = "All"; App.onlyAssessable = false; renderFilters(); renderBoardGrid(); });
    bindClick("#reset-data", resetApplication);
    bindClick("#focus-terminal", () => $("#term-input")?.focus());
    bindClick("#save-mission", () => { saveSoon(); toast("Mission state saved.", "success"); });
    $("#desktop-save")?.addEventListener("click", () => { saveSoon(); toast("Mission state saved.", "success"); });
    $("#desktop-help")?.addEventListener("click", () => $("#shortcut-modal")?.classList.remove("hidden"));
    bindClick("#objective-dock-close", () => { const d=$("#objective-dock"); d?.classList.add("collapsed"); $("#objective-dock-open")?.classList.remove("hidden"); });
    bindClick("#objective-dock-open", () => { $("#objective-dock")?.classList.remove("collapsed"); $("#objective-dock-open")?.classList.add("hidden"); });
    bindClick("#taskbar-wifi", () => openDesktopWindow("tool", "network"));
    document.addEventListener("keydown", e => {
      if (e.ctrlKey && e.key.toLowerCase() === "k") { e.preventDefault(); $("#term-input")?.focus(); }
      if (e.ctrlKey && e.key.toLowerCase() === "s") { e.preventDefault(); saveSoon(); toast("Progress saved locally.", "success"); }
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "d") { e.preventDefault(); openDebugPanel(); }
      if (e.key === "Escape") { $("#shortcut-modal")?.classList.add("hidden"); $("#rules-modal")?.classList.add("hidden"); }
    });
    boot();
  });
})();
