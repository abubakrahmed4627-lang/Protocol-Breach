import re, json, os, zipfile, hashlib, subprocess
from pathlib import Path
root=Path('/mnt/data/v63')
js=(root/'js/protocol-breach-runtime.js').read_text(encoding='utf8')
html=(root/'index.html').read_text(encoding='utf8')
report={}
# 1 syntax
r=subprocess.run(['node','--check',str(root/'js/protocol-breach-runtime.js')],capture_output=True,text=True)
report['syntax']=r.returncode==0
# static ids
ids=re.findall(r'\bid=["\']([^"\']+)["\']',html)
from collections import Counter
c=Counter(ids); report['duplicate_static_ids']=[k for k,v in c.items() if v>1]
report['static_ids']=len(ids)
report['buttons']=len(re.findall(r'<button\b',html,re.I))
report['unnamed_buttons']=len(re.findall(r'<button\b(?![^>]*(?:aria-label|title|>[^<]+</button>))[^>]*>',html,re.I))
# assets
refs=re.findall(r'(?:src|href)=["\']([^"\']+)["\']',html)
missing=[]
for ref in refs:
    if ref.startswith(('http:','https:','#','data:','javascript:')): continue
    if not (root/ref.split('?',1)[0]).exists(): missing.append(ref)
report['missing_html_assets']=missing
# stale refs
report['stale_scenario_refs']=sorted(set(re.findall(r'scenarios/plan-\d+\.js',js)))
# network primitives
report['real_network_primitives']={k:len(re.findall(k,js,re.I)) for k in ['XMLHttpRequest','WebSocket','sendBeacon']}
# commands 120x3 done by external script
qa=subprocess.run(['node',str(root/'test_params.js')],capture_output=True,text=True); report['parameter_test']=qa.stdout.strip()
# all default commands
qa=subprocess.run(['node',str(root/'test_all.js')],capture_output=True,text=True); report['command_test']=qa.stdout.strip()
# modules
qa=subprocess.run(['node',str(root/'test_modules.js')],capture_output=True,text=True); report['cross_tool_test']=qa.stdout.strip()
# assessment + red team direct
qa=subprocess.run(['node','-e',r'''const fs=require('fs'),vm=require('vm');const src=fs.readFileSync('/mnt/data/v63/js/protocol-breach-runtime.js','utf8');const ctx={window:{},State:{clamp:(x,a,b)=>Math.max(a,Math.min(b,x))},Clock:{now:()=>Date.now()},console,Date,Math,JSON};vm.createContext(ctx);let i=src.indexOf('/* ===== assessment.js ===== */'),j=src.indexOf('/* ===== world.js ===== */',i);vm.runInContext(src.slice(i,j),ctx);let s={id:1,reputation:0,assessmentSeed:42,objectiveResults:{},assessmentTaskFailures:{},assessmentCap:1000,assessmentEarnings:0,log:[]},sc={id:1,network:{hosts:[{hostname:'h',ip:'1.1.1.1',services:[{service:'http'}],vulnerabilities:[]}]},flags:[{description:'A',hint:'H'}],users:[]};let out={};for(const rep of [0,4,5,9,10,13,16,20]){s.reputation=rep;s.assessmentSet=[];s.assessmentSetBand=null;s.assessmentSetCount=0;let t=ctx.window.Assessment.ensureSet(sc,s);out[rep]={count:t.length,diff:t.map(x=>x.objectives[0].difficulty)}};out.pools=ctx.window.Assessment.poolStats();console.log(JSON.stringify(out));'''],capture_output=True,text=True); report['assessment_test']=qa.stdout.strip()
qa=subprocess.run(['node','-e',r'''const fs=require('fs'),vm=require('vm');const src=fs.readFileSync('/mnt/data/v63/js/protocol-breach-runtime.js','utf8');const ctx={window:{},console,Date,Math,JSON};vm.createContext(ctx);let i=src.indexOf('/* ===== economy.js ===== */'),j=src.indexOf('/* ===== assessment.js ===== */',i);vm.runInContext(src.slice(i,j),ctx);let out={};for(const rep of [0,10,19,20])out[rep]=ctx.window.Economy.redTeamQuote({score:100,reputation:rep}).map(x=>x.price);console.log(JSON.stringify(out));'''],capture_output=True,text=True); report['redteam_test']=qa.stdout.strip()
# file paths all scenarios
qa=subprocess.run(['node','-e',r'''const fs=require('fs'),vm=require('vm');const src=fs.readFileSync('/mnt/data/v63/js/protocol-breach-runtime.js','utf8');const ctx={window:{},console,Date,Math,JSON};vm.createContext(ctx);let a=src.indexOf('/* ===== bootstrap-data.js ===== */'),b=src.indexOf('/* ===== storage.js ===== */',a);vm.runInContext(src.slice(a,b),ctx);let w=src.indexOf('/* ===== world.js ===== */'),x=src.indexOf('/* ===== comms.js ===== */',w);vm.runInContext(src.slice(w,x),ctx);let out={};for(const [id,s] of Object.entries(ctx.window.SCENARIO_LIBRARY))out[id]=ctx.window.World.filePaths(s).dirs.filter(p=>['/home/kali','/home/kali/Desktop','/home/kali/Documents','/home/kali/Downloads'].includes(p));console.log(JSON.stringify(out));'''],capture_output=True,text=True); report['file_paths_test']=qa.stdout.strip()
(root/'QA_LATEST.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report,indent=2))
