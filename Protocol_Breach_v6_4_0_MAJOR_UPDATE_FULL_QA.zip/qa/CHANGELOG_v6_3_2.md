# v6.3.2
- First-launch intro persistence corrected.
- New-mission briefing gate added.
- Maple Careers upload surface and terminal workflow added.
- SMBMap/Careers help coverage added.
- Brix Hydra target routing corrected.
- Brix CCTV HTTP/login service added.
