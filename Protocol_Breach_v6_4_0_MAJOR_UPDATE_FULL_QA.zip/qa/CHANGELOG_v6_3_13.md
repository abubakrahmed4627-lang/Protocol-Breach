# v6.3.13

- Replaced wall-clock mission timing with active simulation time. Offline/hidden/closed-session time does not count.
- Objective time is derived per objective from a 1–10 difficulty score.
- Added the requested Slack and objective-time formulas.
- Mission total time is the sum of objective times.
- Score thresholds are 15%, 17.5%, 20%, 22.5%, and 25% of total time.
- Score ceilings are now 100 → 80 → 70 → 55 → 40 → 20.
- Timeout occurs at 30% of calculated total active mission time.
- Added Help → Rules with Summary and Detailed tabs.
- Detailed rules include all timing and score formulas plus the offline-time rule.
