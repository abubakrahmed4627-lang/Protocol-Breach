# Protocol Breach v6.3.0 — Full Walkthrough & Brutal QA Report
## Verdict

**Brutal rating: 9.6 / 10.** Mobile was intentionally excluded. The build is substantially stronger, but I am not calling it 10/10 because pixel-perfect cross-browser visual certification remains unavailable in this environment.
## Changes requested and addressed
- **File Explorer:** added real simulated path navigation (Home, Desktop, Documents, Downloads, /etc, /var, /tmp, /root, /opt), Up navigation, path-aware search, empty-folder states and persisted current path.- **Social Media:** searched profiles can now be opened reliably; profile IDs and post IDs both resolve, including generated search profiles.- **ComsApp / Mail / Phone:** contacts now expose interest topics derived from scenario/social intelligence. Topics such as football, coffee, travel, technology and motorsport can be discussed directly. Employee email messages also expose topic reply actions. Generated social profiles carry interests into the live communications directory.- **Assessments:** 1 assessment below 5 Reputation, 2 below 10, and 3 at 10+. Pools contain 100 Very Easy, 200 Easy, 200 Moderate, 100 Hard, 100 Very Hard and 100 Extreme variants. Questions are randomized per mission/reputation band and grounded in scenario data. Reputation raises both difficulty and reward multiplier. At 20/20, an Extreme assessment is guaranteed.- **Red Team:** at 20/20 Reputation, Red Team prices are reduced by 50%. The discount is visible in the Red Team UI.- **Accessibility:** the educational agreement checkbox now has an explicit accessible label.
## Five test approaches
### 1. Code / static integrity
- JavaScript syntax: **PASS**
- Static IDs: **76; 0 duplicates**
- Static buttons: **31; 0 unlabeled**
- Static inputs: **2; 0 unlabeled after checkbox fix**
- Missing HTML assets: **0**
- Stale scenario file references: **0**
- XMLHttpRequest/WebSocket/sendBeacon: **0**
### 2. All scenario command execution
- **10/10 scenarios**
- **120/120 command handlers**
- Default/normal execution: **0 errors**
- Parameter matrix: **360/360** across normal, abnormal and extreme arguments
### 3. Cross-tool consistency
- **All 10 scenarios** exercised through World/File data, Comms/Phone, Social and generated-profile paths.
- **30/30 tool bundles** passed.
- Scenario employee interests propagated into communications.
- Generated social profiles resolve back to profiles and remain addressable in the live directory.
### 4. Assessment / economy / persistence
- Assessment counts: <5 = 1, 5–9 = 2, 10+ = 3.
- Pool sizes: 100 / 200 / 200 / 100 / 100 / 100.
- Reward multiplier: 0.75× at 0 Rep, 1.375× at 10 Rep, 2.0× at 20 Rep.
- Red Team: 20 Rep produces exactly 50% of the 0–19 Rep price at the same Score.
- State wipe removes Protocol Breach save data while preserving unrelated origin data.
### 5. UI / walkthrough structure
The full logical walkthrough was traced for all scenarios:

**Startup → First Time / Played → 12-slide intro / agreement → Challenge Board → scenario selection → mission → desktop → Terminal / Browser / Files / Wi-Fi / Wireshark / Identity / ComsApp / Social / Location / Intel / Red Team / Assessments / Objectives / Log / Task Manager → mission report → board → reset → fresh startup.**

The browser automation environment still blocks reliable interactive Chromium execution, so this is a DOM/logic walkthrough rather than a claim of pixel-perfect human mouse testing.
## Scenario coverage
| # | Scenario | Difficulty | Commands | Hosts | Files | Users | Flags ||---:|---|---|---:|---:|---:|---:|---:|| 1 | Maple & Ash Legal Partners | Weak | 12 | 4 | 9 | 7 | 4 || 2 | Brix Dental Partners | Medium | 12 | 4 | 5 | 6 | 4 || 3 | RheinWerk Commerce GmbH | Medium | 12 | 3 | 4 | 6 | 4 || 4 | PixelForge Interactive | Hard | 12 | 4 | 4 | 6 | 4 || 5 | Al Nahda Capital | Brutal | 12 | 3 | 4 | 6 | 5 || 6 | Rede Vida Hospital Network | Hard | 12 | 5 | 4 | 7 | 4 || 7 | Hanul Logistics & Manufacturing | Brutal | 12 | 3 | 4 | 5 | 4 || 8 | Borealis Energy Group | Brutal | 12 | 4 | 4 | 5 | 4 || 9 | Aurora Media & Entertainment | Brutal | 12 | 3 | 4 | 5 | 4 || 10 | Meridian Global Shipping | Extremely Brutal | 12 | 4 | 4 | 6 | 5 |
## Important test outputs
```text
{ total: 360, failures: [] }
```
```text
{
  "counts": {
    "scenarios": 10,
    "commands": 120,
    "errors": 0
  },
  "failures": []
}
```
```text
{ scenarioToolBundles: 30, failures: 0, fail: [] }
```
Assessment matrix:
```json
{"0":{"count":1,"diff":["Easy"]},"4":{"count":1,"diff":["Very Easy"]},"5":{"count":2,"diff":["Easy","Easy"]},"9":{"count":2,"diff":["Easy","Very Easy"]},"10":{"count":3,"diff":["Moderate","Easy","Easy"]},"13":{"count":3,"diff":["Hard","Very Hard","Hard"]},"16":{"count":3,"diff":["Extreme","Extreme","Hard"]},"20":{"count":3,"diff":["Extreme","Extreme","Extreme"]},"pools":{"Very Easy":100,"Easy":200,"Moderate":200,"Hard":100,"Very Hard":100,"Extreme":100},"mult":[0.75,1.375,2]}
```
Red Team price matrix:
```json
{"0":[5,10,15,25],"19":[5,10,15,25],"20":[2.5,5,7.5,12.5]}
```
Reset ownership test:
```json
[["otherApp","keep"]]
```
## Remaining weaknesses — no sugar-coating
- **Real browser visual QA is still the largest certification gap.** I can validate DOM structure and application logic here, but I cannot honestly claim every Chrome/Edge/Firefox mouse/touch path and pixel-level rendering has been exercised.- **The runtime is still monolithic (~330 KB JS).** It is functional but expensive to maintain. A source-module/bundled architecture would reduce regression risk.- **The desktop UI is dense.** The simulator has a lot of tools and panels; first-time players can still experience cognitive overload.- **Mobile remains intentionally unchanged**, per request.- **Assessment pools are procedurally generated from reusable templates**, not 800 hand-authored questions. They meet the requested pool counts and vary scenario-grounded values, but a future content pass could make the higher tiers more strategically diverse rather than primarily template-driven.
## Final judgement

This is now a **9.6/10 release candidate**. I would not add more major applications. The next improvement should be real human/browser playtesting and balancing, not feature accumulation.
