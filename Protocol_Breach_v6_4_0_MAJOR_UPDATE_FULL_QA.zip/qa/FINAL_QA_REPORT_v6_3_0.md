# Protocol Breach v6.3.1 — Full Fix / Cross-Scenario QA

## Verdict

This release addresses the genuine bugs and cross-scenario variants found during the first-time-player walkthrough. Beginner-only knowledge gaps remain intentionally separate; the core simulator keeps authentic cybersecurity terminology.

## Fixes

### Critical workflow fixes
- RDP success now produces canonical objective evidence across scenarios instead of relying on a handler printing a flag manually.
- Successful RDP access creates a persistent simulated RDP session state and an Activity Log entry.
- Maple & Ash RDP now requires explicit credentials and validates them against scenario data. Wrong credentials fail cleanly.
- `xfreerdp` now supports `/v:`, `/u:` and `/p:` syntax.
- Successful RDP access unlocks the next objective through the existing evidence engine.
- Administrator is now intended to be reachable from the People Directory via an explicit profile action.
- Exposure Monitor no longer prints objective flag IDs or exact attack commands as the primary UI lead.

### UI / navigation fixes
- File Explorer now supports direct path entry in addition to Places and Up navigation.
- Fixed `/var` sidebar label condition.
- File Explorer path validation rejects nonexistent simulated paths without changing state.
- Terminal help now has an actual `xfreerdp` example and improved examples for major specialized tools.
- Nmap is now treated as quiet reconnaissance, matching the Terminal banner and the intended gameplay rule.
- RDP-active status is visible in the status strip.

### Mission-content fixes across all scenarios
- Removed explicit objective flag IDs from desktop notes.
- Removed plaintext credentials from desktop notes where those notes were acting as spoilers.
- Replaced them with investigation leads that still preserve the evidence chain.
- Scenario-specific credentials remain discoverable through the appropriate simulated tools/data rather than a universal spoiler note.

## Classification policy
- Genuine software/state failures: fixed.
- UI/explanation inconsistencies: fixed where they affected navigation or truthful feedback.
- Medium-user cybersecurity knowledge gaps: intentionally retained.
- Beginner friction: retained for a future learning layer rather than weakening the simulator.

## Tests performed

- JavaScript syntax: PASS
- Maple RDP unit path: missing credentials rejected; wrong credentials rejected; correct credentials accepted.
- Slash-style xfreerdp argument parsing: PASS
- Desktop notes scan: no explicit `Flag:` objective leaks in scenario fileContents.
- All 10 scenario command handlers remain present.
- Existing 120-command baseline retained.
- Existing assessment/economy changes retained.
- Existing social profile resolution retained.
- Existing communications interests retained.

## Known limitation

Real-browser pixel-perfect certification is still outside the available execution environment. The release therefore does not claim that every browser-rendering detail has been human-mouse certified.

## Release

**v6.3.1 — Full Fix**
