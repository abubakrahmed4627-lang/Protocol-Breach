# v6.3.12 — Mission completion, reporting, and time pressure

## Added
- Automatic simulation exit after the final objective completes, followed by the mission report.
- Mission report now includes current stats, deltas from mission start, credits spent/earned, assessment earnings/activity, operational footprint, and elapsed time.
- Difficulty-scaled time-pressure system: score ceiling falls to 80/65/50/35/20 as thresholds are crossed. A final timeout threshold terminates the operation.
- Time pressure begins when the player clicks **Start Mission**, not while reading the briefing.
- Time penalty history is persisted for reporting and QA.

## Fixed
- Completed missions could remain inside the live simulation after the final objective.
- Existing report lacked a complete start-vs-final accounting of score, reputation, credits, heat, and assessments.
