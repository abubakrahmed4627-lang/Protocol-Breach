# Protocol Breach v6.3.14

## Player Rules & Mechanics
- Expanded the ? > Rules modal into the authoritative player-facing game manual.
- Summary tab now explains mission flow, resources, operational style, support systems, timing and scope.
- Detailed tab now documents Points, Heat, Noise, Awareness, target response thresholds, Protection, Intelligence, Red Team, Assessments, recovery, time pressure, tools/evidence, Credits, Reputation, persistence and mission reports.
- Added exact formulas and current mechanic tables where appropriate.
- Added explicit distinction between player-facing mechanics and scenario-specific answers.
- Added rules tables styling.
