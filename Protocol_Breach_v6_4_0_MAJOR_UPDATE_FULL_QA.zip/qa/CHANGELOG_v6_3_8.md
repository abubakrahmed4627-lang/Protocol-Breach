# Protocol Breach v6.3.8

## Fix
- Fixed Careers file-picker runtime error caused by referencing the Files panel's locally scoped `normalizePath` helper.
- Careers picker now uses a local canonical path normalizer and the same `scenario.filesystem` + `scenario.fileContents` data source as the Files application.
- Preserved the small chooser dialog flow: select file, then click Choose, returning to Careers.
- No payload filename is prefilled or revealed by the Careers form.
