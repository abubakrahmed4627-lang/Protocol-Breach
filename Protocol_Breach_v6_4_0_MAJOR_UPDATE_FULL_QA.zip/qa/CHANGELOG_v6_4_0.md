# Protocol Breach v6.4.0

Major update implementing the expanded simulated command catalogue, mission lifecycle fixes, and scenario-specific educational briefing information.
