# Protocol Breach v6.3.2 — Walkthrough Fixes

This patch addresses defects found during the Maple & Ash and Brix Dental walkthroughs.

## Fixed
- Startup introduction now appears only until the first-time tutorial and educational agreement are completed. Returning users go directly to the Operations Center.
- New missions now show a mission briefing before entering the live simulation, including scenario description, objective chain, and the expected evidence-driven operating method. Existing in-progress missions continue directly.
- Maple Careers now exposes a real fictional application/upload surface and a corresponding `careers` terminal workflow. The simulator accepts the fictional Desktop `payload.exe` and awards the existing recruitment-malware objective flag through the normal evidence engine.
- `help careers` now documents the Careers workflow.
- `help smbmap` now documents the supported simulated SMB permission mapping syntax.
- Brix Hydra is target-aware. A CCTV target stays on the CCTV service; it no longer silently redirects to Roundcube. Unsupported/ambiguous targets return an explicit error.
- Brix CCTV now has a reachable simulated HTTP service at `http://cctv.brixdental.co.za:8080` with a functional fictional login surface. Successful use of the scenario credential evidence awards the CCTV objective through the normal flag/objective engine.

## Design guardrails
- Tool output cannot silently substitute a different host/service than the requested target.
- Objective completion remains evidence/flag-driven and does not depend solely on visible text.
- All functionality remains local and fictional; no real network requests are introduced.
