const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync('/mnt/data/v63/js/protocol-breach-runtime.js','utf8');
const a=src.indexOf('window.PB_TOOL_CATALOG = '), b=src.indexOf('\n\nwindow.Terminal',a);
const ctx={window:{},console,Date,Math,JSON}; vm.createContext(ctx); vm.runInContext(src.slice(a,b)+';',ctx);
const catalog=ctx.window.PB_TOOL_CATALOG;
const required=`nmap whois dig host theharvester recon-ng whatweb gobuster dirb curl wget masscan nikto enum4linux smbclient rpcclient snmpwalk onesixtyone dnsrecon burpsuite sqlmap wfuzz commix xsser wpscan zaproxy hydra john hashcat crunch cewl hash-identifier wireshark tcpdump ettercap bettercap responder arpspoof macchanger msfconsole searchsploit netcat ncat socat mimikatz powershell-empire weevely ssh scp rsync grep awk sed sort uniq find locate which ps top htop kill lsof ss netstat strings binwalk dd tar gzip zip unzip mmls fls icat foremost scalpel volatility gdb radare2 ghidra apktool strace ltrace faraday dradis cutycapt pipal`.split(' ');
const missing=required.filter(x=>!catalog[x]); const malformed=Object.entries(catalog).filter(([k,v])=>!Array.isArray(v)||v.length!==3||v.some(x=>!String(x).trim()));
// Verify the generic handler is present and can parse every catalogue command, --help and arbitrary flags.
const hStart=src.indexOf('    function extendedTool(cmd,args){'); const hEnd=src.indexOf('\n    function scenarioCmd',hStart);
const hsrc=src.slice(hStart,hEnd).replace(/^    function /,'function ');
const s={name:'Test Scenario',id:1,currentPath:'/home/kali',network:{hosts:[{ip:'203.0.113.10',hostname:'test.example',domains:['test.example'],services:[{port:80,protocol:'http',service:'http'}]}]},users:[{username:'analyst'}],fileContents:{'/home/kali/Desktop/notes.txt':'fictional test evidence'}};
const hctx={window:{PB_TOOL_CATALOG:catalog},console,Math,Date,s}; vm.createContext(hctx); vm.runInContext(hsrc,hctx);
const failures=[];
for(const cmd of required){ for(const args of [[],['--help'],['-v','--all','--rate','999','target']]){ try{const out=hctx.extendedTool(cmd,args); if(typeof out!=='string'||!out.includes('[SIMULATED')&&args[0]!=='--help') failures.push(`${cmd} ${args.join(' ')}`);}catch(e){failures.push(`${cmd}: ${e.message}`);} } }
console.log(JSON.stringify({required:required.length,catalog:Object.keys(catalog).length,missing,malformed,handlerFailures:failures},null,2));
process.exit((missing.length||malformed.length||failures.length)?1:0);
