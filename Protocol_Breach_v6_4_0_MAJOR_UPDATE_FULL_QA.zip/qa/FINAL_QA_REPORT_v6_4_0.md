# Protocol Breach v6.4.0 — Major Update QA Report

## Verdict

**Static/logic QA: PASS.**
The update implements the requested expanded simulated command catalogue and the marked mission-lifecycle fixes. No real network primitives were found.

Interactive pixel-perfect browser certification remains environment-limited; this report does not claim human mouse/touch certification where it could not be performed.

## 1. Code and integrity

- JavaScript syntax: **PASS**
- Static HTML IDs: **80; 0 duplicates**
- Static buttons: **35**
- Missing HTML assets: **0**
- Stale scenario references: **0**
- XMLHttpRequest: **0**
- WebSocket: **0**
- sendBeacon: **0**

## 2. Existing scenario command coverage

- Scenarios: **10/10**
- Scenario command handlers: **121**
- Default execution errors: **0**
- Parameter matrix: **363 tests, 0 failures**
- Cross-tool bundles: **30/30, 0 failures**

## 3. New CLI catalogue

**88/88 requested commands present.**

Every new catalogue entry has:
- category
- usage/syntax
- player-facing description
- `help <command>` support
- `--help` / `-h` response
- arbitrary option/argument parsing without crashing
- scenario-aware fictional output
- explicit local/simulated boundary

Extended-tool test:

```text
required: 88
catalog: 88
missing: []
malformed: []
handlerFailures: []
```

The simulator deliberately does not execute these tools against real hosts. Scenario-specific handlers remain authoritative for objective-grade evidence and flags.

## 4. Mission lifecycle fixes

### Completion

- All objectives complete → mission outcome becomes `COMPLETE`.
- Tick loop stops.
- Mission report is generated **before** the scenario board is restored.
- Board state is saved after completion.

### Timeout

- Score ceilings remain **80 / 70 / 55 / 40 / 20**.
- Threshold factors remain **15% / 17.5% / 20% / 22.5% / 25%** of calculated total objective time.
- Timeout state is persisted as `timedOut` with mission outcome `TIMEOUT`.
- Final report is shown before returning to the board.
- Scenario board now displays **Mission failed · Time limit**.
- Re-entering a completed or timed-out mission opens its report instead of restarting the live simulation.

### Active-time behavior

- Timer starts only after **Start Mission**.
- Hidden/offline/closed time is excluded.
- `Save & Exit` pauses active timing.
- Reload does not carry a live `activeTimeSince` timestamp across the gap.

## 5. Mission-time formula verification

The implemented formula is:

`slack = (minimum / 3) × (0.5 / difficulty)`

`objective time = (minimum + (maximum + slack)) / 2 + slack`

Difficulty 1–10 was evaluated successfully.

For the current difficulty scale, objective-time results are:

| Difficulty | Minimum | Maximum | Slack | Calculated time |
|---:|---:|---:|---:|---:|
| 1 | 4 | 10 | 0.6667 | 8.0000 |
| 2 | 5 | 12 | 0.4167 | 9.1250 |
| 3 | 6 | 15 | 0.3333 | 11.0000 |
| 4 | 7 | 18 | 0.2917 | 12.9375 |
| 5 | 8 | 20 | 0.2667 | 14.4000 |
| 6 | 10 | 24 | 0.2778 | 17.4167 |
| 7 | 12 | 28 | 0.2857 | 20.4286 |
| 8 | 14 | 32 | 0.2917 | 23.4375 |
| 9 | 16 | 36 | 0.2963 | 26.4444 |
| 10 | 18 | 42 | 0.3000 | 30.4500 |

A full set of difficulties 1–10 therefore produces a total of **173.6397 minutes** before the threshold multipliers are applied.

## 6. Existing systems regression tests

- Assessment generation: **PASS**
- Assessment pools: **PASS**
- Reputation/reward scaling: **PASS**
- Red Team pricing: **PASS**
- File-path coverage: **10/10 scenarios PASS**
- Scenario data consistency: **PASS**
- Reset ownership checks: **PASS**

## 7. Added educational briefing content

Every scenario briefing now includes:

- **Skills Needed**
- **Real-World Use**
- **Educational Purpose**
- Objective chain
- Operating method

The content is scenario-specific rather than a generic cybersecurity list.

## 8. Previously marked walkthrough bugs addressed

- Careers attachment chooser synchronization: retained and regression-tested.
- Careers `.exe` submission: retained with canonical objective completion and target-response effects.
- Careers objective completion: retained.
- Mission 4/4 completion transition: fixed.
- Completion report not appearing: fixed ordering.
- Timeout with no failure screen: fixed.
- Timeout remaining `In progress`: fixed.
- Post-timeout automatic re-entry/exit loop: fixed by treating timed-out missions as terminal and opening the report.
- Offline time consuming mission time: preserved as fixed.
- Mission briefing before a new mission: retained.
- Scenario-specific learning information: added in v6.4.0.
- Expanded CLI/tool catalogue: added in v6.4.0.

## 9. Remaining certification limitation

The environment used for this QA run does not permit reliable interactive Chromium navigation of the local application, so a literal human-style click-through of every UI path was not honestly claimed. Static, syntax, scenario, parameter, cross-tool, catalogue and lifecycle checks were completed instead.
