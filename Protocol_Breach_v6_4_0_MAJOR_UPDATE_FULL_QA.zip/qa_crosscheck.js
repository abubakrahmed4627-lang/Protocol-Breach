const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync('/mnt/data/pbwork/js/protocol-breach-runtime.js','utf8');
const ctx={window:{},console,Date,Math,JSON}; vm.createContext(ctx);
const a=src.indexOf('/* ===== bootstrap-data.js ===== */'), b=src.indexOf('/* ===== storage.js ===== */',a); vm.runInContext(src.slice(a,b),ctx);
const w=src.indexOf('/* ===== world.js ===== */'), x=src.indexOf('/* ===== comms.js ===== */',w); vm.runInContext(src.slice(w,x),ctx); const webStart=src.indexOf('/* ===== web.js ===== */'), webEnd=src.indexOf('/* ===== terminal.js ===== */',webStart); vm.runInContext(src.slice(webStart,webEnd),ctx);
let report={scenarios:0,people:0,profileClueMismatches:[],directoryMissingProfiles:[],genericExposureLeads:[],flagLeaksInNotes:[]};
for(const [id,s] of Object.entries(ctx.window.SCENARIO_LIBRARY)){
 report.scenarios++;
 const pages=ctx.window.WebWorld.pages(s,{world:{generatedProfiles:{}}});
 const dir=pages.filter(p=>p.category==='directory'&&p.url.endsWith('/people')).find(Boolean);
 const profiles=pages.filter(p=>p.category==='directory'&&/\/people\//.test(p.url));
 const users=s.users||[];
 report.people+=users.length;
 for(const u of users){
   const p=profiles.find(x=>x.url.endsWith('/'+String(u.username).toLowerCase().replace(/[^a-z0-9]+/g,'-')));
   if(!p) report.directoryMissingProfiles.push({id,username:u.username});
   else {
     const clue=String(p.html).match(/Public OSINT clue<\/b><p>(.*?)<\/p>/)?.[1]||'';
     const expected=String(u.osint||'No public clue catalogued.').replace(/&/g,'&amp;');
     if(clue!==expected) report.profileClueMismatches.push({id,username:u.username,expected,got:clue});
   }
 }
 const intel=pages.find(p=>p.category==='intel');
 if(intel && /Lead: Investigate the relevant service, host or application using the scenario evidence\./.test(intel.html)) report.genericExposureLeads.push(id);
 for(const [path,text] of Object.entries(s.fileContents||{})) if(/\/Desktop\/notes\.txt$/.test(path) && /Flag:\s*[A-Z]+\{/.test(text)) report.flagLeaksInNotes.push({id,path});
}
console.log(JSON.stringify(report,null,2));
