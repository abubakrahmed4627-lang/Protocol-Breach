const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync('/mnt/data/v63/js/protocol-breach-runtime.js','utf8');
const bi=src.indexOf('/* ===== bootstrap-data.js ===== */'), bj=src.indexOf('/* ===== storage.js ===== */',bi);
const ctx={window:{},console,Date,Math,JSON};vm.createContext(ctx);vm.runInContext(src.slice(bi,bj),ctx);
const scenarios=ctx.window.SCENARIO_LIBRARY;
function helpersFor(s){
 const hosts=(s.network?.hosts||[]); const files=s.fileContents||{};
 return {
  currentPath:'/home/kali',flagsFound:[],scenario:s,env:{},
  findFlagInText:(t)=>((s.flags||[]).find(f=>String(t).includes(f.id))||null),
  resolvePath:(p)=>String(p||'').startsWith('/')?String(p):'/home/kali/'+String(p),
  listDirectory:(p)=>Object.keys(files).filter(x=>x.startsWith(String(p||'/home/kali')+'/')).map(x=>x.split('/').pop()),
  getFileContent:(p)=>files[p]??null,printLine:()=>{},getHostByIP:(ip)=>hosts.find(h=>h.ip===ip),
  getServiceByIPPort:(ip,port)=>{const h=hosts.find(x=>x.ip===ip);return h?.services?.find(v=>String(v.port)===String(port))},
  getAllIPs:()=>hosts.map(h=>h.ip),
  filesystem:s.filesystem||{},
 };
}
let failures=[];let counts={scenarios:0,commands:0,errors:0};
for(const [id,s] of Object.entries(scenarios)){
 counts.scenarios++;
 const cmds=s.commands||{};
 for(const [name,fn] of Object.entries(cmds)){
  counts.commands++;
  try{const out=fn([],s,helpersFor(s)); if(out===undefined||out===null) throw new Error('empty output');}
  catch(e){counts.errors++;failures.push({id,name,error:String(e&&e.stack||e)});}
 }
}
console.log(JSON.stringify({counts,failures},null,2));
