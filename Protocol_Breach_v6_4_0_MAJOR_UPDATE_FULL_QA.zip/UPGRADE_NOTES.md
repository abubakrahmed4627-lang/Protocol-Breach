# Protocol Breach v6.4.0 Major Update

- 88 additional simulated CLI commands across the requested tool categories.
- Player-facing help and scenario-aware fictional fallback output.
- Fixed completion and timeout report ordering.
- Fixed timeout persistence and post-timeout re-entry.
- Added scenario-specific Skills Needed, Real-World Use and Educational Purpose to mission briefings.
- Active-time-only timer remains enforced.
- Score ceilings remain 80 / 70 / 55 / 40 / 20 at 15% / 17.5% / 20% / 22.5% / 25% of calculated objective time.
- All activity remains fictional and local.
