const fs=require('fs'),vm=require('vm');const src=fs.readFileSync('/mnt/data/v63/js/protocol-breach-runtime.js','utf8');const ctx={window:{},console,Date,Math,JSON};vm.createContext(ctx);
function mod(a,b){const i=src.indexOf(`/* ===== ${a}.js ===== */`),j=src.indexOf(`/* ===== ${b}.js ===== */`,i);if(i<0||j<0)throw new Error('module markers '+a+' '+b);vm.runInContext(src.slice(i,j),ctx)}
mod('world','comms');mod('comms','web');mod('social','app');
const bi=src.indexOf('/* ===== bootstrap-data.js ===== */'),bj=src.indexOf('/* ===== storage.js ===== */',bi);vm.runInContext(src.slice(bi,bj),ctx);
const scenarios=ctx.window.SCENARIO_LIBRARY;let fail=[];let n=0;
for(const [id,s] of Object.entries(scenarios)){
 const state={difficulty:s.difficulty,world:{generatedProfiles:{}},comms:{directory:[],emails:[]},social:{friends:{},messages:{},viewed:[],feedOffset:0,relationshipXP:0},users:s.users};
 try{const fs=ctx.window.World.files(s); if(!fs.length)throw new Error('no files'); ctx.window.World.filePaths(s); ctx.window.World.browserResults(s,'home'); ctx.window.World.wifi(s);ctx.window.World.simulatedSpeed(state);ctx.window.World.latencyMs(state);n++;}catch(e){fail.push([id,'World',String(e)])}
 try{const d=ctx.window.CommsWorld.directory(state); if(!d.length)throw new Error('no directory'); const c=d[0]; ctx.window.CommsWorld.phoneLookup(state,c.phone); ctx.window.CommsWorld.optionReply(state,c,'greeting','phone'); ctx.window.CommsWorld.optionReply(state,c,'topic:'+(c.interests?.[0]||'football'),'phone');n++;}catch(e){fail.push([id,'Comms',String(e)])}
 try{const rows=ctx.window.SocialWorld.search(s,'football'); if(!rows.length)throw new Error('no search'); const p=ctx.window.SocialWorld.resolveProfile(state,rows[0].id); if(!p)throw new Error('profile not resolvable'); ctx.window.SocialWorld.openPost(state,ctx.window.SocialWorld.postFor(p,0));n++;}catch(e){fail.push([id,'Social',String(e)])}
}
console.log({scenarioToolBundles:n,failures:fail.length,fail:fail.slice(0,20)});
